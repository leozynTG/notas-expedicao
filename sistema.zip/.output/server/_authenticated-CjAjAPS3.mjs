import { o as __toESM } from "./_runtime.mjs";
import { baixar, gerarPlanilha, gerarZips } from "./_ssr/exportar-CyB7YhkX.mjs";
import { n as lerPickingsTexto, processarCarga, r as TIPOS, t as lerPickingsPdf } from "./_ssr/processar-CJm-LIil.mjs";
import { y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "./_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { E as CircleAlert, S as Database, T as CircleCheck, f as LoaderCircle, g as FileText, m as Info, n as TriangleAlert, s as RotateCcw, t as X, v as FileSpreadsheet, x as Download, y as FileArchive } from "./_libs/lucide-react.mjs";
import { f as salvarCarga, i as cargaExistente, t as AppShell } from "./_ssr/AppShell-DeQ07z7V.mjs";
import { t as cn } from "./_ssr/utils-C_uf36nf.mjs";
import { t as Button } from "./_ssr/button-UtwXV0ic.mjs";
import { t as Input } from "./_ssr/input-B8Q2ztVi.mjs";
import { t as Label } from "./_ssr/label-DBD1bRRP.mjs";
import { n as dataHora, t as brl } from "./_ssr/formato-C78tmqZq.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./_ssr/alert-dialog-CJc3CPXp.mjs";
import { a as sugerirNumeroCarga, i as montarCarga, n as cargasDistintas, t as TabelaNotas } from "./_ssr/historico-C0yNNhv5.mjs";
import { a as useQueryClient } from "./_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated-CjAjAPS3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DropZone({ titulo, dica, aceita, extensoes, icone, arquivo, opcional, onArquivo, onErro }) {
	const input = (0, import_react.useRef)(null);
	const [arrastando, setArrastando] = (0, import_react.useState)(false);
	function escolher(f) {
		if (!f) return;
		const nome = f.name.toLowerCase();
		if (!extensoes.some((e) => nome.endsWith(e))) {
			onErro(`"${f.name}" não é um arquivo aceito aqui (${extensoes.join(", ")}).`);
			return;
		}
		onArquivo(f);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "button",
		tabIndex: 0,
		"aria-label": titulo,
		onClick: () => input.current?.click(),
		onKeyDown: (e) => (e.key === "Enter" || e.key === " ") && input.current?.click(),
		onDragOver: (e) => {
			e.preventDefault();
			setArrastando(true);
		},
		onDragLeave: () => setArrastando(false),
		onDrop: (e) => {
			e.preventDefault();
			setArrastando(false);
			escolher(e.dataTransfer.files[0]);
		},
		className: cn("group relative flex min-h-48 cursor-pointer flex-col justify-between rounded-lg border-2 border-dashed bg-card p-5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", arrastando ? "border-primary bg-accent" : "border-input hover:border-primary/60", arquivo && "border-solid border-primary/50"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: input,
				type: "file",
				accept: aceita,
				className: "hidden",
				onChange: (e) => {
					escolher(e.target.files?.[0]);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-10 items-center justify-center rounded-md bg-accent text-accent-foreground [&_svg]:size-5",
					children: icone
				}), opcional && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-secondary px-2 py-0.5 text-xs font-medium text-muted-foreground",
					children: "opcional"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-foreground",
					children: titulo
				}), arquivo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular truncate text-sm text-primary",
							children: arquivo.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular shrink-0 text-xs text-muted-foreground",
							children: [(arquivo.size / 1024).toLocaleString("pt-BR", { maximumFractionDigits: 0 }), " KB"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Remover arquivo",
							onClick: (e) => {
								e.stopPropagation();
								onArquivo(null);
							},
							className: "ml-auto rounded p-1 text-muted-foreground hover:bg-secondary hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: dica
				})]
			})
		]
	});
}
var ORDEM = [
	"erro",
	"alerta",
	"info"
];
var ESTILO_NIVEL = {
	erro: {
		caixa: "border-destructive/30 bg-destructive-soft text-destructive",
		icone: CircleAlert
	},
	alerta: {
		caixa: "border-warning/50 bg-warning-soft text-warning-foreground",
		icone: TriangleAlert
	},
	info: {
		caixa: "border-border bg-secondary text-muted-foreground",
		icone: Info
	}
};
function Indicador({ rotulo, valor, destaque }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("card-surface p-4", destaque && "border-warning/60 bg-warning-soft"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
			children: rotulo
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("tabular mt-1 text-2xl font-medium", destaque ? "text-warning-foreground" : "text-foreground"),
			children: valor
		})]
	});
}
function ConferenciaPickings({ mapa, pedidosNf }) {
	const arquivo = mapa.origem === "txt" ? ".txt" : mapa.origem === "ocr" ? "PDF (por OCR)" : "PDF";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "text-sm font-semibold text-foreground",
			children: [
				"Conferência dos pickings",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-normal text-muted-foreground",
					children: [
						"— ",
						mapa.pickings.length,
						" par(es) lido(s) do ",
						arquivo
					]
				})
			]
		}), mapa.semTexto ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			role: "alert",
			className: "flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive-soft px-4 py-3 text-sm text-destructive",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 size-4 shrink-0" }), mapa.origem === "pdf" ? "Este PDF não tem texto: parece ser uma digitalização (imagem). Os pickings não puderam ser lidos. Gere o PDF de novo pelo sistema ou envie o .txt." : "O arquivo .txt está vazio. Os pickings não puderam ser lidos."]
		}) : mapa.pickings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			role: "alert",
			className: "flex items-start gap-2 rounded-lg border border-destructive/30 bg-destructive-soft px-4 py-3 text-sm text-destructive",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 size-4 shrink-0" }), "Nenhum pedido foi encontrado no mapa analítico. Confira se é o arquivo certo."]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-surface max-h-96 overflow-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "sticky top-0 bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
						"Nº picking",
						"Pedido",
						"Tipo",
						"Na carga"
					].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "whitespace-nowrap px-3 py-2 font-medium",
						children: h
					}, h)) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: mapa.pickings.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular px-3 py-2",
							children: p.numero || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive",
								children: "não lido"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular px-3 py-2",
							children: p.pedido
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: p.descricao
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: pedidosNf.has(p.pedido) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-success",
								children: "Sim"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Sem NF"
							})
						})
					]
				}, `${p.numero}|${p.pedido}`)) })]
			})
		})]
	});
}
function Resultado({ resultado, onBaixar, onNova }) {
	const { resumo, notas, avisos } = resultado;
	const grupos = (0, import_react.useMemo)(() => {
		const m = /* @__PURE__ */ new Map();
		for (const a of avisos) {
			const g = m.get(a.categoria) ?? {
				nivel: a.nivel,
				itens: []
			};
			g.itens.push(a);
			m.set(a.categoria, g);
		}
		return Array.from(m.entries()).sort((a, b) => ORDEM.indexOf(a[1].nivel) - ORDEM.indexOf(b[1].nivel));
	}, [avisos]);
	const previa = notas.slice(0, 15);
	const pedidosNf = (0, import_react.useMemo)(() => new Set(notas.map((n) => n.pedido.toUpperCase()).filter(Boolean)), [notas]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3 lg:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "XMLs lidos",
						valor: resumo.total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Fracionadas",
						valor: resumo.fracionadas,
						destaque: resumo.fracionadas > 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Sem volume no XML",
						valor: resumo.semVolume,
						destaque: resumo.semVolume > 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Sem pedido",
						valor: resumo.semPedido,
						destaque: resumo.semPedido > 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Notas sem picking",
						valor: resumo.notasSemPicking,
						destaque: resumo.notasSemPicking > 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Valor total",
						valor: brl(resumo.valorTotal)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold text-foreground",
					children: "Notas por tipo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: TIPOS.filter((t) => resumo.porTipo[t] > 0).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 rounded-md border bg-secondary px-3 py-1.5 text-sm",
						children: [t, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular font-medium text-primary",
							children: resumo.porTipo[t]
						})]
					}, t))
				})]
			}),
			resultado.mapa && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConferenciaPickings, {
				mapa: resultado.mapa,
				pedidosNf
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "download",
						size: "tile",
						onClick: () => onBaixar("planilha"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex flex-col items-start",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Planilha de notas" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-normal opacity-80",
									children: [
										".xlsx · ",
										resumo.total,
										" linhas"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "ml-auto" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "downloadOutline",
						size: "tile",
						disabled: resumo.noZipTrocas === 0,
						onClick: () => onBaixar("trocas"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-col items-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "trocas_brindes_amostras.zip" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-normal text-muted-foreground",
								children: [resumo.noZipTrocas, " XML(s)"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "ml-auto" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "downloadOutline",
						size: "tile",
						disabled: resumo.noZipDemais === 0,
						onClick: () => onBaixar("demais"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-col items-start",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "demais_notas.zip" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs font-normal text-muted-foreground",
								children: [resumo.noZipDemais, " XML(s)"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "ml-auto" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-sm font-semibold text-foreground",
					children: ["Avisos ", avisos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular text-muted-foreground",
						children: [
							"(",
							avisos.length,
							")"
						]
					})]
				}), grupos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-lg border border-success/30 bg-success-soft px-4 py-3 text-sm text-success",
					children: "Nenhum aviso. Tudo conferido."
				}) : grupos.map(([categoria, g]) => {
					const { caixa, icone: Icone } = ESTILO_NIVEL[g.nivel];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						open: g.nivel !== "info",
						className: cn("rounded-lg border px-4 py-3", caixa),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
							className: "flex cursor-pointer items-center gap-2 text-sm font-semibold",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icone, { className: "size-4 shrink-0" }),
								categoria,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular font-normal opacity-80",
									children: ["· ", g.itens.length]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-1 pl-6 text-sm text-foreground",
							children: g.itens.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "list-disc",
								children: a.mensagem
							}, i))
						})]
					}, categoria);
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-sm font-semibold text-foreground",
					children: ["Prévia ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-normal text-muted-foreground",
						children: [
							"— primeiras ",
							previa.length,
							" de ",
							notas.length,
							" notas"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabelaNotas, { linhas: previa })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center pb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: onNova,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), " Processar outra carga"]
				})
			})
		]
	});
}
function SalvarCarga({ notas }) {
	const queryClient = useQueryClient();
	const [numero, setNumero] = (0, import_react.useState)(() => sugerirNumeroCarga(notas));
	const [salvando, setSalvando] = (0, import_react.useState)(false);
	const [existente, setExistente] = (0, import_react.useState)(null);
	const [salvaId, setSalvaId] = (0, import_react.useState)(null);
	const distintas = cargasDistintas(notas);
	async function gravar(substituir) {
		const { carga, notas: linhas } = montarCarga(numero, notas);
		let id;
		try {
			id = await salvarCarga({ data: {
				carga,
				notas: linhas,
				substituir
			} });
		} catch (e) {
			if (e instanceof Error && e.message.includes("CARGA_JA_EXISTE")) return "existe";
			throw e;
		}
		setSalvaId(id);
		queryClient.invalidateQueries({ queryKey: ["cargas"] });
		toast.success(`Carga ${carga.numero_carga} salva no histórico.`);
		return "ok";
	}
	async function verificarExistente(n) {
		return await cargaExistente({ data: { numero: n } });
	}
	async function salvar() {
		const n = numero.trim();
		if (!n) {
			toast.error("Informe o número da carga.");
			return;
		}
		setSalvando(true);
		try {
			const atual = await verificarExistente(n);
			if (atual) {
				setExistente(atual);
				return;
			}
			if (await gravar(false) === "existe") setExistente(await verificarExistente(n));
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível salvar a carga. Tente de novo.");
		} finally {
			setSalvando(false);
		}
	}
	async function substituir() {
		setExistente(null);
		setSalvando(true);
		try {
			await gravar(true);
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível substituir a carga. Tente de novo.");
		} finally {
			setSalvando(false);
		}
	}
	if (salvaId) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-wrap items-center gap-3 rounded-lg border border-success/30 bg-success-soft px-4 py-3 text-sm text-success",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-5 shrink-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				"Carga ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular font-medium",
					children: numero.trim()
				}),
				" salva no histórico."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				size: "sm",
				variant: "outline",
				className: "ml-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/historico/$id",
					params: { id: salvaId },
					children: "Abrir no histórico"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "card-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
							htmlFor: "numero-carga",
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4 text-primary" }), " Número da carga"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "numero-carga",
							className: "tabular w-48",
							value: numero,
							placeholder: "Ex.: 140894",
							onChange: (e) => setNumero(e.target.value),
							onKeyDown: (e) => e.key === "Enter" && salvar()
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: salvar,
						disabled: salvando || !numero.trim(),
						children: [salvando && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), " Salvar no histórico"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "basis-full text-xs text-muted-foreground sm:basis-auto",
						children: [
							numero && distintas.includes(numero.trim()) ? "Lido das informações complementares das notas. Confira ou corrija antes de salvar." : "Não encontramos o número da carga nas notas. Digite antes de salvar.",
							" ",
							"Só os dados da tabela são salvos; os XMLs e o PDF não."
						]
					})
				]
			}),
			distintas.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-warning-foreground",
				children: [
					"Este ZIP tem notas de mais de uma carga: ",
					distintas.join(", "),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: existente !== null,
				onOpenChange: (o) => !o && setExistente(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, { children: [
					"A carga ",
					numero.trim(),
					" já está no histórico"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: existente && `Ela foi processada por ${existente.processada_por_email || "usuário removido"} em ${dataHora(existente.processada_em)}, com ${existente.total_notas} nota(s). Deseja substituir pelos dados desta carga?` })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancelar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: substituir,
					children: "Substituir"
				})] })] })
			})
		]
	});
}
var XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
function Index() {
	const [zip, setZip] = (0, import_react.useState)(null);
	const [mapa, setMapa] = (0, import_react.useState)(null);
	const [processando, setProcessando] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("");
	const [erro, setErro] = (0, import_react.useState)(null);
	const [resultado, setResultado] = (0, import_react.useState)(null);
	const [arquivos, setArquivos] = (0, import_react.useState)(null);
	const base = zip ? zip.name.replace(/\.(zip|rar)$/i, "") : "carga";
	async function processar() {
		if (!zip) return;
		setErro(null);
		setProcessando(true);
		try {
			let leitura = null;
			if (mapa) if (mapa.name.toLowerCase().endsWith(".pdf")) {
				const { lerPaginasPdf } = await import("./_ssr/pdf-texto-DYy5gAvA.mjs");
				setStatus("Lendo o PDF do mapa analítico…");
				leitura = lerPickingsPdf(await lerPaginasPdf(mapa));
				if (leitura.pickings.length === 0) {
					setStatus("PDF sem texto legível: iniciando OCR (pode levar alguns minutos)…");
					const { lerPickingsOcr } = await import("./_ssr/ocr-Bb79OMzx.mjs");
					leitura = await lerPickingsOcr(mapa, (i, t) => setStatus(`OCR do mapa analítico: página ${i} de ${t}`));
				}
			} else leitura = lerPickingsTexto(await mapa.text());
			const r = await processarCarga(await zip.arrayBuffer(), leitura);
			const [planilha, zips] = await Promise.all([gerarPlanilha(r.notas), gerarZips(r.notas)]);
			setArquivos({
				planilha,
				...zips
			});
			setResultado(r);
		} catch (e) {
			console.error(e);
			setErro(e instanceof Error && e.message ? e.message : "Não foi possível ler os arquivos. Confira se o ZIP e o PDF estão corretos.");
		} finally {
			setProcessando(false);
			setStatus("");
		}
	}
	function onBaixar(qual) {
		if (!arquivos) return;
		if (qual === "planilha") baixar(arquivos.planilha, `notas_${base}.xlsx`, XLSX_MIME);
		if (qual === "trocas") baixar(arquivos.trocas, "trocas_brindes_amostras.zip", "application/zip");
		if (qual === "demais") baixar(arquivos.demais, "demais_notas.zip", "application/zip");
	}
	function nova() {
		setResultado(null);
		setArquivos(null);
		setZip(null);
		setMapa(null);
		setErro(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: resultado ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-baseline gap-x-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight text-foreground",
				children: "Resumo da carga"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular text-sm text-muted-foreground",
				children: zip?.name
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SalvarCarga, { notas: resultado.notas }, zip?.name)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Resultado, {
			resultado,
			onBaixar,
			onNova: nova
		})
	] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tight text-foreground",
				children: "Organizar XMLs da carga"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-muted-foreground",
				children: "Envie o ZIP com as notas e, se tiver, o mapa analítico dos pedidos. Você recebe a planilha e os XMLs separados em dois ZIPs."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropZone, {
					titulo: "1. ZIP com os XMLs",
					dica: "Arraste o .zip ou .rar aqui ou clique para escolher",
					aceita: ".zip,.rar,application/zip,application/vnd.rar",
					extensoes: [".zip", ".rar"],
					icone: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileArchive, {}),
					arquivo: zip,
					onArquivo: setZip,
					onErro: setErro
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropZone, {
					titulo: "2. Mapa analítico (pickings)",
					dica: "PDF ou .txt da impressão dos pedidos",
					aceita: ".pdf,.txt,application/pdf,text/plain",
					extensoes: [".pdf", ".txt"],
					icone: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}),
					arquivo: mapa,
					opcional: true,
					onArquivo: setMapa,
					onErro: setErro
				})]
			}),
			erro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-4 rounded-md border border-destructive/30 bg-destructive-soft px-4 py-3 text-sm text-destructive",
				children: erro
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex items-center gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "lg",
						disabled: !zip || processando,
						onClick: processar,
						children: [processando && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), processando ? "Processando…" : "Processar carga"]
					}),
					processando && status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted-foreground",
						children: status
					}),
					!mapa && zip && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted-foreground",
						children: "Sem o mapa, as notas ficam sem número de picking."
					})
				]
			})
		]
	}) });
}
//#endregion
export { Index as component };
