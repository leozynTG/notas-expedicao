//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DiacZnnd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/tmp/repo/notas/src/routes/__root.tsx",
		children: ["/_authenticated"],
		preloads: [
			"/assets/index-CLiV3A19.js",
			"/assets/rolldown-runtime-C0FnF6B9.js",
			"/assets/useSelector-DlpMds3W.js",
			"/assets/AppShell-DuKKRfRk.js",
			"/assets/matchContext-1KyhBNCI.js",
			"/assets/queryOptions-C9dJc8S5.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CLiV3A19.js"
		} }]
	},
	"/_authenticated": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/route.tsx",
		children: [
			"/_authenticated/cte",
			"/_authenticated/dashboard",
			"/_authenticated/",
			"/_authenticated/historico/$id",
			"/_authenticated/recebimento/$id",
			"/_authenticated/recebimento/novo",
			"/_authenticated/historico/",
			"/_authenticated/recebimento/"
		],
		preloads: ["/assets/route-DxclXa8I.js"]
	},
	"/_authenticated/cte": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/cte.tsx",
		children: void 0,
		preloads: [
			"/assets/cte-PVUzN88W.js",
			"/assets/download-CYIG0YY2.js",
			"/assets/x-DIwZeolV.js",
			"/assets/ordenar-BIEiKX-8.js",
			"/assets/exportar-Br9tW4wt.js",
			"/assets/dist-BQrrITPo.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/input-BBCP_jeX.js",
			"/assets/dist-BQz7sBaD.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-Ce4HMbks.js",
			"/assets/useQuery-CdJVZ_6k.js",
			"/assets/dist-D3mQCY3V.js",
			"/assets/chevron-right-Ce_4w_8r.js",
			"/assets/label-CwQV9W00.js",
			"/assets/x-DIwZeolV.js",
			"/assets/dist-BQrrITPo.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/input-BBCP_jeX.js",
			"/assets/dist-BQz7sBaD.js",
			"/assets/dist-nlOcyzZC.js",
			"/assets/Combination-CBwg8PtB.js",
			"/assets/formato-BVpioUbh.js"
		]
	},
	"/_authenticated/": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated-BIN2CHEg.js",
			"/assets/download-CYIG0YY2.js",
			"/assets/file-text-B4a-jsZI.js",
			"/assets/file-spreadsheet-DzbYmH9a.js",
			"/assets/label-CwQV9W00.js",
			"/assets/x-DIwZeolV.js",
			"/assets/exportar-Br9tW4wt.js",
			"/assets/processar-yS5zIywx.js",
			"/assets/dist-BQrrITPo.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/input-BBCP_jeX.js",
			"/assets/formato-BVpioUbh.js",
			"/assets/alert-dialog-CFOF4H9K.js",
			"/assets/historico-CJvNHk49.js"
		]
	},
	"/_authenticated/historico/$id": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/historico.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/historico._id-BRxMCgBn.js",
			"/assets/useSuspenseQuery-CT7giOaf.js",
			"/assets/trash-2-DlHl7KK7.js",
			"/assets/download-CYIG0YY2.js",
			"/assets/file-spreadsheet-DzbYmH9a.js",
			"/assets/dist-BQrrITPo.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/formato-BVpioUbh.js",
			"/assets/alert-dialog-CFOF4H9K.js",
			"/assets/historico-CJvNHk49.js"
		]
	},
	"/_authenticated/recebimento/$id": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/recebimento.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/recebimento._id-DmCH0XIU.js",
			"/assets/useSuspenseQuery-CT7giOaf.js",
			"/assets/trash-2-DlHl7KK7.js",
			"/assets/FormRecebimento-OZewGSEU.js",
			"/assets/dados-B8TcGrvV.js",
			"/assets/dist-BQrrITPo.js",
			"/assets/alert-dialog-CFOF4H9K.js"
		]
	},
	"/_authenticated/recebimento/novo": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/recebimento.novo.tsx",
		children: void 0,
		preloads: [
			"/assets/recebimento.novo-CtdxSQBq.js",
			"/assets/useQuery-CdJVZ_6k.js",
			"/assets/trash-2-DlHl7KK7.js",
			"/assets/FormRecebimento-OZewGSEU.js",
			"/assets/dados-B8TcGrvV.js"
		]
	},
	"/_authenticated/historico/": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/historico.index.tsx",
		children: void 0,
		preloads: [
			"/assets/historico.index-D559kogX.js",
			"/assets/useQuery-CdJVZ_6k.js",
			"/assets/chevron-right-Ce_4w_8r.js",
			"/assets/input-BBCP_jeX.js",
			"/assets/formato-BVpioUbh.js"
		]
	},
	"/_authenticated/recebimento/": {
		filePath: "/tmp/repo/notas/src/routes/_authenticated/recebimento.index.tsx",
		children: void 0,
		preloads: [
			"/assets/recebimento.index-BsX8P_iK.js",
			"/assets/useQuery-CdJVZ_6k.js",
			"/assets/chevron-right-Ce_4w_8r.js",
			"/assets/file-spreadsheet-DzbYmH9a.js",
			"/assets/dados-B8TcGrvV.js",
			"/assets/label-CwQV9W00.js",
			"/assets/exportar-Br9tW4wt.js",
			"/assets/dist-BQrrITPo.js",
			"/assets/utils-B6KiDbIe.js",
			"/assets/input-BBCP_jeX.js",
			"/assets/formato-BVpioUbh.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
