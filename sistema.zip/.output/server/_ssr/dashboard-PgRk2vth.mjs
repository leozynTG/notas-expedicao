import { o as __toESM } from "../_runtime.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as Check, D as ChevronUp, O as ChevronRight, f as LoaderCircle, k as ChevronDown, n as TriangleAlert, t as X } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-UtwXV0ic.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { a as pct, i as numBr, n as dataHora, s as toneladas, t as brl } from "./formato-C78tmqZq.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as Route } from "./dashboard-DsuH-YBt.mjs";
import { a as seriePorCarga, i as intervaloPeriodo, o as topCidades, r as dashboardQuery, s as totais } from "./historico-queries-DyG2ualt.mjs";
import { a as Line, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as LineChart, o as CartesianGrid, r as YAxis, s as Bar, t as BarChart } from "../_libs/recharts+[...].mjs";
import { a as SelectItemIndicator, c as SelectPortal, d as SelectSeparator$1, f as SelectTrigger$1, i as SelectItem$1, l as SelectScrollDownButton$1, m as SelectViewport, n as SelectContent$1, o as SelectItemText, p as SelectValue$1, r as SelectIcon, s as SelectLabel$1, t as Select$1, u as SelectScrollUpButton$1 } from "../_libs/@radix-ui/react-select+[...].mjs";
import { t as Root } from "../_libs/radix-ui__react-toggle.mjs";
import { n as ToggleGroupItem$1, t as ToggleGroup$1 } from "../_libs/radix-ui__react-toggle-group.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-PgRk2vth.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Select = Select$1;
var SelectValue = SelectValue$1;
var SelectTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
	ref,
	className: cn("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-50" })
	})]
}));
SelectTrigger.displayName = SelectTrigger$1.displayName;
var SelectScrollUpButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-4 w-4" })
}));
SelectScrollUpButton.displayName = SelectScrollUpButton$1.displayName;
var SelectScrollDownButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })
}));
SelectScrollDownButton.displayName = SelectScrollDownButton$1.displayName;
var SelectContent = import_react.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent$1, {
	ref,
	className: cn("relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
	position,
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
			className: cn("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton, {})
	]
}) }));
SelectContent.displayName = SelectContent$1.displayName;
var SelectLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", className),
	...props
}));
SelectLabel.displayName = SelectLabel$1.displayName;
var SelectItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
	ref,
	className: cn("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children })]
}));
SelectItem.displayName = SelectItem$1.displayName;
var SelectSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
SelectSeparator.displayName = SelectSeparator$1.displayName;
var toggleVariants = cva("inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium cursor-pointer transition-colors hover:bg-muted hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=on]:bg-accent data-[state=on]:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-transparent",
			outline: "border border-input bg-transparent shadow-sm hover:bg-accent hover:text-accent-foreground"
		},
		size: {
			default: "h-9 px-2 min-w-9",
			sm: "h-8 px-1.5 min-w-8",
			lg: "h-10 px-2.5 min-w-10"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Toggle = import_react.forwardRef(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(toggleVariants({
		variant,
		size,
		className
	})),
	...props
}));
Toggle.displayName = Root.displayName;
var ToggleGroupContext = import_react.createContext({
	size: "default",
	variant: "default"
});
var ToggleGroup = import_react.forwardRef(({ className, variant, size, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleGroup$1, {
	ref,
	className: cn("flex items-center justify-center gap-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleGroupContext.Provider, {
		value: {
			variant,
			size
		},
		children
	})
}));
ToggleGroup.displayName = ToggleGroup$1.displayName;
var ToggleGroupItem = import_react.forwardRef(({ className, children, variant, size, ...props }, ref) => {
	const context = import_react.useContext(ToggleGroupContext);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleGroupItem$1, {
		ref,
		className: cn(toggleVariants({
			variant: context.variant || variant,
			size: context.size || size
		}), className),
		...props,
		children
	});
});
ToggleGroupItem.displayName = ToggleGroupItem$1.displayName;
var THEMES = {
	light: "",
	dark: ".dark"
};
var ChartContext = import_react.createContext(null);
function useChart() {
	const context = import_react.useContext(ChartContext);
	if (!context) throw new Error("useChart must be used within a <ChartContainer />");
	return context;
}
var ChartContainer = import_react.forwardRef(({ id, className, children, config, ...props }, ref) => {
	const uniqueId = import_react.useId();
	const chartId = `chart-${id || uniqueId.replace(/:/g, "")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContext.Provider, {
		value: { config },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			"data-chart": chartId,
			ref,
			className: cn("flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-none [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-sector]:outline-none [&_.recharts-surface]:outline-none", className),
			...props,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartStyle, {
				id: chartId,
				config
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, { children })]
		})
	});
});
ChartContainer.displayName = "Chart";
var ChartStyle = ({ id, config }) => {
	const colorConfig = Object.entries(config).filter(([, config]) => config.theme || config.color);
	if (!colorConfig.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", { dangerouslySetInnerHTML: { __html: Object.entries(THEMES).map(([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig.map(([key, itemConfig]) => {
		const color = itemConfig.theme?.[theme] || itemConfig.color;
		return color ? `  --color-${key}: ${color};` : null;
	}).join("\n")}
}
`).join("\n") } });
};
var ChartTooltip = Tooltip;
var ChartTooltipContent = import_react.forwardRef(({ active, payload, className, indicator = "dot", hideLabel = false, hideIndicator = false, label, labelFormatter, labelClassName, formatter, color, nameKey, labelKey }, ref) => {
	const { config } = useChart();
	const tooltipLabel = import_react.useMemo(() => {
		if (hideLabel || !payload?.length) return null;
		const [item] = payload;
		const key = `${labelKey || item?.dataKey || item?.name || "value"}`;
		const itemConfig = getPayloadConfigFromPayload(config, item, key);
		const value = !labelKey && typeof label === "string" ? config[label]?.label || label : itemConfig?.label;
		if (labelFormatter) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("font-medium", labelClassName),
			children: labelFormatter(value, payload)
		});
		if (!value) return null;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("font-medium", labelClassName),
			children: value
		});
	}, [
		label,
		labelFormatter,
		payload,
		hideLabel,
		labelClassName,
		config,
		labelKey
	]);
	if (!active || !payload?.length) return null;
	const nestLabel = payload.length === 1 && indicator !== "dot";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: cn("grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl", className),
		children: [!nestLabel ? tooltipLabel : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-1.5",
			children: payload.filter((item) => item.type !== "none").map((item, index) => {
				const key = `${nameKey || item.name || item.dataKey || "value"}`;
				const itemConfig = getPayloadConfigFromPayload(config, item, key);
				const indicatorColor = color || item.payload.fill || item.color;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground", indicator === "dot" && "items-center"),
					children: formatter && item?.value !== void 0 && item.name ? formatter(item.value, item.name, item, index, item.payload) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [itemConfig?.icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(itemConfig.icon, {}) : !hideIndicator && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)", {
							"h-2.5 w-2.5": indicator === "dot",
							"w-1": indicator === "line",
							"w-0 border-[1.5px] border-dashed bg-transparent": indicator === "dashed",
							"my-0.5": nestLabel && indicator === "dashed"
						}),
						style: {
							"--color-bg": indicatorColor,
							"--color-border": indicatorColor
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex flex-1 justify-between leading-none", nestLabel ? "items-end" : "items-center"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [nestLabel ? tooltipLabel : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: itemConfig?.label || item.name
							})]
						}), item.value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono font-medium tabular-nums text-foreground",
							children: item.value.toLocaleString()
						})]
					})] })
				}, item.dataKey);
			})
		})]
	});
});
ChartTooltipContent.displayName = "ChartTooltip";
var ChartLegendContent = import_react.forwardRef(({ className, hideIcon = false, payload, verticalAlign = "bottom", nameKey }, ref) => {
	const { config } = useChart();
	if (!payload?.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: cn("flex items-center justify-center gap-4", verticalAlign === "top" ? "pb-3" : "pt-3", className),
		children: payload.filter((item) => item.type !== "none").map((item) => {
			const key = `${nameKey || item.dataKey || "value"}`;
			const itemConfig = getPayloadConfigFromPayload(config, item, key);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground"),
				children: [itemConfig?.icon && !hideIcon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(itemConfig.icon, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-2 w-2 shrink-0 rounded-[2px]",
					style: { backgroundColor: item.color }
				}), itemConfig?.label]
			}, item.value);
		})
	});
});
ChartLegendContent.displayName = "ChartLegend";
function getPayloadConfigFromPayload(config, payload, key) {
	if (typeof payload !== "object" || payload === null) return;
	const payloadPayload = "payload" in payload && typeof payload.payload === "object" && payload.payload !== null ? payload.payload : void 0;
	let configLabelKey = key;
	if (key in payload && typeof payload[key] === "string") configLabelKey = payload[key];
	else if (payloadPayload && key in payloadPayload && typeof payloadPayload[key] === "string") configLabelKey = payloadPayload[key];
	return configLabelKey in config ? config[configLabelKey] : config[key];
}
function Cartao({ rotulo, valor, detalhe, destaque }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("card-surface p-4", destaque && "border-warning/60 bg-warning-soft"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
				children: rotulo
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "tabular mt-1 text-2xl font-medium text-foreground",
				children: valor
			}),
			detalhe && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "tabular mt-0.5 text-xs text-muted-foreground",
				children: detalhe
			})
		]
	});
}
var kgTxt = (v) => `${numBr(v, v >= 100 ? 0 : 2)} kg`;
var media = (v, casas = 1) => v === null ? "–" : numBr(v, casas);
function Cartoes({ t }) {
	const semPeso = Math.max(t.notasSemPesoBruto, t.notasSemPesoLiquido);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Cargas",
				valor: numBr(t.cargas),
				detalhe: `${numBr(t.notas)} notas no total`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Média de notas por carga",
				valor: media(t.mediaNotasPorCarga)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Valor total",
				valor: brl(t.valor),
				detalhe: t.ticketMedio === null ? void 0 : `Ticket médio ${brl(t.ticketMedio)} por nota`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Volumes",
				valor: numBr(t.volumes),
				detalhe: `Média de ${media(t.mediaVolumesPorCarga)} por carga`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Peso bruto",
				valor: kgTxt(t.pesoBruto),
				detalhe: toneladas(t.pesoBruto)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Peso líquido",
				valor: kgTxt(t.pesoLiquido),
				detalhe: toneladas(t.pesoLiquido)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Notas de troca",
				valor: numBr(t.trocas),
				detalhe: `${pct(t.pctTrocas)} das notas`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartao, {
				rotulo: "Valor das trocas",
				valor: brl(t.valorTrocas),
				detalhe: `${pct(t.pctValorTrocas)} do valor total`
			})
		]
	}), semPeso > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-3 flex items-start gap-2 rounded-md border border-warning/60 bg-warning-soft px-3 py-2 text-sm text-warning-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0" }), t.notasSemPesoBruto === t.notasSemPesoLiquido ? `${numBr(semPeso)} nota(s) sem peso no XML ficaram de fora dos totais de peso.` : `Ficaram de fora dos totais de peso: ${numBr(t.notasSemPesoBruto)} nota(s) sem peso bruto e ${numBr(t.notasSemPesoLiquido)} sem peso líquido.`]
	})] });
}
var cfgPeso = { pesoBruto: {
	label: "Peso bruto (kg)",
	color: "var(--chart-1)"
} };
var cfgTroca = { taxaTroca: {
	label: "Taxa de troca (%)",
	color: "var(--chart-5)"
} };
var cfgCidade = {
	valor: {
		label: "Valor (R$)",
		color: "var(--chart-2)"
	},
	notas: {
		label: "Notas",
		color: "var(--chart-2)"
	}
};
function Grafico({ titulo, sub, children, acao }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex flex-wrap items-start justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-semibold text-foreground",
				children: titulo
			}), sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: sub
			})] }), acao]
		}), children]
	});
}
function Graficos({ cargas, cidades }) {
	const [criterio, setCriterio] = (0, import_react.useState)("valor");
	const serie = (0, import_react.useMemo)(() => seriePorCarga(cargas), [cargas]);
	const top = (0, import_react.useMemo)(() => topCidades(cidades, criterio), [cidades, criterio]);
	const rotuloCarga = (carga) => {
		const p = serie.find((s) => s.carga === carga);
		return p ? `Carga ${carga} · ${dataHora(p.processadaEm)}` : `Carga ${carga}`;
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 grid gap-4 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grafico, {
				titulo: "Peso bruto por carga",
				sub: "Em kg, da mais antiga para a mais recente",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
					config: cfgPeso,
					className: "aspect-auto h-64 w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: serie,
						margin: {
							left: 8,
							right: 8
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { vertical: false }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "carga",
								tickLine: false,
								axisLine: false,
								interval: "preserveStartEnd",
								minTickGap: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tickLine: false,
								axisLine: false,
								width: 56,
								tickFormatter: (v) => numBr(v)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, {
								labelFormatter: (l) => rotuloCarga(String(l)),
								formatter: (v) => v === null || v === void 0 ? "sem peso" : kgTxt(Number(v))
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "pesoBruto",
								fill: "var(--color-pesoBruto)",
								radius: [
									3,
									3,
									0,
									0
								]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grafico, {
				titulo: "Taxa de troca por carga",
				sub: "% das notas da carga que são troca",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
					config: cfgTroca,
					className: "aspect-auto h-64 w-full",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
						data: serie,
						margin: {
							left: 8,
							right: 8
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { vertical: false }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "carga",
								tickLine: false,
								axisLine: false,
								interval: "preserveStartEnd",
								minTickGap: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tickLine: false,
								axisLine: false,
								width: 44,
								tickFormatter: (v) => `${numBr(v)}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, {
								labelFormatter: (l) => rotuloCarga(String(l)),
								formatter: (v) => pct(Number(v))
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								dataKey: "taxaTroca",
								stroke: "var(--color-taxaTroca)",
								strokeWidth: 2,
								dot: { r: 3 },
								type: "monotone"
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Grafico, {
					titulo: "Top 10 cidades",
					sub: criterio === "valor" ? "Por valor das notas" : "Por quantidade de notas",
					acao: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToggleGroup, {
						type: "single",
						size: "sm",
						variant: "outline",
						value: criterio,
						onValueChange: (v) => v && setCriterio(v),
						"aria-label": "Ordenar cidades por",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleGroupItem, {
							value: "valor",
							children: "Valor"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleGroupItem, {
							value: "notas",
							children: "Nº de notas"
						})]
					}),
					children: top.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-8 text-center text-sm text-muted-foreground",
						children: "Sem notas no período."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
						config: cfgCidade,
						className: "aspect-auto w-full",
						style: { height: 36 + top.length * 30 },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: top,
							layout: "vertical",
							margin: {
								left: 8,
								right: 24
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { horizontal: false }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									type: "number",
									dataKey: criterio,
									tickLine: false,
									axisLine: false,
									tickFormatter: (v) => criterio === "valor" ? `R$ ${v.toLocaleString("pt-BR", {
										notation: "compact",
										maximumFractionDigits: 1
									})}` : numBr(v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									type: "category",
									dataKey: "cidade",
									tickLine: false,
									axisLine: false,
									width: 170
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, { formatter: (v) => criterio === "valor" ? brl(Number(v)) : `${numBr(Number(v))} notas` }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: criterio,
									fill: `var(--color-${criterio})`,
									radius: [
										0,
										3,
										3,
										0
									]
								})
							]
						})
					})
				})
			})
		]
	});
}
function Dashboard() {
	const busca = Route.useSearch();
	const navigate = useNavigate({ from: Route.fullPath });
	const periodo = intervaloPeriodo(busca.de, busca.ate);
	const { data, isLoading, isFetching, error } = useQuery({
		...dashboardQuery(periodo.de, periodo.ate),
		placeholderData: keepPreviousData
	});
	const cargas = data?.cargas ?? [];
	const cidades = data?.cidades ?? [];
	const geral = (0, import_react.useMemo)(() => totais(cargas), [cargas]);
	const recentes = (0, import_react.useMemo)(() => [...cargas].reverse(), [cargas]);
	const selecionada = cargas.find((c) => c.id === busca.carga) ?? recentes[0] ?? null;
	const daCarga = (0, import_react.useMemo)(() => selecionada ? totais([selecionada]) : null, [selecionada]);
	const cidadesDaCarga = (0, import_react.useMemo)(() => selecionada ? topCidades(cidades, "valor", 5, /* @__PURE__ */ new Set([selecionada.id])) : [], [cidades, selecionada]);
	const setBusca = (p) => navigate({
		search: (s) => {
			const novo = {
				...s,
				...p
			};
			return Object.fromEntries(Object.entries(novo).filter(([, v]) => v));
		},
		replace: true
	});
	const textoPeriodo = busca.de && busca.ate ? `de ${fmtDia(busca.de)} a ${fmtDia(busca.ate)}` : busca.de ? `a partir de ${fmtDia(busca.de)}` : busca.ate ? `até ${fmtDia(busca.ate)}` : "todo o período";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold tracking-tight text-foreground",
			children: "Dashboard"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: [
				"Cargas salvas no histórico, ",
				textoPeriodo,
				"."
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "de",
						className: "text-xs",
						children: "De"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "de",
						type: "date",
						className: "w-40",
						value: busca.de ?? "",
						max: busca.ate,
						onChange: (e) => setBusca({
							de: e.target.value || void 0,
							carga: void 0
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "ate",
						className: "text-xs",
						children: "Até"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "ate",
						type: "date",
						className: "w-40",
						value: busca.ate ?? "",
						min: busca.de,
						onChange: (e) => setBusca({
							ate: e.target.value || void 0,
							carga: void 0
						})
					})]
				}),
				(busca.de || busca.ate) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => setBusca({
						de: void 0,
						ate: void 0,
						carga: void 0
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), " Limpar período"]
				}),
				isFetching && !isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mb-2.5 size-4 animate-spin text-muted-foreground" })
			]
		})]
	}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex justify-center py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
	}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-6 rounded-md border border-destructive/30 bg-destructive-soft px-4 py-3 text-sm text-destructive",
		children: "Não foi possível carregar o dashboard. Recarregue a página."
	}) : cargas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "card-surface mt-6 px-5 py-10 text-center text-sm text-muted-foreground",
		children: busca.de || busca.ate ? "Nenhuma carga salva nesse período." : "Nenhuma carga salva ainda. Processe uma carga e salve no histórico."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "mb-3 text-lg font-semibold text-foreground",
				children: ["Geral ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-normal text-muted-foreground",
					children: "(todas as cargas)"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartoes, { t: geral }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Graficos, {
				cargas,
				cidades
			})
		]
	}), selecionada && daCarga && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-12 border-t pt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold text-foreground",
					children: "Por carga"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Processada em ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular",
							children: dataHora(selecionada.processada_em)
						}),
						" ·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/historico/$id",
							params: { id: selecionada.id },
							className: "inline-flex items-center text-primary hover:underline",
							children: ["abrir no histórico ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3.5" })]
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Carga"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: selecionada.id,
						onValueChange: (v) => setBusca({ carga: v }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-56",
							"aria-label": "Escolher carga",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: recentes.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
							value: c.id,
							children: ["Carga ", c.numero_carga]
						}, c.id)) })]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cartoes, { t: daCarga }),
			cidadesDaCarga.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-surface mt-4 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 text-sm font-semibold text-foreground",
					children: "Principais cidades da carga"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y text-sm",
					children: cidadesDaCarga.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-4 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.cidade }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular text-muted-foreground",
							children: [
								numBr(c.notas),
								" nota(s) · ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: brl(c.valor)
								})
							]
						})]
					}, c.cidade))
				})]
			})
		]
	})] })] });
}
function fmtDia(d) {
	const [a, m, dia] = d.split("-");
	return `${dia}/${m}/${a}`;
}
//#endregion
export { Dashboard as component };
