import { o as __toESM } from "../_runtime.mjs";
import { baixar } from "./exportar-CyB7YhkX.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { _ as FileStack, f as LoaderCircle, t as X, x as Download } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-UtwXV0ic.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { a as notaOrdem, n as conferirConjunto, o as ordenarPaginas, s as situacao, t as chavesDuplicadas } from "./ordenar-C3jKVwwd.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cte-CXc4splV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-primary/20", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full w-full flex-1 bg-primary transition-all",
		style: { transform: `translateX(-${100 - (value || 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
var ESTILO = {
	OK: "bg-success/15 text-success",
	"Várias notas": "bg-accent text-accent-foreground",
	"Não identificada": "bg-destructive-soft text-destructive",
	Duplicada: "bg-warning-soft text-warning-foreground"
};
function Indicador({ rotulo, valor, destaque }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("card-surface p-4", destaque && "border-warning/60 bg-warning-soft"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
			children: rotulo
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "tabular mt-1 text-2xl font-medium text-foreground",
			children: valor
		})]
	});
}
var NOME_TIPO = {
	cte: "CTe",
	nfe: "NF-e",
	boleto: "Boleto",
	outro: "Não reconhecida"
};
function ZonaPdf({ titulo, dica, arquivos, onAdicionar, onRemover }) {
	const input = (0, import_react.useRef)(null);
	const [arrastando, setArrastando] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "button",
		tabIndex: 0,
		"aria-label": titulo,
		onClick: () => input.current?.click(),
		onKeyDown: (e) => (e.key === "Enter" || e.key === " ") && input.current?.click(),
		onDragOver: (e) => {
			e.preventDefault();
			setArrastando(true);
		},
		onDragLeave: () => setArrastando(false),
		onDrop: (e) => {
			e.preventDefault();
			setArrastando(false);
			onAdicionar(e.dataTransfer.files);
		},
		className: cn("mt-4 flex min-h-28 cursor-pointer flex-col justify-center gap-3 rounded-lg border-2 border-dashed bg-card p-5 transition-colors", arrastando ? "border-primary bg-accent" : "border-input hover:border-primary/60"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: input,
				type: "file",
				accept: ".pdf,application/pdf",
				multiple: true,
				className: "hidden",
				onChange: (e) => {
					onAdicionar(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-10 items-center justify-center rounded-md bg-accent text-accent-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileStack, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold text-foreground",
					children: titulo
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: dica
				})] })]
			}),
			arquivos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-2",
				children: arquivos.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-1 rounded-md bg-secondary px-2 py-1 text-sm text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular max-w-60 truncate",
						children: f.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Remover arquivo",
						className: "rounded p-0.5 text-muted-foreground hover:text-foreground",
						onClick: (e) => {
							e.stopPropagation();
							onRemover(i);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, i))
			})
		]
	});
}
function OrganizarCte() {
	const [ctes, setCtes] = (0, import_react.useState)([]);
	const [apoio, setApoio] = (0, import_react.useState)([]);
	const arquivos = (0, import_react.useMemo)(() => [...ctes, ...apoio], [ctes, apoio]);
	const [paginas, setPaginas] = (0, import_react.useState)(null);
	const [progresso, setProgresso] = (0, import_react.useState)(null);
	const [gerando, setGerando] = (0, import_react.useState)(false);
	const [erro, setErro] = (0, import_react.useState)(null);
	function adicionar(set, lista) {
		if (!lista) return;
		const novos = [...lista].filter((f) => f.name.toLowerCase().endsWith(".pdf"));
		if (novos.length < lista.length) setErro("Só arquivos PDF são aceitos.");
		else setErro(null);
		set((a) => [...a, ...novos]);
		setPaginas(null);
	}
	async function analisar() {
		setErro(null);
		setPaginas(null);
		try {
			const { lerCtes } = await import("./pdf-CNeVtuuK.mjs");
			setPaginas(await lerCtes(arquivos, (atual, total) => setProgresso({
				atual,
				total
			}), ctes.length));
		} catch (e) {
			console.error(e);
			setErro("Não foi possível ler os PDFs. Confira se os arquivos estão corretos.");
		} finally {
			setProgresso(null);
		}
	}
	const ordem = (0, import_react.useMemo)(() => paginas ? ordenarPaginas(paginas) : [], [paginas]);
	const dup = (0, import_react.useMemo)(() => chavesDuplicadas(ordem), [ordem]);
	const avisosConjunto = (0, import_react.useMemo)(() => conferirConjunto(ordem), [ordem]);
	const cont = (0, import_react.useMemo)(() => {
		const s = ordem.map((p) => situacao(p, dup));
		return {
			identificadas: ordem.filter((p) => notaOrdem(p) !== null && p.tipo !== "outro").length,
			varias: ordem.filter((p) => p.notas.length > 1).length,
			nao: s.filter((x) => x === "Não identificada").length
		};
	}, [ordem, dup]);
	function definirManual(p, v) {
		const n = v === "" ? null : parseInt(v, 10);
		setPaginas((ps) => ps.map((x) => x === p ? {
			...x,
			manual: Number.isFinite(n) ? n : null
		} : x));
	}
	async function baixarPdf() {
		setGerando(true);
		try {
			const { gerarPdfOrdenado } = await import("./pdf-CNeVtuuK.mjs");
			baixar(await gerarPdfOrdenado(arquivos, ordem), apoio.length > 0 ? "Documentos_organizados_por_nota.pdf" : "CTEs_organizados_por_nota.pdf", "application/pdf");
		} catch (e) {
			console.error(e);
			setErro("Não foi possível gerar o PDF ordenado.");
		} finally {
			setGerando(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-3xl font-bold tracking-tight text-foreground",
			children: "Organizar CTe"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-xl text-muted-foreground",
			children: "Envie os PDFs de CTe — e, se quiser, as NF-e e os boletos — e receba um único PDF em ordem crescente pelo número da nota: CTe, NF-e e boletos de cada nota, prontos para imprimir."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZonaPdf, {
			titulo: "PDFs de CTe (DACTE)",
			dica: "Arraste um ou mais PDFs aqui ou clique para escolher",
			arquivos: ctes,
			onAdicionar: (l) => adicionar(setCtes, l),
			onRemover: (i) => {
				setCtes((a) => a.filter((_, j) => j !== i));
				setPaginas(null);
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZonaPdf, {
			titulo: "NF-e (DANFE) e boletos — opcional",
			dica: "Pode ser um PDF com nota e boletos juntos, ou PDFs separados. Cada nota entra depois do seu CTe, seguida dos boletos 1, 2, 3…",
			arquivos: apoio,
			onAdicionar: (l) => adicionar(setApoio, l),
			onRemover: (i) => {
				setApoio((a) => a.filter((_, j) => j !== i));
				setPaginas(null);
			}
		}),
		erro && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "alert",
			className: "mt-4 rounded-md border border-destructive/30 bg-destructive-soft px-4 py-3 text-sm text-destructive",
			children: erro
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex flex-wrap items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				disabled: ctes.length === 0 || !!progresso,
				onClick: analisar,
				children: [progresso && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), " Analisar e ordenar"]
			}), paginas && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "lg",
				variant: "outline",
				disabled: gerando || ordem.length === 0,
				onClick: baixarPdf,
				children: [gerando ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Baixar PDF ordenado"]
			})]
		}),
		progresso && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: progresso.atual / progresso.total * 100 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "tabular mt-2 text-sm text-muted-foreground",
				children: [
					"Lendo página ",
					progresso.atual,
					" de ",
					progresso.total
				]
			})]
		}),
		paginas && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid grid-cols-2 gap-3 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Total de páginas",
						valor: ordem.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Identificadas",
						valor: cont.identificadas
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Com várias notas",
						valor: cont.varias
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
						rotulo: "Não identificadas",
						valor: cont.nao,
						destaque: cont.nao > 0
					})
				]
			}),
			avisosConjunto.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: "mt-6 rounded-md border border-warning/60 bg-warning-soft px-4 py-3 text-sm text-warning-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: "Confira antes de imprimir:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-1 list-disc pl-5",
					children: avisosConjunto.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: a }, a))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-surface mt-6 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-secondary text-left text-xs uppercase tracking-wide text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
							"#",
							"Tipo",
							"Arquivo",
							"Pág.",
							"Notas",
							"Parcela",
							"Série",
							"Situação",
							"Nota manual"
						].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 font-medium",
							children: h
						}, h)) })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ordem.map((p, i) => {
						const s = situacao(p, dup);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-2 text-muted-foreground",
									children: i + 1
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: NOME_TIPO[p.tipo]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-48 truncate px-3 py-2",
									title: p.nomeArquivo,
									children: p.nomeArquivo
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-2",
									children: p.pagina
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-2",
									children: p.notas.join(", ") || "–"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-2",
									children: p.parcela ? `${p.parcela.n}/${p.parcela.total}` : "–"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-2",
									children: p.series.join(", ") || "–"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("rounded-full px-2 py-0.5 text-xs font-medium", ESTILO[s]),
										children: s
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-2",
									children: p.notas.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										inputMode: "numeric",
										"aria-label": `Nota manual da página ${p.pagina}`,
										className: "h-8 w-32",
										defaultValue: p.manual ?? "",
										onBlur: (e) => definirManual(p, e.target.value),
										onKeyDown: (e) => e.key === "Enter" && definirManual(p, e.currentTarget.value)
									})
								})
							]
						}, `${p.arquivo}-${p.pagina}`);
					}) })]
				})
			})
		] })
	] });
}
//#endregion
export { OrganizarCte as component };
