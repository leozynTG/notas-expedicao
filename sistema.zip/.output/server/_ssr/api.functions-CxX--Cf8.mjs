import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api.functions-CxX--Cf8.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var BOOL_NOTA = ["fracionado"];
var BOOL_REC = [
	"tem_ocorrencia",
	"lanc_kpi",
	"lanc_controle_paletes",
	"lanc_email"
];
function linha(o, bools = [], jsons = []) {
	const r = { ...o };
	for (const b of bools) if (b in r) r[b] = Boolean(r[b]);
	for (const j of jsons) if (typeof r[j] === "string") r[j] = JSON.parse(r[j]);
	return r;
}
var num = (v) => {
	if (v === null || v === void 0 || v === "") return null;
	const n = Number(v);
	return Number.isFinite(n) ? n : null;
};
var txt = (v) => v === null || v === void 0 ? "" : String(v);
var int0 = (v) => Math.trunc(num(v) ?? 0);
var buscarCargas_createServerFn_handler = createServerRpc({
	id: "c3bda7de8583cf7ad6095f945ab73ab8bf5e98461394635aa86aa6957f40cc5a",
	name: "buscarCargas",
	filename: "src/lib/api.functions.ts"
}, (opts) => buscarCargas.__executeServer(opts));
var buscarCargas = createServerFn({ method: "POST" }).inputValidator((i) => ({ termo: String(i?.termo ?? "").trim() })).handler(buscarCargas_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	const like = `%${data.termo}%`;
	return data.termo === "" ? banco().prepare("select * from cargas order by processada_em desc limit 500").all() : banco().prepare(`select c.* from cargas c
               where c.numero_carga like ?1 or exists (
                 select 1 from notas n where n.carga_id = c.id
                   and (n.nf like ?1 or n.pedido like ?1 or n.destinatario like ?1))
               order by c.processada_em desc limit 500`).all(like);
});
var lerCarga_createServerFn_handler = createServerRpc({
	id: "d81450e7fff21008e4c3d673451f075e0cc904202bbde3c4e5b86ba668c8992b",
	name: "lerCarga",
	filename: "src/lib/api.functions.ts"
}, (opts) => lerCarga.__executeServer(opts));
var lerCarga = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(lerCarga_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	const carga = banco().prepare("select * from cargas where id = ?").get(data.id);
	if (!carga) return null;
	return {
		carga,
		notas: banco().prepare("select * from notas where carga_id = ? order by rowid").all(data.id).map((n) => linha(n, BOOL_NOTA))
	};
});
var cargaExistente_createServerFn_handler = createServerRpc({
	id: "1ad621858cb1ac3542436284088b42e4d5b09142941b0e2fdb1bb05070f80347",
	name: "cargaExistente",
	filename: "src/lib/api.functions.ts"
}, (opts) => cargaExistente.__executeServer(opts));
var cargaExistente = createServerFn({ method: "POST" }).inputValidator((i) => ({ numero: String(i?.numero ?? "").trim() })).handler(cargaExistente_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	return banco().prepare("select processada_em, processada_por_email, total_notas from cargas where numero_carga = ?").get(data.numero) ?? null;
});
var salvarCarga_createServerFn_handler = createServerRpc({
	id: "7d4dd17df75127374004930d82771207d083cf937c64b66da253b2f3d41ead50",
	name: "salvarCarga",
	filename: "src/lib/api.functions.ts"
}, (opts) => salvarCarga.__executeServer(opts));
var salvarCarga = createServerFn({ method: "POST" }).inputValidator((i) => ({
	carga: i?.carga ?? {},
	notas: Array.isArray(i?.notas) ? i.notas : [],
	substituir: Boolean(i?.substituir)
})).handler(salvarCarga_createServerFn_handler, async ({ data }) => {
	const { banco, uuid } = await import("./db-Deys2qbq.mjs");
	const db = banco();
	const c = data.carga;
	const numero = txt(c["numero_carga"]).trim();
	if (!numero) throw new Error("Número da carga vazio");
	const id = uuid();
	db.exec("begin immediate");
	try {
		if (db.prepare("select id from cargas where numero_carga = ?").get(numero)) {
			if (!data.substituir) throw new Error("CARGA_JA_EXISTE");
			db.prepare("delete from cargas where numero_carga = ?").run(numero);
		}
		db.prepare(`insert into cargas (id, numero_carga, processada_em, total_notas, vendas, trocas, bonificacoes, brindes, amostras, outras,
           notas_fracionadas, notas_sem_volume, peso_liquido_total_kg, peso_bruto_total_kg)
         values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, numero, (/* @__PURE__ */ new Date()).toISOString(), int0(c["total_notas"]), int0(c["vendas"]), int0(c["trocas"]), int0(c["bonificacoes"]), int0(c["brindes"]), int0(c["amostras"]), int0(c["outras"]), int0(c["notas_fracionadas"]), int0(c["notas_sem_volume"]), num(c["peso_liquido_total_kg"]), num(c["peso_bruto_total_kg"]));
		const ins = db.prepare(`insert into notas (id, carga_id, nf, pedido, numero_troca, natureza_operacao, tipo, destinatario, cidade_uf, valor_nf, volumes,
           qtde_cx, qtde_fd, qtde_un, fracionado, especie_volume, chave_acesso, peso_liquido_kg, peso_bruto_kg)
         values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
		for (const n of data.notas) ins.run(uuid(), id, txt(n["nf"]), txt(n["pedido"]), txt(n["numero_troca"]) || null, txt(n["natureza_operacao"]), txt(n["tipo"]), txt(n["destinatario"]), txt(n["cidade_uf"]), num(n["valor_nf"]) ?? 0, num(n["volumes"]), num(n["qtde_cx"]) ?? 0, num(n["qtde_fd"]) ?? 0, num(n["qtde_un"]) ?? 0, n["fracionado"] ? 1 : 0, txt(n["especie_volume"]), txt(n["chave_acesso"]), num(n["peso_liquido_kg"]), num(n["peso_bruto_kg"]));
		db.exec("commit");
	} catch (e) {
		db.exec("rollback");
		throw e;
	}
	return id;
});
var excluirCarga_createServerFn_handler = createServerRpc({
	id: "16be09368a0e84cb8e2ce4b1a8e0c97e76f3fc09bec2bec219096afe19d0d1ec",
	name: "excluirCarga",
	filename: "src/lib/api.functions.ts"
}, (opts) => excluirCarga.__executeServer(opts));
var excluirCarga = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(excluirCarga_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	banco().prepare("delete from cargas where id = ?").run(data.id);
	return true;
});
var dashboardCargas_createServerFn_handler = createServerRpc({
	id: "af55fb3335ddc7de462123f0eabaec035ec494de569b66e070e777e53e2d3413",
	name: "dashboardCargas",
	filename: "src/lib/api.functions.ts"
}, (opts) => dashboardCargas.__executeServer(opts));
var dashboardCargas = createServerFn({ method: "POST" }).inputValidator((i) => ({
	de: i?.de ?? null,
	ate: i?.ate ?? null
})).handler(dashboardCargas_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	const db = banco();
	const filtro = "(?1 is null or c.processada_em >= ?1) and (?2 is null or c.processada_em < ?2)";
	return {
		cargas: db.prepare(`select c.id, c.numero_carga, c.processada_em,
           count(n.id) as notas,
           coalesce(sum(case when n.tipo = 'Troca' then 1 else 0 end), 0) as trocas,
           coalesce(sum(n.valor_nf), 0) as valor,
           coalesce(sum(case when n.tipo = 'Troca' then n.valor_nf else 0 end), 0) as valor_trocas,
           coalesce(sum(n.volumes), 0) as volumes,
           sum(n.peso_bruto_kg) as peso_bruto,
           sum(n.peso_liquido_kg) as peso_liquido,
           coalesce(sum(case when n.id is not null and n.peso_bruto_kg is null then 1 else 0 end), 0) as notas_sem_peso_bruto,
           coalesce(sum(case when n.id is not null and n.peso_liquido_kg is null then 1 else 0 end), 0) as notas_sem_peso_liquido
         from cargas c left join notas n on n.carga_id = c.id
         where ${filtro} group by c.id order by c.processada_em`).all(data.de, data.ate),
		cidades: db.prepare(`select n.carga_id, n.cidade_uf, count(*) as notas, coalesce(sum(n.valor_nf), 0) as valor
         from notas n join cargas c on c.id = n.carga_id where ${filtro} group by n.carga_id, n.cidade_uf`).all(data.de, data.ate)
	};
});
var CAMPOS_REC = [
	"data_chegada",
	"hora_chegada",
	"hora_inicio",
	"hora_final",
	"data_saida",
	"cliente",
	"origem",
	"motorista",
	"transportadora",
	"veiculo",
	"placa",
	"peso_kg",
	"valor",
	"transporte",
	"cubagem_m3",
	"volumes",
	"quant_nfe",
	"lacre",
	"paletes_total",
	"paletes_pbr",
	"paletes_chep",
	"paletes_descartavel",
	"paletes_quebrados",
	"tem_ocorrencia",
	"ocorrencias",
	"lanc_kpi",
	"lanc_controle_paletes",
	"lanc_email",
	"conferente",
	"assinatura_conferente",
	"assinatura_motorista"
];
var TEXTO_OBRIG = [
	"origem",
	"transportadora",
	"veiculo",
	"transporte",
	"lacre",
	"conferente"
];
function valoresRec(r) {
	return CAMPOS_REC.map((k) => {
		const v = r[k];
		if (k === "ocorrencias") return JSON.stringify(v ?? []);
		if (BOOL_REC.includes(k)) return v ? 1 : 0;
		if ((v === void 0 || v === null) && TEXTO_OBRIG.includes(k)) return "";
		return v === void 0 ? null : v;
	});
}
var LISTA_SEM_ASSINATURA = "id,criado_em,atualizado_em,criado_por,criado_por_email,data_chegada,hora_chegada,hora_inicio,hora_final,data_saida,cliente,origem,motorista,transportadora,veiculo,placa,peso_kg,valor,transporte,cubagem_m3,volumes,quant_nfe,lacre,paletes_total,paletes_pbr,paletes_chep,paletes_descartavel,paletes_quebrados,tem_ocorrencia,ocorrencias,lanc_kpi,lanc_controle_paletes,lanc_email,conferente";
var listarRecebimentos_createServerFn_handler = createServerRpc({
	id: "56bc825dd8bf5e306a51679d4eb2b5754f377fb9bef603f1111380e6dee205e2",
	name: "listarRecebimentos",
	filename: "src/lib/api.functions.ts"
}, (opts) => listarRecebimentos.__executeServer(opts));
var listarRecebimentos = createServerFn({ method: "POST" }).handler(listarRecebimentos_createServerFn_handler, async () => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	return banco().prepare(`select ${LISTA_SEM_ASSINATURA} from recebimentos order by data_chegada desc, criado_em desc`).all().map((r) => linha(r, BOOL_REC, ["ocorrencias"]));
});
var lerRecebimento_createServerFn_handler = createServerRpc({
	id: "6cce6de78506ca95c407db558bedf1b87afce0c3924c35e55a9c2d578054ceef",
	name: "lerRecebimento",
	filename: "src/lib/api.functions.ts"
}, (opts) => lerRecebimento.__executeServer(opts));
var lerRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(lerRecebimento_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	const r = banco().prepare("select * from recebimentos where id = ?").get(data.id);
	return r ? linha(r, BOOL_REC, ["ocorrencias"]) : null;
});
var criarRecebimento_createServerFn_handler = createServerRpc({
	id: "17676bf3447605e4a015301692433309a5509aa13cb836c74371c9dc6dabd116",
	name: "criarRecebimento",
	filename: "src/lib/api.functions.ts"
}, (opts) => criarRecebimento.__executeServer(opts));
var criarRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({ registro: i?.registro ?? {} })).handler(criarRecebimento_createServerFn_handler, async ({ data }) => {
	const { banco, uuid } = await import("./db-Deys2qbq.mjs");
	const id = uuid();
	const agora = (/* @__PURE__ */ new Date()).toISOString();
	banco().prepare(`insert into recebimentos (id, criado_em, atualizado_em, ${CAMPOS_REC.join(",")}) values (?,?,?,${CAMPOS_REC.map(() => "?").join(",")})`).run(id, agora, agora, ...valoresRec(data.registro));
	return id;
});
var atualizarRecebimento_createServerFn_handler = createServerRpc({
	id: "4db06652dcd8e202c61c6bf72553f3fcf656fa7e79dd4f85e7081964dbe6234d",
	name: "atualizarRecebimento",
	filename: "src/lib/api.functions.ts"
}, (opts) => atualizarRecebimento.__executeServer(opts));
var atualizarRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({
	id: String(i?.id ?? ""),
	registro: i?.registro ?? {}
})).handler(atualizarRecebimento_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	banco().prepare(`update recebimentos set atualizado_em = ?, ${CAMPOS_REC.map((k) => `${k} = ?`).join(", ")} where id = ?`).run((/* @__PURE__ */ new Date()).toISOString(), ...valoresRec(data.registro), data.id);
	return true;
});
var excluirRecebimento_createServerFn_handler = createServerRpc({
	id: "0b2820bfd52bb35eb2a3d370a4840efa9d5c5cccd8e40bcfe4e28bd27e97691d",
	name: "excluirRecebimento",
	filename: "src/lib/api.functions.ts"
}, (opts) => excluirRecebimento.__executeServer(opts));
var excluirRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(excluirRecebimento_createServerFn_handler, async ({ data }) => {
	const { banco } = await import("./db-Deys2qbq.mjs");
	banco().prepare("delete from recebimentos where id = ?").run(data.id);
	return true;
});
var baixarBackup_createServerFn_handler = createServerRpc({
	id: "832ddf203094db8d628cc9c3141f82ad90df8ab96a4ca96e3cb8bed7844a877a",
	name: "baixarBackup",
	filename: "src/lib/api.functions.ts"
}, (opts) => baixarBackup.__executeServer(opts));
var baixarBackup = createServerFn({ method: "POST" }).handler(baixarBackup_createServerFn_handler, async () => {
	const { copiaDoBanco } = await import("./db-Deys2qbq.mjs");
	return copiaDoBanco().toString("base64");
});
//#endregion
export { atualizarRecebimento_createServerFn_handler, baixarBackup_createServerFn_handler, buscarCargas_createServerFn_handler, cargaExistente_createServerFn_handler, criarRecebimento_createServerFn_handler, dashboardCargas_createServerFn_handler, excluirCarga_createServerFn_handler, excluirRecebimento_createServerFn_handler, lerCarga_createServerFn_handler, lerRecebimento_createServerFn_handler, listarRecebimentos_createServerFn_handler, salvarCarga_createServerFn_handler };
