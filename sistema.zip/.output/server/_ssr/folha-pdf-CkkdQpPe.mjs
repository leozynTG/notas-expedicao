import { o as escreverNumBr, r as dataBr } from "./dados-DGVmU1Si.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/folha-pdf-CkkdQpPe.js
/**
* Preenche o modelo oficial "Controle de Recebimento" (public/folha-recebimento.pdf) com os dados
* do registro, sem alterar o desenho. Coordenadas em pontos, medidas do próprio PDF (A4, topo = 0).
*/
var ALTURA = 841.92;
var y = (topo) => ALTURA - topo;
var CAMPO = {
	cliente: [
		103.4,
		559.5,
		208.9
	],
	origem: [
		103.4,
		559.5,
		235.5
	],
	motorista: [
		103.4,
		361.4,
		274.7
	],
	transp: [
		415.4,
		559.5,
		274.7
	],
	veiculo: [
		103.4,
		206.6,
		301.4
	],
	placa1: [
		262,
		404,
		301.4
	],
	placa2: [
		417,
		559.5,
		301.4
	],
	peso: [
		103.4,
		258.2,
		328.2
	],
	valor: [
		361.4,
		559.5,
		328.2
	],
	transporte: [
		103.4,
		309.8,
		354.9
	],
	cubagem: [
		415.4,
		559.5,
		354.9
	],
	volumes: [
		103.4,
		206.6,
		381.7
	],
	quant: [
		309.8,
		415.4,
		381.7
	],
	lacre: [
		467.1,
		559.5,
		381.7
	]
};
var DATAS = {
	chegada: {
		partes: [
			[138.5, 166.3],
			[170, 199.6],
			[203.5, 232.8]
		],
		base: 127.5
	},
	saida: {
		partes: [
			[447.1, 474.9],
			[479, 508.2],
			[512, 541.4]
		],
		base: 165.5
	}
};
var HORAS = {
	chegada: {
		partes: [[463.5, 491.4], [495.4, 523]],
		base: 127.5
	},
	inicio: {
		partes: [[105.2, 133], [137, 164.7]],
		base: 165.5
	},
	final: {
		partes: [[271.5, 299.3], [303.3, 330.9]],
		base: 165.5
	}
};
var COLUNAS = [
	35.8,
	102.9,
	257.8,
	309.4,
	415,
	559.5
];
var LINHAS_TOPO = 462.7;
var ALTURA_LINHA = 18.1;
var LINHAS_POR_PAGINA = 14;
var LOGO = {
	x0: 41.8,
	x1: 193.2,
	topo: 46.9,
	base: 91.6
};
async function gerarFolhaPdf(r) {
	const { PDFDocument, StandardFonts, rgb } = await import("../_libs/pdf-lib.mjs").then((n) => n.t);
	const baixar = async (caminho) => {
		const resp = await fetch(new URL(caminho, document.baseURI));
		if (!resp.ok) throw new Error(`Arquivo ${caminho} não encontrado (${resp.status}).`);
		return resp.arrayBuffer();
	};
	const [modelo, logo] = await Promise.all([baixar("/folha-recebimento.pdf"), baixar("/logo-cdlog.png")]);
	const saida = await PDFDocument.create();
	const [tpl] = await saida.embedPdf(await PDFDocument.load(modelo), [0]);
	const imgLogo = await saida.embedPng(logo);
	const fonte = await saida.embedFont(StandardFonts.Helvetica);
	const tinta = rgb(.05, .1, .45);
	const oc = Array.isArray(r.ocorrencias) ? r.ocorrencias : [];
	const nPaginas = Math.max(1, Math.ceil(oc.length / LINHAS_POR_PAGINA));
	for (let pg = 0; pg < nPaginas; pg++) {
		const pagina = saida.addPage([595.32, ALTURA]);
		pagina.drawPage(tpl);
		pagina.drawRectangle({
			x: LOGO.x0 - 2,
			y: y(LOGO.base + 2),
			width: LOGO.x1 - LOGO.x0 + 4,
			height: LOGO.base - LOGO.topo + 4,
			color: rgb(1, 1, 1)
		});
		const lw = LOGO.x1 - LOGO.x0;
		const lh = LOGO.base - LOGO.topo;
		const esc = Math.min(lw / imgLogo.width, lh / imgLogo.height);
		pagina.drawImage(imgLogo, {
			x: LOGO.x0,
			y: y(LOGO.base) + (lh - imgLogo.height * esc) / 2,
			width: imgLogo.width * esc,
			height: imgLogo.height * esc
		});
		const texto = (t, x0, x1, topoLinha, tam = 11, f = fonte, folga = 2.5) => {
			if (!t) return;
			let s = tam;
			while (s > 6 && f.widthOfTextAtSize(t, s) > x1 - x0 - 4) s -= .5;
			pagina.drawText(t, {
				x: x0 + 2,
				y: y(topoLinha - folga),
				size: s,
				font: f,
				color: tinta
			});
		};
		const centro = (t, x0, x1, topoBase, tam = 11) => {
			if (!t) return;
			const w = fonte.widthOfTextAtSize(t, tam);
			pagina.drawText(t, {
				x: (x0 + x1) / 2 - w / 2,
				y: y(topoBase),
				size: tam,
				font: fonte,
				color: tinta
			});
		};
		const xis = (xa, xb, topoBase) => centro("X", xa, xb, topoBase, 12);
		if (pg > 0) pagina.drawText(`Continuação — ${r.cliente} — ${r.placa} — ${dataBr(r.data_chegada)}`, {
			x: 36,
			y: y(30),
			size: 8,
			font: fonte,
			color: tinta
		});
		else {
			const n = (v, c = 0) => v === null || v === void 0 ? "" : escreverNumBr(v, c);
			const parte = (campo, t, tam) => texto(t, campo[0], campo[1], campo[2], tam);
			const data = (k, iso) => {
				if (!iso) return;
				const [a, m, d] = iso.split("-");
				[
					d,
					m,
					a
				].forEach((v, i) => centro(v ?? "", DATAS[k].partes[i][0], DATAS[k].partes[i][1], DATAS[k].base));
			};
			const hora = (k, h) => {
				const m = (h ?? "").match(/^(\d{1,2}):(\d{2})/);
				if (!m) return;
				[m[1].padStart(2, "0"), m[2]].forEach((v, i) => centro(v, HORAS[k].partes[i][0], HORAS[k].partes[i][1], HORAS[k].base));
			};
			data("chegada", r.data_chegada);
			hora("chegada", r.hora_chegada);
			hora("inicio", r.hora_inicio);
			hora("final", r.hora_final);
			data("saida", r.data_saida);
			parte(CAMPO.cliente, r.cliente);
			parte(CAMPO.origem, r.origem);
			parte(CAMPO.motorista, r.motorista);
			parte(CAMPO.transp, r.transportadora);
			parte(CAMPO.veiculo, r.veiculo);
			const placas = r.placa.split("/").map((x) => x.trim());
			parte(CAMPO.placa1, placas[0] ?? "");
			parte(CAMPO.placa2, placas[1] ?? "");
			parte(CAMPO.peso, n(r.peso_kg, 3));
			parte(CAMPO.valor, n(r.valor, 2));
			parte(CAMPO.transporte, r.transporte);
			parte(CAMPO.cubagem, n(r.cubagem_m3, 3));
			parte(CAMPO.volumes, n(r.volumes));
			parte(CAMPO.quant, n(r.quant_nfe));
			parte(CAMPO.lacre, r.lacre);
			const pal = [
				[
					r.paletes_pbr,
					139,
					167
				],
				[
					r.paletes_chep,
					201,
					229
				],
				[
					r.paletes_descartavel,
					271,
					299
				],
				[
					r.paletes_quebrados,
					391,
					419
				]
			];
			for (const [v, xa, xb] of pal) if (v !== null && v !== void 0) centro(String(v), xa, xb, 404.5);
			if (r.tem_ocorrencia) xis(287.7, 303.3, 432);
			else xis(393.4, 408.9, 432);
			if (r.lanc_kpi) xis(41.3, 53.8, 804);
			if (r.lanc_controle_paletes) xis(86.5, 102, 804);
			if (r.lanc_email) xis(227.8, 243.4, 804);
			const assina = async (dataUrl, x0, x1) => {
				if (!dataUrl) return;
				try {
					const img = dataUrl.includes("image/jpeg") ? await saida.embedJpg(dataUrl) : await saida.embedPng(dataUrl);
					const maxW = x1 - x0 - 10;
					const e = Math.min(maxW / img.width, 44 / img.height);
					pagina.drawImage(img, {
						x: (x0 + x1) / 2 - img.width * e / 2,
						y: y(753.4) + 1,
						width: img.width * e,
						height: img.height * e
					});
				} catch (e) {
					console.error("assinatura", e);
				}
			};
			await assina(r.assinatura_conferente, 34.9, 206.6);
			await assina(r.assinatura_motorista, 361.4, 560.6);
			if (r.conferente) centro(r.conferente, 34.9, 206.6, 778.5, 7);
			if (r.motorista) centro(r.motorista, 361.4, 560.6, 778.5, 7);
		}
		oc.slice(pg * LINHAS_POR_PAGINA, (pg + 1) * LINHAS_POR_PAGINA).forEach((o, i) => {
			const topoLinha = LINHAS_TOPO + ALTURA_LINHA * (i + 1);
			[
				o.codigo,
				o.produto,
				o.quant,
				o.nota,
				o.motivo
			].forEach((c, j) => {
				const t = String(c ?? "");
				if (t) texto(t, COLUNAS[j], COLUNAS[j + 1], topoLinha, 9, fonte, 4.5);
			});
		});
	}
	return saida.save();
}
/** Gera o PDF e abre numa nova aba (já no visualizador, pronto para imprimir). */
async function abrirFolhaPdf(r) {
	const bytes = await gerarFolhaPdf(r);
	const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
	if (!window.open(url, "_blank")) {
		const a = document.createElement("a");
		a.href = url;
		a.download = `controle-recebimento-${r.data_chegada}.pdf`;
		a.click();
	}
	setTimeout(() => URL.revokeObjectURL(url), 6e4);
}
//#endregion
export { abrirFolhaPdf };
