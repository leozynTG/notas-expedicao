import { i as montarPaginaApoio, r as montarPagina } from "./ordenar-C3jKVwwd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pdf-CNeVtuuK.js
/** Reads each page's text (items joined by spaces) and builds the page records. Browser-only. */
async function lerCtes(arquivos, progresso, primeiroApoio = arquivos.length) {
	const [pdfjs, worker] = await Promise.all([import("../_libs/pdfjs-dist.mjs").then((n) => n.t), import("./pdf.worker.min-BDqvoJpD.mjs")]);
	pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
	const docs = await Promise.all(arquivos.map(async (f) => pdfjs.getDocument({ data: new Uint8Array(await f.arrayBuffer()) }).promise));
	const total = docs.reduce((s, d) => s + d.numPages, 0);
	const paginas = [];
	let atual = 0;
	for (const [i, doc] of docs.entries()) for (let p = 1; p <= doc.numPages; p++) {
		progresso(++atual, total);
		const texto = (await (await doc.getPage(p)).getTextContent()).items.map((it) => it.str ?? "").join(" ");
		paginas.push((i >= primeiroApoio ? montarPaginaApoio : montarPagina)(i, arquivos[i].name, p, texto));
	}
	return paginas;
}
async function gerarPdfOrdenado(arquivos, ordem) {
	const { PDFDocument } = await import("../_libs/pdf-lib.mjs").then((n) => n.t);
	const fontes = await Promise.all(arquivos.map(async (f) => PDFDocument.load(await f.arrayBuffer(), { ignoreEncryption: true })));
	const saida = await PDFDocument.create();
	for (const p of ordem) {
		const [pg] = await saida.copyPages(fontes[p.arquivo], [p.pagina - 1]);
		saida.addPage(pg);
	}
	return saida.save();
}
//#endregion
export { gerarPdfOrdenado, lerCtes };
