import { abrirPdf } from "./pdf-texto-DYy5gAvA.mjs";
import { t as require_src } from "../_libs/tesseract.js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ocr-Bb79OMzx.js
var import_src = require_src();
/**
* Leitura por OCR do Mapa Analítico quando o PDF não tem texto legível (fontes Type 3 sem Unicode).
* Para cada página: recorta (1) o número no canto superior direito e (2) o bloco "Cliente + PEDIDO".
*/
var ESCALA = 3;
var REGS_NUMERO = [
	{
		x0: .865,
		x1: .928,
		y0: .022,
		y1: .05
	},
	{
		x0: .85,
		x1: .935,
		y0: .02,
		y1: .055
	},
	{
		x0: .86,
		x1: .931,
		y0: .024,
		y1: .048
	}
];
var REG_BLOCO = {
	x0: .04,
	x1: .66,
	y0: .088,
	y1: .162
};
function base() {
	return new URL("ocr/", document.baseURI).href;
}
async function novoWorker() {
	const b = base();
	return (0, import_src.createWorker)("eng", 1, {
		workerPath: b + "worker.min.js",
		corePath: b,
		langPath: b,
		gzip: true,
		workerBlobURL: false
	});
}
function recortar(origem, r, borda) {
	const w = origem.width;
	const h = origem.height;
	const sx = Math.floor(r.x0 * w);
	const sy = Math.floor(r.y0 * h);
	const sw = Math.ceil((r.x1 - r.x0) * w);
	const sh = Math.ceil((r.y1 - r.y0) * h);
	const c = document.createElement("canvas");
	c.width = sw + borda * 2;
	c.height = sh + borda * 2;
	const ctx = c.getContext("2d");
	ctx.fillStyle = "#fff";
	ctx.fillRect(0, 0, c.width, c.height);
	ctx.drawImage(origem, sx, sy, sw, sh, borda, borda, sw, sh);
	return c;
}
/** Apaga linhas/bordas longas (horizontais e verticais) que atrapalham a leitura dos dígitos. */
function tirarLinhas(c) {
	const ctx = c.getContext("2d");
	const img = ctx.getImageData(0, 0, c.width, c.height);
	const d = img.data;
	const escuro = (x, y) => d[(y * c.width + x) * 4] < 225;
	const linhas = [];
	const cols = [];
	for (let y = 0; y < c.height; y++) {
		let n = 0;
		for (let x = 0; x < c.width; x++) if (escuro(x, y)) n++;
		if (n > c.width * .5) linhas.push(y - 1, y, y + 1);
	}
	for (let x = 0; x < c.width; x++) {
		let n = 0;
		for (let y = 0; y < c.height; y++) if (escuro(x, y)) n++;
		if (n > c.height * .5) cols.push(x - 1, x, x + 1);
	}
	const branco = (x, y) => {
		const k = (y * c.width + x) * 4;
		d[k] = d[k + 1] = d[k + 2] = 255;
	};
	for (const y of linhas) if (y >= 0 && y < c.height) for (let x = 0; x < c.width; x++) branco(x, y);
	for (const x of cols) if (x >= 0 && x < c.width) for (let y = 0; y < c.height; y++) branco(x, y);
	for (let k = 0; k < d.length; k += 4) {
		const v = d[k] < 150 ? 0 : 255;
		d[k] = d[k + 1] = d[k + 2] = v;
	}
	ctx.putImageData(img, 0, 0);
	return c;
}
function ampliar(c, f) {
	const o = document.createElement("canvas");
	o.width = c.width * f;
	o.height = c.height * f;
	const x = o.getContext("2d");
	x.imageSmoothingQuality = "high";
	x.drawImage(c, 0, 0, o.width, o.height);
	return o;
}
/** O→0 etc. em campos que só podem ter dígitos. */
function soNumeros(s) {
	return s.replace(/[OoQD]/g, "0").replace(/[Il|]/g, "1").replace(/S/g, "5").replace(/B/g, "8").replace(/[^0-9]/g, "");
}
function interpretarBloco(texto) {
	const linhas = texto.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
	let cnpj = "";
	for (const l of linhas) {
		const m = l.match(/CNPJ\s*[.,:_]{2,}\s*:?\s*([0-9OoIl|SB.,\/\-\s]{14,24})/i) ?? l.match(/CPF\s*[.,:_]{2,}\s*:?\s*([0-9OoIl|SB.,\/\-\s]{11,18})/i);
		if (m) {
			const d = soNumeros(m[1]);
			if (d && d !== "78099777000142") {
				cnpj = d;
				break;
			}
		}
	}
	const saida = [];
	for (const l of linhas) {
		const m = l.match(/PEDIDO\b.{0,16}?[:;]\s*([0-9OoIl]{2})\s*[-–—~_]\s*([A-Za-z0-9]{3,9})\s*(?:[|Il!\]\[]\s*(.*))?$/i);
		if (m) saida.push({
			pedido: m[2].toUpperCase(),
			descricao: (m[3] ?? "").trim(),
			cnpj
		});
	}
	return saida;
}
async function lerPickingsOcr(arquivo, progresso) {
	const pdf = await abrirPdf(await arquivo.arrayBuffer());
	const wNum = await novoWorker();
	const wBloco = await novoWorker();
	await wNum.setParameters({
		tessedit_char_whitelist: "0123456789",
		tessedit_pageseg_mode: "7"
	});
	await wBloco.setParameters({ tessedit_pageseg_mode: "6" });
	const pickings = [];
	const vistos = /* @__PURE__ */ new Set();
	const avisos = [];
	let anterior = "";
	let anteriorN = 0;
	try {
		for (let i = 1; i <= pdf.numPages; i++) {
			const pg = await pdf.getPage(i);
			const vp = pg.getViewport({ scale: ESCALA });
			const canvas = document.createElement("canvas");
			canvas.width = Math.floor(vp.width);
			canvas.height = Math.floor(vp.height);
			await pg.render({
				canvasContext: canvas.getContext("2d"),
				viewport: vp,
				canvas
			}).promise;
			const rb = await wBloco.recognize(recortar(canvas, REG_BLOCO, 20));
			const cands = [];
			const noIntervalo = (c) => c === anteriorN || c === anteriorN + 1 || c > anteriorN && c <= anteriorN + 3;
			tentativas: for (const fator of [
				2,
				3,
				1.5,
				4
			]) {
				for (const reg of REGS_NUMERO) {
					const cv = ampliar(tirarLinhas(recortar(canvas, reg, 30)), fator);
					const d = ((await wNum.recognize(cv)).data.text || "").replace(/\D/g, "");
					if (d.length >= 1 && d.length <= 4) cands.push(parseInt(d, 10));
					if (cands.some(noIntervalo) && cands.length >= 2) break tentativas;
				}
				if (!anteriorN && cands.length >= 3) break;
			}
			let escolhido = cands.find((c) => c === anteriorN + 1) ?? cands.find((c) => c === anteriorN) ?? cands.filter((c) => c > anteriorN && c <= anteriorN + 3).sort((a, b) => a - b)[0];
			if (escolhido === void 0 && cands.length) {
				const freq = /* @__PURE__ */ new Map();
				for (const c of cands) freq.set(c, (freq.get(c) ?? 0) + 1);
				escolhido = [...freq.entries()].sort((a, b) => b[1] - a[1] || b[0] - a[0])[0][0];
			}
			const numero = escolhido === void 0 ? "" : String(escolhido);
			let usado = numero || anterior;
			if (numero) {
				const n = parseInt(numero, 10);
				if (anteriorN && (n < anteriorN || n > anteriorN + 1)) avisos.push({
					categoria: "Número de picking suspeito",
					nivel: "alerta",
					mensagem: `Página ${i} do mapa: número lido ${n} após ${anteriorN}. Confira o número manualmente.`
				});
				anteriorN = n;
			}
			anterior = usado;
			for (const p of interpretarBloco(rb.data.text || "")) {
				const chave = `${usado}|${p.pedido}`;
				if (vistos.has(chave)) continue;
				vistos.add(chave);
				pickings.push({
					numero: usado,
					pedido: p.pedido,
					descricao: p.descricao,
					cnpj: p.cnpj
				});
			}
			progresso?.(i, pdf.numPages);
			canvas.width = canvas.height = 0;
		}
	} finally {
		await wNum.terminate();
		await wBloco.terminate();
	}
	return {
		origem: "ocr",
		pickings,
		semTexto: false,
		avisos
	};
}
//#endregion
export { lerPickingsOcr };
