import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { f as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as cargaQuery } from "./historico-queries-DyG2ualt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/historico._id-BlyVrCrn.js
var import_jsx_runtime = require_jsx_runtime();
var $$splitComponentImporter = () => import("./historico._id-DZr4iY5r.mjs");
var Route = createFileRoute("/_authenticated/historico/$id")({
	validateSearch: (s) => typeof s["q"] === "string" && s["q"] ? { q: s["q"] } : {},
	loader: ({ context, params }) => context.queryClient.ensureQueryData(cargaQuery(params.id)),
	head: ({ loaderData }) => {
		const titulo = loaderData ? `Carga ${loaderData.carga.numero_carga} — Expedição CDLog` : "Carga — Expedição CDLog";
		return { meta: [
			{ title: titulo },
			{
				name: "description",
				content: "Notas da carga, quem processou e quando, com download da planilha."
			},
			{
				property: "og:title",
				content: titulo
			},
			{
				property: "og:description",
				content: "Detalhes de uma carga processada."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			}
		] };
	},
	pendingComponent: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex justify-center py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
	}) }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
