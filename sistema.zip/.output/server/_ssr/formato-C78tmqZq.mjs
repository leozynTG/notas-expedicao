//#region node_modules/.nitro/vite/services/ssr/assets/formato-C78tmqZq.js
var brl = (v) => v.toLocaleString("pt-BR", {
	style: "currency",
	currency: "BRL"
});
var qtd = (v) => v === 0 ? "–" : v.toLocaleString("pt-BR", { maximumFractionDigits: 4 });
var dataHora = (iso) => new Date(iso).toLocaleString("pt-BR", {
	dateStyle: "short",
	timeStyle: "short"
});
var kg = (v) => v === null ? "–" : `${v.toLocaleString("pt-BR", { maximumFractionDigits: 3 })} kg`;
var numBr = (v, casas = 0) => v.toLocaleString("pt-BR", {
	minimumFractionDigits: casas,
	maximumFractionDigits: casas
});
var pct = (v) => v === null ? "–" : `${numBr(v, 1)}%`;
var toneladas = (kgTotal) => `${numBr(kgTotal / 1e3, 2)} t`;
//#endregion
export { pct as a, numBr as i, dataHora as n, qtd as o, kg as r, toneladas as s, brl as t };
