import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { f as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as recebimentoQuery } from "./consultas-CR7OsYoG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recebimento._id-BmxIggvZ.js
var import_jsx_runtime = require_jsx_runtime();
var $$splitComponentImporter = () => import("./recebimento._id-JjGzQBbB.mjs");
var Route = createFileRoute("/_authenticated/recebimento/$id")({
	loader: ({ context, params }) => context.queryClient.ensureQueryData(recebimentoQuery(params.id)),
	head: () => ({ meta: [
		{ title: "Recebimento — Expedição CDLog" },
		{
			name: "description",
			content: "Detalhes de um recebimento de carga."
		},
		{
			property: "og:title",
			content: "Recebimento — Expedição CDLog"
		},
		{
			property: "og:description",
			content: "Detalhes de um recebimento."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	pendingComponent: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex justify-center py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
	}) }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
