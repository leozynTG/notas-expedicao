import { m as normalizarPlaca, o as escreverNumBr, p as lerNumBr } from "./dados-DGVmU1Si.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/manifesto-mmIkbTkv.js
var PARAR = /* @__PURE__ */ new Set([
	"TECNORISK",
	"GEREN",
	"RISCO",
	"AUTORIZACÃO",
	"AUTORIZAÇÃO",
	"QTDE",
	"PESO",
	"CTE",
	"CTRC"
]);
var MAIUSC = "A-ZÀ-ÖØ-Þ";
/** Lê o texto (já extraído, uma string por página) de um DAMDFE e devolve os campos do Controle de Recebimento. */
function lerManifesto(paginas) {
	const t = paginas.join(" \n ").replace(/\s+/g, " ");
	const d = {};
	const avisos = [];
	if (!/MANIFESTO ELETR/i.test(t)) avisos.push("Este PDF não parece ser um manifesto (DAMDFE).");
	const lac = t.match(new RegExp(`LACRES: ?([${MAIUSC}][${MAIUSC} .&]*?)-([\\d/ -]+?)(?= •|$)`));
	if (lac) {
		d.cliente = lac[1].trim();
		d.lacre = lac[2].trim();
	}
	const org = t.match(new RegExp(`([${MAIUSC}]+(?: [${MAIUSC}]+)*)/([A-Z]{2})\\([A-Z]{3}\\)`));
	if (org) d.origem = `${org[1]}/${org[2]}`;
	const nomes = [];
	for (const m of t.matchAll(new RegExp(`\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2} ((?:[${MAIUSC}]+ ?)+)`, "g"))) {
		const palavras = m[1].trim().split(" ");
		const corte = palavras.findIndex((p) => PARAR.has(p));
		const nome = (corte >= 0 ? palavras.slice(0, corte) : palavras).join(" ");
		if (nome && !nomes.includes(nome)) nomes.push(nome);
	}
	if (nomes.length) d.motorista = nomes.join(" / ");
	const tr = t.match(new RegExp(`([${MAIUSC}][${MAIUSC} .&]+?(?:LTDA|S\\.?A\\.?|ME|EPP))(?= |$)`));
	if (tr) d.transportadora = /^CDLOG/.test(tr[1]) ? "CDLOG" : tr[1].trim();
	let placas = [...t.matchAll(/PLACA ([A-Z]{3}\d[A-Z0-9]\d{2})\b/g)].map((m) => m[1]);
	if (placas.length === 0) placas = [...t.matchAll(/\b([A-Z]{3}\d[A-Z0-9]\d{2})\b/g)].map((m) => m[1]);
	placas = [...new Set(placas)].slice(0, 2);
	if (placas.length) d.placa = placas.map(normalizarPlaca).join(" / ");
	const tot = [...t.matchAll(/(\d+) CTRCs ([\d.]+,\d) ([\d.]+,\d) (\d+) ([\d.]+,\d{2}) ([\d.]+,\d{2}) ([\d.]+,\d{2})/g)].sort((a, b) => Number(b[1]) - Number(a[1]))[0];
	if (tot) {
		d.peso = escreverNumBr(lerNumBr(tot[2]), 3);
		d.volumes = tot[4];
		d.valor = escreverNumBr(lerNumBr(tot[5]), 2);
	} else avisos.push("Não consegui achar os totais (peso, volumes e valor) no manifesto.");
	const nf = t.match(/NOTAS FISCAIS NO MDFE: ?(\d+)/);
	if (nf) d.quant_nfe = nf[1];
	if (nomes.length) avisos.push("Confira o nome do motorista: o manifesto pode cortar nomes longos.");
	return {
		dados: d,
		avisos
	};
}
//#endregion
export { lerManifesto };
