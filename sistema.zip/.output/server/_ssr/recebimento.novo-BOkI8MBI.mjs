import { o as __toESM } from "../_runtime.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { f as LoaderCircle, j as ArrowLeft } from "../_libs/lucide-react.mjs";
import { a as criarRecebimento, t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { a as useQueryClient, r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { c as formDeRegistro, d as hojeIso, h as paraRegistro, l as formVazio } from "./dados-DGVmU1Si.mjs";
import { t as recebimentoQuery } from "./consultas-CR7OsYoG.mjs";
import { t as FormRecebimento } from "./FormRecebimento-B0pwYjiC.mjs";
import { t as Route } from "./recebimento.novo-ChMZbmTW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recebimento.novo-BOkI8MBI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NovoRecebimento() {
	const { copiar } = Route.useSearch();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [salvando, setSalvando] = (0, import_react.useState)(false);
	const origem = useQuery({
		...recebimentoQuery(copiar ?? ""),
		enabled: !!copiar
	});
	async function salvar(f) {
		setSalvando(true);
		try {
			const id = await criarRecebimento({ data: { registro: paraRegistro(f) } });
			await qc.invalidateQueries({ queryKey: ["recebimentos"] });
			toast.success("Recebimento salvo.");
			navigate({
				to: "/recebimento/$id",
				params: { id }
			});
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível salvar. O que você digitou continua na tela; tente de novo.");
		} finally {
			setSalvando(false);
		}
	}
	let inicial = formVazio();
	if (copiar) inicial = origem.data ? {
		...formDeRegistro(origem.data),
		data_chegada: hojeIso(),
		hora_chegada: "",
		hora_inicio: "",
		hora_final: "",
		data_saida: "",
		assinatura_conferente: null,
		assinatura_motorista: null,
		lanc_kpi: false,
		lanc_controle_paletes: false,
		lanc_email: false
	} : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/recebimento",
			className: "mb-4 inline-flex items-center gap-1 text-sm text-primary hover:underline",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Recebimentos"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-6 text-2xl font-bold tracking-tight text-foreground",
			children: copiar ? "Duplicar recebimento" : "Novo recebimento"
		}),
		!inicial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRecebimento, {
			inicial,
			onSalvar: salvar,
			salvando
		}, copiar ?? "novo")
	] });
}
//#endregion
export { NovoRecebimento as component };
