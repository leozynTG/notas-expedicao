import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { o as qtd, t as brl } from "./formato-C78tmqZq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/historico-C0yNNhv5.js
var import_jsx_runtime = require_jsx_runtime();
var COLUNAS = [
	"NF",
	"Pedido",
	"Nº picking",
	"Tipo",
	"Destinatário",
	"Cidade/UF",
	"Valor",
	"Vol.",
	"CX",
	"FD",
	"UN",
	"Frac."
];
function TabelaNotas({ linhas, destaque }) {
	const termo = destaque?.trim().toLowerCase() ?? "";
	const bate = (n) => termo.length > 0 && [
		n.nfTexto,
		n.pedido,
		n.destinatario
	].some((v) => v.toLowerCase().includes(termo));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "card-surface overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: COLUNAS.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "whitespace-nowrap px-3 py-2 font-medium",
					children: h
				}, h)) })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: linhas.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: cn("border-t", bate(n) && "bg-accent"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "tabular px-3 py-2",
						children: n.nfTexto
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "tabular px-3 py-2",
						children: n.pedido || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-destructive",
							children: "—"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "tabular px-3 py-2",
						children: n.numeroPicking
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-2",
						title: n.natOp,
						children: n.tipo
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "max-w-56 truncate px-3 py-2",
						title: n.destinatario,
						children: n.destinatario
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "whitespace-nowrap px-3 py-2",
						children: n.cidadeUf
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "tabular whitespace-nowrap px-3 py-2 text-right",
						children: brl(n.valor)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "tabular px-3 py-2 text-right",
						children: n.volumes ?? ""
					}),
					[
						n.qtdCx,
						n.qtdFd,
						n.qtdUn
					].map((v, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: cn("tabular px-3 py-2 text-right", n.fracionado && "bg-warning-soft"),
						children: qtd(v)
					}, j)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-3 py-2",
						children: n.fracionado ? "Sim" : "Não"
					})
				]
			}, `${n.chave}-${i}`)) })]
		})
	});
}
/** Número de carga mais frequente entre as notas (infCpl "CARGA: ..."). Vazio se nenhuma tiver. */
function sugerirNumeroCarga(notas) {
	const cont = /* @__PURE__ */ new Map();
	for (const n of notas) {
		const c = n.carga.trim();
		if (c) cont.set(c, (cont.get(c) ?? 0) + 1);
	}
	let melhor = "";
	let max = 0;
	for (const [c, q] of cont) if (q > max) {
		melhor = c;
		max = q;
	}
	return melhor;
}
/** Números de carga diferentes encontrados (para avisar quando o ZIP mistura cargas). */
function cargasDistintas(notas) {
	return Array.from(new Set(notas.map((n) => n.carga.trim()).filter(Boolean)));
}
/** Soma ignorando notas sem o campo; null quando nenhuma nota tem valor. */
function somaPesos(valores) {
	const presentes = valores.filter((v) => v !== null);
	if (presentes.length === 0) return null;
	return Math.round(presentes.reduce((s, v) => s + v, 0) * 1e4) / 1e4;
}
/** Monta só os dados extraídos (nada do XML/PDF em si) para salvar no histórico. */
function montarCarga(numero, notas) {
	const conta = (t) => notas.filter((n) => n.tipo === t).length;
	return {
		carga: {
			numero_carga: numero.trim(),
			total_notas: notas.length,
			vendas: conta("Venda"),
			trocas: conta("Troca"),
			bonificacoes: conta("Bonificação"),
			brindes: conta("Brinde"),
			amostras: conta("Amostra"),
			outras: conta("Outra saída") + conta("Outro"),
			notas_fracionadas: notas.filter((n) => n.fracionado).length,
			notas_sem_volume: notas.filter((n) => n.volumes === null).length,
			peso_bruto_total_kg: somaPesos(notas.map((n) => n.pesoBruto)),
			peso_liquido_total_kg: somaPesos(notas.map((n) => n.pesoLiquido))
		},
		notas: notas.map((n) => ({
			nf: n.nfTexto,
			pedido: n.pedido,
			numero_troca: n.numeroPicking ? n.numeroPicking : null,
			natureza_operacao: n.natOp,
			tipo: n.tipo,
			destinatario: n.destinatario,
			cidade_uf: n.cidadeUf,
			valor_nf: n.valor,
			volumes: n.volumes,
			qtde_cx: n.qtdCx,
			qtde_fd: n.qtdFd,
			qtde_un: n.qtdUn,
			fracionado: n.fracionado,
			especie_volume: n.especie,
			peso_bruto_kg: n.pesoBruto,
			peso_liquido_kg: n.pesoLiquido,
			chave_acesso: n.chave
		}))
	};
}
var numero = (v) => typeof v === "number" ? v : Number(v) || 0;
var numeroOuNulo = (v) => v === null ? null : numero(v);
/** Converte notas do histórico de volta para linhas da planilha, ordenadas por NF. */
function linhasDoHistorico(notas) {
	return notas.map((n) => {
		const nf = parseInt(n.nf, 10);
		return {
			nf: Number.isFinite(nf) ? nf : null,
			nfTexto: n.nf,
			pedido: n.pedido,
			numeroPicking: n.numero_troca ?? "",
			natOp: n.natureza_operacao,
			tipo: n.tipo,
			destinatario: n.destinatario,
			cidadeUf: n.cidade_uf,
			valor: numero(n.valor_nf),
			volumes: n.volumes === null ? null : numero(n.volumes),
			qtdCx: numero(n.qtde_cx),
			qtdFd: numero(n.qtde_fd),
			qtdUn: numero(n.qtde_un),
			fracionado: n.fracionado,
			especie: n.especie_volume,
			pesoBruto: numeroOuNulo(n.peso_bruto_kg),
			pesoLiquido: numeroOuNulo(n.peso_liquido_kg),
			chave: n.chave_acesso
		};
	}).sort((a, b) => (a.nf ?? Number.MAX_SAFE_INTEGER) - (b.nf ?? Number.MAX_SAFE_INTEGER));
}
//#endregion
export { sugerirNumeroCarga as a, montarCarga as i, cargasDistintas as n, linhasDoHistorico as r, TabelaNotas as t };
