//#region node_modules/.nitro/vite/services/ssr/assets/unrar-Co60q_tH.js
var unrar_default = "/assets/unrar-De7VYsPt.wasm";
//#endregion
export { unrar_default as default };
