import { o as __toESM } from "../_runtime.mjs";
import { n as require_lib } from "../_libs/exceljs+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/processar-CJm-LIil.js
var import_lib = /* @__PURE__ */ __toESM(require_lib());
var eh = (d, ...b) => b.every((v, i) => d[i] === v);
/** Aceita .zip ou .rar (detectado pelos primeiros bytes) e devolve sempre os bytes de um ZIP. */
async function paraZip(dados) {
	const bytes = dados instanceof Uint8Array ? dados : new Uint8Array(dados);
	if (eh(bytes, 80, 75)) return bytes;
	if (!eh(bytes, 82, 97, 114, 33)) throw new Error("Formato não reconhecido: envie um arquivo .zip ou .rar com os XMLs.");
	const [{ createExtractorFromData }, wasm] = await Promise.all([import("../_libs/node-unrar-js.mjs").then((n) => n.t), import("./unrar-Co60q_tH.mjs")]);
	const extrator = await createExtractorFromData({
		wasmBinary: await (await fetch(wasm.default)).arrayBuffer(),
		data: bytes.slice().buffer
	});
	const zip = new import_lib.default();
	for (const f of extrator.extract().files) {
		if (f.fileHeader.flags.directory || !f.extraction) continue;
		zip.file(f.fileHeader.name, f.extraction);
	}
	return zip.generateAsync({ type: "uint8array" });
}
var TIPOS = [
	"Venda",
	"Troca",
	"Brinde",
	"Amostra",
	"Bonificação",
	"Outra saída",
	"Outro"
];
/** Uppercase and strip accents so "BONIFICAÇÃO" and "BONIFICACAO" compare equal. */
function normalizar(s) {
	return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().trim();
}
function classificar(natOp, infAdFisco) {
	const nat = normalizar(natOp);
	const fisco = normalizar(infAdFisco);
	if (nat.startsWith("OUTRA SAIDA")) {
		if (fisco.includes("TROCA")) return "Troca";
		if (fisco.includes("BRINDE")) return "Brinde";
		return "Outra saída";
	}
	if (nat.includes("AMOSTRA")) return "Amostra";
	if (nat.includes("BONIFICACAO")) return "Bonificação";
	if (nat.startsWith("VENDA")) return "Venda";
	return "Outro";
}
function grupoZip(natOp) {
	const nat = normalizar(natOp);
	return nat.startsWith("OUTRA SAIDA") || nat.includes("AMOSTRA") ? "trocas_brindes_amostras" : "demais_notas";
}
function extrairPedido(infCpl) {
	return infCpl.match(/PEDIDO:\s*(\S+)/i)?.[1] ?? "";
}
function extrairCarga(infCpl) {
	return infCpl.match(/CARGA:\s*([^\s,;|]+)/i)?.[1] ?? "";
}
function arred(n) {
	return Math.round(n * 1e4) / 1e4;
}
function temDecimal(n) {
	return Math.abs(arred(n) % 1) > 0;
}
function soDigitos(s) {
	return s.replace(/\D/g, "");
}
function filhos(el, nome) {
	return Array.from(el.children).filter((c) => c.localName === nome);
}
function no(el, caminho) {
	let atual = el;
	for (const parte of caminho.split("/")) {
		if (!atual) return null;
		atual = filhos(atual, parte)[0] ?? null;
	}
	return atual;
}
function txt(el, caminho) {
	return no(el, caminho)?.textContent?.trim() ?? "";
}
function num(s) {
	const v = parseFloat(s.replace(",", "."));
	return Number.isFinite(v) ? v : 0;
}
var XmlIgnorado = class extends Error {};
function lerNfe(xml, arquivo) {
	const doc = new DOMParser().parseFromString(xml, "application/xml");
	if (doc.getElementsByTagName("parsererror").length > 0) throw new XmlIgnorado("XML inválido (não foi possível ler o arquivo)");
	const inf = doc.getElementsByTagNameNS("*", "infNFe")[0] ?? null;
	if (!inf) throw new XmlIgnorado("não é uma NF-e (sem infNFe)");
	const nfTexto = txt(inf, "ide/nNF");
	const natOp = txt(inf, "ide/natOp");
	const infCpl = txt(inf, "infAdic/infCpl");
	const infAdFisco = txt(inf, "infAdic/infAdFisco");
	const dest = no(inf, "dest");
	const mun = txt(dest, "enderDest/xMun");
	const uf = txt(dest, "enderDest/UF");
	const transp = no(inf, "transp");
	const vols = transp ? filhos(transp, "vol") : [];
	let volumes = null;
	let pesoLiquido = null;
	let pesoBruto = null;
	const especies = /* @__PURE__ */ new Set();
	for (const v of vols) {
		const q = txt(v, "qVol");
		if (q !== "") volumes = (volumes ?? 0) + num(q);
		const pl = txt(v, "pesoL");
		if (pl !== "") pesoLiquido = (pesoLiquido ?? 0) + num(pl);
		const pb = txt(v, "pesoB");
		if (pb !== "") pesoBruto = (pesoBruto ?? 0) + num(pb);
		const e = txt(v, "esp");
		if (e) especies.add(e);
	}
	const somas = {};
	for (const det of filhos(inf, "det")) {
		const prod = no(det, "prod");
		const u = normalizar(txt(prod, "uCom"));
		somas[u] = (somas[u] ?? 0) + num(txt(prod, "qCom"));
	}
	const qtdCx = arred(somas["CX"] ?? 0);
	const qtdFd = arred(somas["FD"] ?? 0);
	const qtdUn = arred(somas["UN"] ?? 0);
	const outrasUnidades = Object.keys(somas).filter((u) => ![
		"CX",
		"FD",
		"UN"
	].includes(u));
	const fracionado = Object.values(somas).some(temDecimal);
	const nfNum = parseInt(nfTexto, 10);
	return {
		arquivo,
		nf: Number.isFinite(nfNum) ? nfNum : null,
		nfTexto,
		chave: (inf.getAttribute("Id") ?? "").replace(/^NFe/i, ""),
		natOp,
		tipo: classificar(natOp, infAdFisco),
		destinatario: txt(dest, "xNome"),
		documento: soDigitos(txt(dest, "CNPJ") || txt(dest, "CPF")),
		cidadeUf: mun || uf ? `${mun}/${uf}` : "",
		valor: num(txt(inf, "total/ICMSTot/vNF")),
		pedido: extrairPedido(infCpl),
		carga: extrairCarga(infCpl),
		infAdFisco,
		volumes: volumes === null ? null : arred(volumes),
		especie: Array.from(especies).join(", "),
		pesoLiquido: pesoLiquido === null ? null : arred(pesoLiquido),
		pesoBruto: pesoBruto === null ? null : arred(pesoBruto),
		qtdCx,
		qtdFd,
		qtdUn,
		fracionado,
		outrasUnidades,
		grupoZip: grupoZip(natOp),
		numeroPicking: ""
	};
}
var RE_PEDIDO = /PEDIDO N\S+:\s*\d+-(\w+)\s*\|\s*(.+)/gi;
/** Client document: "CNPJ....:" (or "CPF....:") with two or more dots. The issuer header uses a single "CNPJ:". */
var RE_DOC_CLIENTE = /(?:CNPJ|CPF)\s*\.{2,}\s*:\s*([\d./-]+)/gi;
/** Picking number region: top 25% of the page, right half. */
var TOPO_MAX = .25;
var ESQUERDA_MIN = .5;
var TOLERANCIA_LINHA = 3;
/** Rebuilds the page text line by line from coordinates, ignoring the order pdf.js returns pieces in. */
function textoDaPagina(pagina) {
	const trechos = pagina.trechos.filter((t) => t.str.trim() !== "").sort((a, b) => a.topo - b.topo);
	const linhas = [];
	for (const t of trechos) {
		const ultima = linhas[linhas.length - 1];
		if (ultima && Math.abs(t.topo - ultima[0].topo) <= TOLERANCIA_LINHA) ultima.push(t);
		else linhas.push([t]);
	}
	return linhas.map((linha) => {
		let texto = "";
		let fim = -Infinity;
		for (const t of linha.sort((a, b) => a.x - b.x)) {
			if (texto && t.x - fim > 1) texto += " ";
			texto += t.str;
			fim = t.x + t.largura;
		}
		return texto.replace(/\s+/g, " ").trim();
	}).join("\n");
}
/** Picking number: a 1–4 digit piece in the top-right corner; the highest one wins, then the rightmost. */
function numeroNoTopo(pagina) {
	const candidatos = pagina.trechos.filter((t) => /^\d{1,4}$/.test(t.str.trim()) && t.topo <= pagina.altura * TOPO_MAX && t.x >= pagina.largura * ESQUERDA_MIN);
	candidatos.sort((a, b) => Math.abs(a.topo - b.topo) > TOLERANCIA_LINHA ? a.topo - b.topo : b.x - a.x);
	return candidatos[0]?.str.trim() ?? "";
}
function adicionar(lista, vistos, p) {
	const chave = `${p.numero}|${p.pedido}`;
	const existente = vistos.get(chave);
	if (existente) {
		if (!existente.cnpj && p.cnpj) existente.cnpj = p.cnpj;
		return;
	}
	vistos.set(chave, p);
	lista.push(p);
}
/**
* Client CNPJ/CPF (digits only) of one picking block. Only "CNPJ....:" / "CPF....:" count;
* the issuer CNPJ is always skipped, and the one on the "Nome Cliente:" line wins.
*/
function documentoCliente(texto) {
	let primeiro = "";
	for (const linha of texto.split(/\r?\n/)) for (const m of linha.matchAll(RE_DOC_CLIENTE)) {
		const doc = soDigitos(m[1] ?? "");
		if (!doc || doc === "78099777000142") continue;
		if (/Nome\s+Cliente\s*:/i.test(linha)) return doc;
		primeiro ||= doc;
	}
	return primeiro;
}
function pedidosDoTexto(texto, numero) {
	const cnpj = documentoCliente(texto);
	return Array.from(texto.matchAll(RE_PEDIDO), (m) => ({
		numero,
		pedido: (m[1] ?? "").toUpperCase(),
		descricao: (m[2] ?? "").trim(),
		cnpj
	}));
}
/**
* Reads the pickings from the PDF pages. A long picking can span several pages:
* a page without a number keeps the previous page's number, and the same
* número + pedido is counted only once.
*/
function lerPickingsPdf(paginas) {
	const pickings = [];
	const vistos = /* @__PURE__ */ new Map();
	let numeroAnterior = "";
	let temTexto = false;
	for (const pagina of paginas) {
		if (pagina.trechos.some((t) => t.str.trim() !== "")) temTexto = true;
		const numero = numeroNoTopo(pagina) || numeroAnterior;
		numeroAnterior = numero;
		for (const p of pedidosDoTexto(textoDaPagina(pagina), numero)) adicionar(pickings, vistos, p);
	}
	return {
		origem: "pdf",
		pickings,
		semTexto: !temTexto
	};
}
/** Reads the .txt export of the map: blocks start after each "IMPRESSO DIA" line; the number is the next line. */
function lerPickingsTexto(texto) {
	return {
		origem: "txt",
		pickings: lerPickings(texto),
		semTexto: texto.trim() === ""
	};
}
/** Splits the "Mapa analítico" text into blocks that start after each "IMPRESSO DIA" line. */
function lerPickings(texto) {
	const blocos = [];
	let atual = null;
	for (const linha of texto.split(/\r?\n/)) {
		if (/IMPRESSO\s+DIA/i.test(linha)) {
			atual = [];
			blocos.push(atual);
			continue;
		}
		atual?.push(linha);
	}
	const pickings = [];
	const vistos = /* @__PURE__ */ new Map();
	for (const bloco of blocos) {
		const primeira = bloco.map((l) => l.trim()).find((l) => l !== "") ?? "";
		const numero = /^\d+$/.test(primeira) ? primeira : primeira.match(/^(\d+)\b/)?.[1] ?? "";
		for (const p of pedidosDoTexto(bloco.join("\n"), numero)) adicionar(pickings, vistos, p);
	}
	return pickings;
}
/** Classes de caracteres que o OCR confunde: 0/O/Q/D, 1/I/L, 2/Z, 5/S/8/B, 9/Y. */
function classeOcr(s) {
	return s.toUpperCase().replace(/[OQD]/g, "0").replace(/[IL]/g, "1").replace(/Z/g, "2").replace(/[S8B]/g, "5").replace(/Y/g, "9");
}
function lev(a, b) {
	const d = Array.from({ length: a.length + 1 }, (_, i) => [i, ...Array(b.length).fill(0)]);
	for (let j = 1; j <= b.length; j++) d[0][j] = j;
	for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
	return d[a.length][b.length];
}
function docParecido(a, b) {
	if (!a || !b) return true;
	if (a === b) return true;
	if (Math.abs(a.length - b.length) > 1) return false;
	return lev(a, b) <= 3;
}
/**
* Fills numeroPicking on every note (any Tipo) by pedido and returns the cross-check warnings.
* tolerante=true (leitura por OCR): casa pedidos com confusões O/0 etc., desempata pelo CNPJ.
*/
function cruzarPickings(notas, pickings, tolerante = false) {
	const avisos = [];
	const porPedido = /* @__PURE__ */ new Map();
	for (const p of pickings) {
		const lista = porPedido.get(p.pedido) ?? [];
		lista.push(p);
		porPedido.set(p.pedido, lista);
	}
	const pedidosNf = new Set(notas.map((n) => n.pedido.toUpperCase()).filter(Boolean));
	const atribuicao = /* @__PURE__ */ new Map();
	if (tolerante) {
		const docOk = (p, n) => !!p.cnpj && !!n.documento && docParecido(p.cnpj, n.documento);
		const reclamados = /* @__PURE__ */ new Set();
		for (const n of notas) {
			if (!n.pedido) continue;
			const ped = n.pedido.toUpperCase();
			const t = pickings.filter((p) => p.pedido === ped && docOk(p, n));
			if (t.length) {
				atribuicao.set(n, t);
				t.forEach((p) => reclamados.add(p));
			}
		}
		for (const n of notas) {
			if (!n.pedido || atribuicao.has(n)) continue;
			const k = classeOcr(n.pedido);
			const livres = pickings.filter((p) => !reclamados.has(p) && docOk(p, n));
			let t = livres.filter((p) => classeOcr(p.pedido) === k);
			if (!t.length) {
				const dist = livres.map((p) => [lev(classeOcr(p.pedido), k), p]).filter(([d]) => d <= 1);
				const melhor = Math.min(...dist.map(([d]) => d));
				t = dist.filter(([d]) => d === melhor).map(([, p]) => p);
				if (new Set(t.map((p) => p.pedido)).size > 1) t = [];
			}
			if (t.length) {
				atribuicao.set(n, t);
				t.forEach((p) => reclamados.add(p));
			}
		}
		for (const n of notas) {
			if (!n.pedido || atribuicao.has(n)) continue;
			const k = classeOcr(n.pedido);
			const t = pickings.filter((p) => !reclamados.has(p) && classeOcr(p.pedido) === k);
			if (t.length === 1) atribuicao.set(n, t);
		}
	}
	const saida = notas.map((n) => {
		const nota = {
			...n,
			numeroPicking: ""
		};
		let achados = nota.pedido ? porPedido.get(nota.pedido.toUpperCase()) ?? [] : [];
		if (tolerante && nota.pedido) achados = atribuicao.get(n) ?? [];
		for (const p of achados) {
			const diverge = tolerante ? !docParecido(p.cnpj, nota.documento) : p.cnpj !== nota.documento;
			if (p.cnpj && nota.documento && diverge) avisos.push({
				categoria: "CNPJ divergente",
				nivel: "erro",
				mensagem: `NF ${nota.nfTexto} (pedido ${nota.pedido}): cliente no picking ${p.numero || "?"} = ${formatarDoc(p.cnpj)}; destinatário da NF = ${formatarDoc(nota.documento)}.`
			});
		}
		const ident = `NF ${nota.nfTexto} — ${nota.destinatario || "destinatário não informado"} — pedido ${nota.pedido || "não informado"}`;
		if (!nota.pedido) avisos.push({
			categoria: "Nota sem picking",
			nivel: "erro",
			mensagem: `${ident}: o XML não tem pedido para cruzar com os pickings.`
		});
		else if (achados.length === 0) avisos.push({
			categoria: "Nota sem picking",
			nivel: "erro",
			mensagem: `${ident}: pedido não encontrado nos pickings.`
		});
		else {
			const numeros = Array.from(new Set(achados.map((p) => p.numero).filter(Boolean)));
			nota.numeroPicking = numeros.join(" / ");
			if (numeros.length > 1) avisos.push({
				categoria: "Vários pickings para o mesmo pedido",
				nivel: "alerta",
				mensagem: `NF ${nota.nfTexto}: pedido ${nota.pedido} aparece nos pickings ${numeros.join(", ")}.`
			});
			if (numeros.length === 0) avisos.push({
				categoria: "Nota sem picking",
				nivel: "erro",
				mensagem: `${ident}: pedido encontrado, mas o número do picking não foi lido.`
			});
		}
		return nota;
	});
	const usados = new Set(Array.from(atribuicao.values()).flat());
	for (const [pedido, lista] of porPedido) if (!pedidosNf.has(pedido) && !(tolerante && lista.every((p) => usados.has(p)))) avisos.push({
		categoria: "Picking sem NF",
		nivel: "info",
		mensagem: `Pedido ${pedido} (picking ${lista.map((p) => p.numero || "?").join(", ")}) não tem XML nesta carga.`
	});
	return {
		notas: saida,
		avisos
	};
}
function formatarDoc(d) {
	if (d.length === 14) return d.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/, "$1.$2.$3/$4-$5");
	if (d.length === 11) return d.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, "$1.$2.$3-$4");
	return d;
}
function decodificar(bytes) {
	const enc = new TextDecoder("ascii").decode(bytes.slice(0, 200)).match(/encoding=["']([\w-]+)["']/i)?.[1]?.toLowerCase() ?? "utf-8";
	try {
		return new TextDecoder(enc).decode(bytes);
	} catch {
		return new TextDecoder("utf-8").decode(bytes);
	}
}
function resumir(notas) {
	const porTipo = Object.fromEntries(TIPOS.map((t) => [t, 0]));
	for (const n of notas) porTipo[n.tipo] += 1;
	return {
		total: notas.length,
		porTipo,
		fracionadas: notas.filter((n) => n.fracionado).length,
		semVolume: notas.filter((n) => n.volumes === null).length,
		semPedido: notas.filter((n) => !n.pedido).length,
		notasSemPicking: notas.filter((n) => !n.numeroPicking).length,
		valorTotal: notas.reduce((s, n) => s + n.valor, 0),
		noZipTrocas: notas.filter((n) => n.grupoZip === "trocas_brindes_amostras").length,
		noZipDemais: notas.filter((n) => n.grupoZip === "demais_notas").length
	};
}
async function processarCarga(zipData, leitura) {
	const zip = await import_lib.default.loadAsync(await paraZip(zipData));
	const avisos = [];
	const porChave = /* @__PURE__ */ new Map();
	const entradas = Object.values(zip.files).filter((f) => {
		if (f.dir) return false;
		const nome = f.name.split("/").pop() ?? "";
		if (f.name.startsWith("__MACOSX/") || nome.startsWith("._")) return false;
		return nome.toLowerCase().endsWith(".xml");
	});
	for (const entrada of entradas) {
		const bytes = await entrada.async("uint8array");
		try {
			const nota = lerNfe(decodificar(bytes), entrada.name);
			const chave = nota.chave || entrada.name;
			const existente = porChave.get(chave);
			if (existente) {
				avisos.push({
					categoria: "Nota repetida no ZIP",
					nivel: "alerta",
					mensagem: `NF ${nota.nfTexto} aparece em "${existente.arquivo}" e "${entrada.name}". Considerada uma vez só.`
				});
				continue;
			}
			porChave.set(chave, {
				...nota,
				bytes
			});
			if (!nota.pedido) avisos.push({
				categoria: "XML sem pedido",
				nivel: "alerta",
				mensagem: `NF ${nota.nfTexto} (${nota.destinatario}): não foi encontrado "PEDIDO:" nas informações complementares.`
			});
			if (nota.outrasUnidades.length > 0) avisos.push({
				categoria: "Unidade fora de CX/FD/UN",
				nivel: "info",
				mensagem: `NF ${nota.nfTexto}: unidade(s) ${nota.outrasUnidades.join(", ")} não somada(s) em Qtde CX/FD/UN.`
			});
		} catch (e) {
			if (!(e instanceof XmlIgnorado)) throw e;
			avisos.push({
				categoria: "Arquivo ignorado",
				nivel: "info",
				mensagem: `"${entrada.name}": ${e.message}.`
			});
		}
	}
	if (porChave.size === 0) throw new Error("Nenhum XML de NF-e foi encontrado dentro do ZIP.");
	let notas = Array.from(porChave.values()).sort((a, b) => (a.nf ?? Number.MAX_SAFE_INTEGER) - (b.nf ?? Number.MAX_SAFE_INTEGER));
	if (leitura !== null) {
		const { pickings } = leitura;
		if (leitura.semTexto) avisos.push({
			categoria: "Mapa analítico sem texto",
			nivel: "erro",
			mensagem: leitura.origem === "pdf" ? "O PDF do mapa analítico não tem texto (parece escaneado). Gere o PDF de novo pelo sistema ou envie o .txt." : "O arquivo .txt do mapa analítico está vazio."
		});
		else if (pickings.length === 0) avisos.push({
			categoria: "Nenhum pedido no mapa analítico",
			nivel: "erro",
			mensagem: "Nenhuma linha \"PEDIDO NÚMERO: 01-… | …\" foi encontrada no mapa analítico."
		});
		const semNumero = pickings.filter((p) => !p.numero);
		if (semNumero.length > 0) avisos.push({
			categoria: "Picking sem número",
			nivel: "alerta",
			mensagem: `Pedido(s) ${semNumero.map((p) => p.pedido).join(", ")}: o número do picking não foi encontrado no topo da página.`
		});
		if (leitura.avisos) avisos.push(...leitura.avisos);
		const cruzado = cruzarPickings(notas, pickings, leitura.origem === "ocr");
		const bytesPorArquivo = new Map(notas.map((n) => [n.arquivo, n.bytes]));
		notas = cruzado.notas.map((n) => ({
			...n,
			bytes: bytesPorArquivo.get(n.arquivo)
		}));
		avisos.push(...cruzado.avisos);
	} else avisos.push({
		categoria: "Pickings",
		nivel: "info",
		mensagem: "O mapa analítico não foi enviado, então as notas ficaram sem número de picking."
	});
	const mapa = leitura && {
		origem: leitura.origem,
		semTexto: leitura.semTexto,
		pickings: leitura.pickings
	};
	return {
		notas,
		avisos,
		resumo: resumir(notas),
		mapa
	};
}
//#endregion
export { lerPickingsTexto as n, processarCarga, TIPOS as r, lerPickingsPdf as t };
