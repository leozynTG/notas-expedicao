//#region node_modules/.nitro/vite/services/ssr/assets/ordenar-C3jKVwwd.js
/** Pure rules for sorting CTe (DACTE) pages by NF-e number. */
function dvChaveValido(chave) {
	if (!/^\d{44}$/.test(chave)) return false;
	let soma = 0;
	let peso = 2;
	for (let i = 42; i >= 0; i--) {
		soma += Number(chave[i]) * peso;
		peso = peso === 9 ? 2 : peso + 1;
	}
	const resto = soma % 11;
	return (resto < 2 ? 0 : 11 - resto) === Number(chave[43]);
}
function chaveValida(chave) {
	return chave.substring(20, 22) === "55" && dvChaveValido(chave);
}
var numeroNota = (chave) => parseInt(chave.substring(25, 34), 10);
var serieNota = (chave) => chave.substring(22, 25);
/** Valid, unique NF-e keys found in one page's text. */
function chavesDaPagina(texto) {
	const candidatas = [];
	for (const m of texto.matchAll(/NF-?E:\s*([\d ]{44,70})/gi)) {
		const d = (m[1] ?? "").replace(/\D/g, "");
		if (d.length >= 44) candidatas.push(d.slice(0, 44));
	}
	let validas = [...new Set(candidatas)].filter(chaveValida);
	if (candidatas.length === 0) {
		const gerais = [...texto.matchAll(/(?:\d[ .]?){44}/g)].map((m) => m[0].replace(/\D/g, ""));
		validas = [...new Set(gerais)].filter((c) => c.length === 44 && chaveValida(c));
	}
	return validas;
}
function montarPagina(arquivo, nomeArquivo, pagina, texto) {
	const chaves = chavesDaPagina(texto);
	return {
		tipo: "cte",
		parcela: null,
		arquivo,
		nomeArquivo,
		pagina,
		chaves,
		notas: [...new Set(chaves.map(numeroNota))].sort((a, b) => a - b),
		series: [...new Set(chaves.map(serieNota))],
		manual: null
	};
}
/** Página de NF-e (DANFE) ou boleto: descobre o tipo e o número da nota pelo texto. */
function montarPaginaApoio(arquivo, nomeArquivo, pagina, texto) {
	const base = {
		tipo: "outro",
		parcela: null,
		arquivo,
		nomeArquivo,
		pagina,
		chaves: [],
		notas: [],
		series: [],
		manual: null
	};
	if (/DANFE/i.test(texto) && /CHAVE\s+DE\s+ACESSO/i.test(texto)) {
		const gerais = [...texto.matchAll(/(?:\d[ .]?){44}/g)].map((m) => m[0].replace(/\D/g, ""));
		const chave = [...new Set(gerais)].find((c) => c.length === 44 && chaveValida(c));
		if (chave) return {
			...base,
			tipo: "nfe",
			notas: [numeroNota(chave)],
			series: [serieNota(chave)]
		};
		const m = texto.match(/N[º°o]\.?\s*(\d{3}\.\d{3}\.\d{3})/i);
		if (m) return {
			...base,
			tipo: "nfe",
			notas: [parseInt(m[1].replace(/\./g, ""), 10)]
		};
		return {
			...base,
			tipo: "nfe"
		};
	}
	const frac = texto.match(/\d{2}\/\d{2}\/\d{4}\s+(\d{1,9})\s+(\d{1,2})\s*\/\s*(\d{1,2})\b/);
	if (frac && /N[uú]mero\s+do\s+Documento/i.test(texto)) return {
		...base,
		tipo: "boleto",
		notas: [parseInt(frac[1], 10)],
		parcela: {
			n: parseInt(frac[2], 10),
			total: parseInt(frac[3], 10)
		}
	};
	if (/N[uú]mero\s+do\s+Documento/i.test(texto) && /Vencimento/i.test(texto)) {
		const unico = texto.match(/\d{2}\/\d{2}\/\d{4}\s+(\d{3,9})\s+[A-Za-z]{2}\b/);
		return {
			...base,
			tipo: "boleto",
			notas: unico ? [parseInt(unico[1], 10)] : [],
			parcela: unico ? {
				n: 1,
				total: 1
			} : null
		};
	}
	return base;
}
var RANK = {
	cte: 0,
	nfe: 1,
	outro: 1,
	boleto: 2
};
var notaOrdem = (p) => p.notas[0] ?? p.manual;
var notasDe = (p) => p.notas.length > 0 ? p.notas : p.manual !== null ? [p.manual] : [];
/** CTe com várias notas (mesmo destinatário): cada nota aponta para a menor nota do grupo. */
function gruposDeNotas(paginas) {
	const pai = /* @__PURE__ */ new Map();
	const raiz = (n) => {
		let r = n;
		while (pai.has(r) && pai.get(r) !== r) r = pai.get(r);
		return r;
	};
	for (const p of paginas) {
		if (p.tipo !== "cte") continue;
		const ns = notasDe(p);
		for (const n of ns) if (!pai.has(n)) pai.set(n, n);
		for (const n of ns.slice(1)) {
			const ra = raiz(ns[0]);
			const rb = raiz(n);
			if (ra !== rb) pai.set(Math.max(ra, rb), Math.min(ra, rb));
		}
	}
	return new Map([...pai.keys()].map((n) => [n, raiz(n)]));
}
function ordenarPaginas(paginas) {
	const grupo = gruposDeNotas(paginas);
	const chave = (p) => {
		const n = notaOrdem(p);
		return n === null ? null : grupo.get(n) ?? n;
	};
	return [...paginas].sort((a, b) => {
		const ga = chave(a);
		const gb = chave(b);
		if (ga === null && gb !== null) return 1;
		if (gb === null && ga !== null) return -1;
		if (ga !== null && gb !== null && ga !== gb) return ga - gb;
		const na = notaOrdem(a);
		const nb = notaOrdem(b);
		if (a.tipo === "cte" && b.tipo !== "cte") return -1;
		if (b.tipo === "cte" && a.tipo !== "cte") return 1;
		if (na !== null && nb !== null && na !== nb) return na - nb;
		return RANK[a.tipo] - RANK[b.tipo] || (a.parcela?.n ?? 0) - (b.parcela?.n ?? 0) || a.arquivo - b.arquivo || a.pagina - b.pagina;
	});
}
/** Keys that appear on more than one page. */
function chavesDuplicadas(paginas) {
	const vistas = /* @__PURE__ */ new Map();
	for (const p of paginas) for (const c of p.chaves) vistas.set(c, (vistas.get(c) ?? 0) + 1);
	return new Set([...vistas].filter(([, n]) => n > 1).map(([c]) => c));
}
function situacao(p, duplicadas) {
	if (p.chaves.length === 0 && notaOrdem(p) === null) return "Não identificada";
	if (p.chaves.some((c) => duplicadas.has(c))) return "Duplicada";
	return p.notas.length > 1 ? "Várias notas" : "OK";
}
/** Avisos de conferência quando há NF-e/boletos junto com os CTe. */
function conferirConjunto(paginas) {
	if (!paginas.some((p) => p.tipo !== "cte")) return [];
	const avisos = [];
	const notas = [...new Set(paginas.flatMap(notasDe))].sort((a, b) => a - b);
	for (const n of notas) {
		const doNota = paginas.filter((p) => notasDe(p).includes(n));
		const tem = (t) => doNota.some((p) => p.tipo === t);
		if (!tem("cte")) avisos.push(`Nota ${n}: não tem CTe.`);
		if (!tem("nfe")) avisos.push(`Nota ${n}: não tem a NF-e.`);
		const bol = doNota.filter((p) => p.tipo === "boleto");
		const total = Math.max(0, ...bol.map((p) => p.parcela?.total ?? 0));
		const achadas = new Set(bol.map((p) => p.parcela?.n ?? 0));
		if (bol.length === 0) avisos.push(`Nota ${n}: nenhum boleto encontrado.`);
		else if (achadas.size < total) {
			const faltam = Array.from({ length: total }, (_, i) => i + 1).filter((i) => !achadas.has(i));
			avisos.push(`Nota ${n}: faltam os boletos ${faltam.map((i) => `${i}/${total}`).join(", ")}.`);
		}
		if (bol.length > achadas.size) avisos.push(`Nota ${n}: há boleto repetido.`);
	}
	return avisos;
}
//#endregion
export { notaOrdem as a, montarPaginaApoio as i, conferirConjunto as n, ordenarPaginas as o, montarPagina as r, situacao as s, chavesDuplicadas as t };
