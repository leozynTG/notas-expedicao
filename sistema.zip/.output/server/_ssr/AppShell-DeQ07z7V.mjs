import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-D2sbC9aE.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { _ as FileStack, d as PackagePlus, h as History, i as ShieldCheck, p as LayoutDashboard, w as ClipboardCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AppShell-DeQ07z7V.js
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var buscarCargas = createServerFn({ method: "POST" }).inputValidator((i) => ({ termo: String(i?.termo ?? "").trim() })).handler(createSsrRpc("c3bda7de8583cf7ad6095f945ab73ab8bf5e98461394635aa86aa6957f40cc5a"));
var lerCarga = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(createSsrRpc("d81450e7fff21008e4c3d673451f075e0cc904202bbde3c4e5b86ba668c8992b"));
var cargaExistente = createServerFn({ method: "POST" }).inputValidator((i) => ({ numero: String(i?.numero ?? "").trim() })).handler(createSsrRpc("1ad621858cb1ac3542436284088b42e4d5b09142941b0e2fdb1bb05070f80347"));
var salvarCarga = createServerFn({ method: "POST" }).inputValidator((i) => ({
	carga: i?.carga ?? {},
	notas: Array.isArray(i?.notas) ? i.notas : [],
	substituir: Boolean(i?.substituir)
})).handler(createSsrRpc("7d4dd17df75127374004930d82771207d083cf937c64b66da253b2f3d41ead50"));
var excluirCarga = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(createSsrRpc("16be09368a0e84cb8e2ce4b1a8e0c97e76f3fc09bec2bec219096afe19d0d1ec"));
var dashboardCargas = createServerFn({ method: "POST" }).inputValidator((i) => ({
	de: i?.de ?? null,
	ate: i?.ate ?? null
})).handler(createSsrRpc("af55fb3335ddc7de462123f0eabaec035ec494de569b66e070e777e53e2d3413"));
var listarRecebimentos = createServerFn({ method: "POST" }).handler(createSsrRpc("56bc825dd8bf5e306a51679d4eb2b5754f377fb9bef603f1111380e6dee205e2"));
var lerRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(createSsrRpc("6cce6de78506ca95c407db558bedf1b87afce0c3924c35e55a9c2d578054ceef"));
var criarRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({ registro: i?.registro ?? {} })).handler(createSsrRpc("17676bf3447605e4a015301692433309a5509aa13cb836c74371c9dc6dabd116"));
var atualizarRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({
	id: String(i?.id ?? ""),
	registro: i?.registro ?? {}
})).handler(createSsrRpc("4db06652dcd8e202c61c6bf72553f3fcf656fa7e79dd4f85e7081964dbe6234d"));
var excluirRecebimento = createServerFn({ method: "POST" }).inputValidator((i) => ({ id: String(i?.id ?? "") })).handler(createSsrRpc("0b2820bfd52bb35eb2a3d370a4840efa9d5c5cccd8e40bcfe4e28bd27e97691d"));
var baixarBackup = createServerFn({ method: "POST" }).handler(createSsrRpc("832ddf203094db8d628cc9c3141f82ad90df8ab96a4ca96e3cb8bed7844a877a"));
var ABA = "inline-flex items-center gap-2 border-b-[3px] border-transparent px-1 pb-3 pt-1 text-xs font-semibold uppercase tracking-wider text-blue-100/80 transition-colors hover:text-white";
var ABA_ATIVA = "border-brand-yellow text-white";
async function backup() {
	try {
		const b64 = await baixarBackup();
		const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
		const url = URL.createObjectURL(new Blob([bytes], { type: "application/octet-stream" }));
		const a = document.createElement("a");
		a.href = url;
		a.download = `expedicao-backup-${(/* @__PURE__ */ new Date()).toLocaleDateString("sv-SE")}.db`;
		a.click();
		setTimeout(() => URL.revokeObjectURL(url), 3e4);
	} catch (e) {
		console.error(e);
		toast.error("Não foi possível gerar o backup.");
	}
}
function AppShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "border-b-4 border-brand-yellow bg-brand-blue text-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-6xl px-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/logo-cdlog.png",
							alt: "CDlog — Sua entrega sempre na frente",
							className: "h-12 w-auto rounded-lg bg-white px-3 py-1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-lg font-bold leading-tight tracking-tight text-white",
							children: "Expedição CDLog"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-blue-100/80",
							children: "Conferência de notas da carga"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex gap-6",
						"aria-label": "Seções",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: ABA,
								activeProps: { className: ABA_ATIVA },
								activeOptions: { exact: true },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackagePlus, { className: "size-4" }), " Nova carga"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/historico",
								className: ABA,
								activeProps: { className: ABA_ATIVA },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-4" }), " Histórico"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/dashboard",
								className: ABA,
								activeProps: { className: ABA_ATIVA },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-4" }), " Dashboard"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/cte",
								className: ABA,
								activeProps: { className: ABA_ATIVA },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileStack, { className: "size-4" }), " Organizar CTe"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/recebimento",
								className: ABA,
								activeProps: { className: ABA_ATIVA },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "size-4" }), " Recebimento"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-auto hidden items-center gap-1.5 pb-3 text-xs text-blue-100/80 md:flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4 text-brand-yellow" }), "XML e PDF não saem do seu computador"]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-6xl px-5 py-10",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-10 border-t-4 border-brand-green bg-brand-navy px-5 py-4 text-center text-xs text-blue-100/80",
				children: [
					"CDLog Logística • Sua entrega sempre na frente •",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: backup,
						className: "underline underline-offset-2 hover:text-white",
						children: "Baixar backup dos dados"
					})
				]
			})
		]
	});
}
//#endregion
export { criarRecebimento as a, excluirRecebimento as c, listarRecebimentos as d, salvarCarga as f, cargaExistente as i, lerCarga as l, atualizarRecebimento as n, dashboardCargas as o, buscarCargas as r, excluirCarga as s, AppShell as t, lerRecebimento as u };
