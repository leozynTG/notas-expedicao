//#region node_modules/.nitro/vite/services/ssr/assets/dados-DGVmU1Si.js
/** "2.435,2" → 2435.2 ; "" → null ; inválido → NaN */
function lerNumBr(s) {
	const t = s.trim().replace(/\s/g, "").replace(/^R\$/i, "");
	if (t === "") return null;
	let norm;
	if (t.includes(",")) norm = t.replace(/\./g, "").replace(",", ".");
	else if (/^\d{1,3}(\.\d{3})+$/.test(t)) norm = t.replace(/\./g, "");
	else norm = t;
	if (!/^-?\d+(\.\d+)?$/.test(norm)) return NaN;
	return Number(norm);
}
function lerInteiro(s) {
	const t = s.trim();
	if (t === "") return null;
	return /^\d+$/.test(t) ? Number(t) : NaN;
}
function escreverNumBr(v, casas = 2) {
	if (v === null || v === void 0 || !Number.isFinite(v)) return "";
	return v.toLocaleString("pt-BR", {
		minimumFractionDigits: 0,
		maximumFractionDigits: casas
	});
}
function placaUma(s) {
	const t = s.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 7);
	return t.length > 3 ? `${t.slice(0, 3)}-${t.slice(3)}` : t;
}
/** Aceita uma ou duas placas (cavalo / carreta), separadas por "/". */
function normalizarPlaca(s) {
	const limpo = s.toUpperCase();
	let partes = limpo.split(/[/,;]/);
	if (partes.length === 1) {
		const t = limpo.replace(/[^A-Z0-9]/g, "");
		partes = t.length > 7 ? [t.slice(0, 7), t.slice(7, 14)] : [t];
	}
	return partes.slice(0, 2).map(placaUma).join(" / ");
}
/** AAA-0A00 (Mercosul) ou AAA-0000 (antiga); hífen opcional. Aceita duas placas separadas por "/". */
function placaValida(s) {
	const partes = s.split("/").map((x) => x.trim().toUpperCase());
	return partes.length <= 2 && partes.every((x) => /^[A-Z]{3}-?\d[A-Z0-9]\d{2}$/.test(x));
}
function minutos(h) {
	const m = h.match(/^(\d{1,2}):(\d{2})$/);
	if (!m) return null;
	return Number(m[1]) * 60 + Number(m[2]);
}
/** Duração em minutos (hora final - hora início); null se faltar hora ou se final < início. */
function duracaoDescarga(inicio, fim) {
	const a = minutos(inicio);
	const b = minutos(fim);
	if (a === null || b === null || b < a) return null;
	return b - a;
}
function finalAntesDoInicio(inicio, fim) {
	const a = minutos(inicio);
	const b = minutos(fim);
	return a !== null && b !== null && b < a;
}
function formatarDuracao(min) {
	if (min === null) return "–";
	const h = Math.floor(min / 60);
	const m = min % 60;
	return `${h}h${String(m).padStart(2, "0")}`;
}
function somaPaletes(p) {
	return (p.pbr ?? 0) + (p.chep ?? 0) + (p.descartavel ?? 0) + (p.quebrados ?? 0);
}
/** Mensagem de aviso, ou null se bate (ou se nada foi informado). */
function avisoPaletes(p) {
	const soma = somaPaletes(p);
	const algum = [
		p.pbr,
		p.chep,
		p.descartavel,
		p.quebrados
	].some((v) => v !== null);
	if (p.total === null && !algum) return null;
	const total = p.total ?? 0;
	if (soma === total) return null;
	return `A soma dos tipos (${soma}) não bate com o total (${total})`;
}
var MOTIVOS = [
	"Falta",
	"Avaria",
	"Sobra",
	"Troca",
	"Outro"
];
/** Totais para preencher o formulário a partir dos XMLs. */
function resumoXml(notas) {
	const comPeso = notas.filter((n) => n.pesoBruto !== null);
	const comVol = notas.filter((n) => n.volumes !== null);
	const ufs = new Set(notas.map((n) => n.cidadeUf.split("/")[1] ?? "").filter(Boolean));
	return {
		quantNfe: notas.length,
		valor: Math.round(notas.reduce((s, n) => s + n.valor, 0) * 100) / 100,
		peso: comPeso.length ? Math.round(comPeso.reduce((s, n) => s + (n.pesoBruto ?? 0), 0) * 1e3) / 1e3 : null,
		volumes: comVol.length ? Math.round(comVol.reduce((s, n) => s + (n.volumes ?? 0), 0)) : null,
		semPeso: notas.length - comPeso.length,
		semVolume: notas.length - comVol.length,
		origem: ufs.size === 1 ? [...ufs][0] : ""
	};
}
function hojeIso() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function formVazio() {
	return {
		data_chegada: hojeIso(),
		hora_chegada: "",
		hora_inicio: "",
		hora_final: "",
		data_saida: "",
		cliente: "",
		origem: "",
		motorista: "",
		transportadora: "",
		veiculo: "",
		placa: "",
		peso: "",
		valor: "",
		transporte: "",
		cubagem: "",
		volumes: "",
		quant_nfe: "",
		lacre: "",
		paletes_total: "",
		paletes_pbr: "",
		paletes_chep: "",
		paletes_descartavel: "",
		paletes_quebrados: "",
		tem_ocorrencia: false,
		ocorrencias: [],
		lanc_kpi: false,
		lanc_controle_paletes: false,
		lanc_email: false,
		conferente: "",
		assinatura_conferente: null,
		assinatura_motorista: null
	};
}
var int = (v) => v === null ? "" : String(v);
function formDeRegistro(r) {
	return {
		data_chegada: r.data_chegada,
		hora_chegada: r.hora_chegada ?? "",
		hora_inicio: r.hora_inicio ?? "",
		hora_final: r.hora_final ?? "",
		data_saida: r.data_saida ?? "",
		cliente: r.cliente,
		origem: r.origem,
		motorista: r.motorista,
		transportadora: r.transportadora,
		veiculo: r.veiculo,
		placa: r.placa,
		peso: escreverNumBr(r.peso_kg, 3),
		valor: escreverNumBr(r.valor, 2),
		transporte: r.transporte,
		cubagem: escreverNumBr(r.cubagem_m3, 3),
		volumes: int(r.volumes),
		quant_nfe: int(r.quant_nfe),
		lacre: r.lacre,
		paletes_total: int(r.paletes_total),
		paletes_pbr: int(r.paletes_pbr),
		paletes_chep: int(r.paletes_chep),
		paletes_descartavel: int(r.paletes_descartavel),
		paletes_quebrados: int(r.paletes_quebrados),
		tem_ocorrencia: r.tem_ocorrencia,
		ocorrencias: Array.isArray(r.ocorrencias) ? r.ocorrencias : [],
		lanc_kpi: r.lanc_kpi,
		lanc_controle_paletes: r.lanc_controle_paletes,
		lanc_email: r.lanc_email,
		conferente: r.conferente,
		assinatura_conferente: r.assinatura_conferente,
		assinatura_motorista: r.assinatura_motorista
	};
}
/** Erros que impedem salvar. */
function validar(f) {
	const e = [];
	if (!f.data_chegada) e.push("Informe a data da chegada.");
	if (!f.cliente.trim()) e.push("Informe o cliente.");
	if (!f.motorista.trim()) e.push("Informe o motorista.");
	if (!f.placa.trim()) e.push("Informe a placa.");
	else if (!placaValida(f.placa)) e.push("Placa inválida (use AAA-0A00 ou AAA-0000; para duas placas separe com /).");
	const vol = lerInteiro(f.volumes);
	if (vol === null) e.push("Informe os volumes.");
	const nums = [
		["Peso", lerNumBr(f.peso)],
		["Valor da carga", lerNumBr(f.valor)],
		["Cubagem", lerNumBr(f.cubagem)]
	];
	const ints = [
		["Volumes", vol],
		["Quant. NF-e", lerInteiro(f.quant_nfe)],
		["Total de paletes", lerInteiro(f.paletes_total)],
		["PBR", lerInteiro(f.paletes_pbr)],
		["CHEP", lerInteiro(f.paletes_chep)],
		["Descartável", lerInteiro(f.paletes_descartavel)],
		["Quebrados", lerInteiro(f.paletes_quebrados)]
	];
	for (const [n, v] of nums) if (Number.isNaN(v)) e.push(`${n}: número inválido (ex.: 2.435,2).`);
	for (const [n, v] of ints) if (Number.isNaN(v)) e.push(`${n}: use um número inteiro.`);
	if (finalAntesDoInicio(f.hora_inicio, f.hora_final)) e.push("A hora final da descarga é antes da hora início.");
	if (f.tem_ocorrencia && f.ocorrencias.length === 0) e.push("Ocorrências marcadas como \"Sim\", mas nenhuma linha foi adicionada.");
	return e;
}
function paraRegistro(f) {
	const n = (s) => lerNumBr(s);
	const i = (s) => lerInteiro(s);
	return {
		data_chegada: f.data_chegada,
		hora_chegada: f.hora_chegada || null,
		hora_inicio: f.hora_inicio || null,
		hora_final: f.hora_final || null,
		data_saida: f.data_saida || null,
		cliente: f.cliente.trim(),
		origem: f.origem.trim(),
		motorista: f.motorista.trim(),
		transportadora: f.transportadora.trim(),
		veiculo: f.veiculo.trim(),
		placa: f.placa.trim().toUpperCase(),
		peso_kg: n(f.peso),
		valor: n(f.valor),
		transporte: f.transporte.trim(),
		cubagem_m3: n(f.cubagem),
		volumes: i(f.volumes) ?? 0,
		quant_nfe: i(f.quant_nfe),
		lacre: f.lacre.trim(),
		paletes_total: i(f.paletes_total),
		paletes_pbr: i(f.paletes_pbr),
		paletes_chep: i(f.paletes_chep),
		paletes_descartavel: i(f.paletes_descartavel),
		paletes_quebrados: i(f.paletes_quebrados),
		tem_ocorrencia: f.tem_ocorrencia,
		ocorrencias: f.tem_ocorrencia ? f.ocorrencias : [],
		lanc_kpi: f.lanc_kpi,
		lanc_controle_paletes: f.lanc_controle_paletes,
		lanc_email: f.lanc_email,
		conferente: f.conferente.trim(),
		assinatura_conferente: f.assinatura_conferente,
		assinatura_motorista: f.assinatura_motorista,
		atualizado_em: (/* @__PURE__ */ new Date()).toISOString()
	};
}
var duracaoRegistro = (r) => duracaoDescarga(r.hora_inicio ?? "", r.hora_final ?? "");
var dataBr = (iso) => iso ? iso.split("-").reverse().join("/") : "";
//#endregion
export { somaPaletes as _, duracaoRegistro as a, formDeRegistro as c, hojeIso as d, lerInteiro as f, resumoXml as g, paraRegistro as h, duracaoDescarga as i, formVazio as l, normalizarPlaca as m, avisoPaletes as n, escreverNumBr as o, lerNumBr as p, dataBr as r, finalAntesDoInicio as s, MOTIVOS as t, formatarDuracao as u, validar as v };
