import { d as listarRecebimentos, u as lerRecebimento } from "./AppShell-DeQ07z7V.mjs";
import { t as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/consultas-CR7OsYoG.js
var recebimentosQuery = queryOptions({
	queryKey: ["recebimentos", "lista"],
	queryFn: async () => await listarRecebimentos()
});
var recebimentoQuery = (id) => queryOptions({
	queryKey: [
		"recebimentos",
		"detalhe",
		id
	],
	queryFn: async () => await lerRecebimento({ data: { id } })
});
//#endregion
export { recebimentosQuery as n, recebimentoQuery as t };
