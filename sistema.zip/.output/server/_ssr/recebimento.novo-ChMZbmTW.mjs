import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recebimento.novo-ChMZbmTW.js
var $$splitComponentImporter = () => import("./recebimento.novo-BOkI8MBI.mjs");
var Route = createFileRoute("/_authenticated/recebimento/novo")({
	validateSearch: (s) => typeof s["copiar"] === "string" && s["copiar"] ? { copiar: s["copiar"] } : {},
	head: () => ({ meta: [
		{ title: "Novo recebimento — Expedição CDLog" },
		{
			name: "description",
			content: "Registre o recebimento de uma carga."
		},
		{
			property: "og:title",
			content: "Novo recebimento — Expedição CDLog"
		},
		{
			property: "og:description",
			content: "Formulário de controle de recebimento."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
