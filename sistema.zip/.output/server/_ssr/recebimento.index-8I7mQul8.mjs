import { o as __toESM } from "../_runtime.mjs";
import { baixar } from "./exportar-CyB7YhkX.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { O as ChevronRight, f as LoaderCircle, l as Plus, n as TriangleAlert, v as FileSpreadsheet } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-UtwXV0ic.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { t as brl } from "./formato-C78tmqZq.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { _ as somaPaletes, i as duracaoDescarga, o as escreverNumBr, r as dataBr, u as formatarDuracao } from "./dados-DGVmU1Si.mjs";
import { n as recebimentosQuery } from "./consultas-CR7OsYoG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recebimento.index-8I7mQul8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTROS_VAZIOS = {
	de: "",
	ate: "",
	cliente: "",
	transportadora: "",
	ocorrencia: "todas"
};
var norm = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
function filtrar(regs, f) {
	const cli = norm(f.cliente);
	const tr = norm(f.transportadora);
	return regs.filter((r) => (!f.de || r.data_chegada >= f.de) && (!f.ate || r.data_chegada <= f.ate) && (!cli || norm(r.cliente).includes(cli)) && (!tr || norm(r.transportadora).includes(tr)) && (f.ocorrencia === "todas" || f.ocorrencia === "com" === r.tem_ocorrencia));
}
/** Há divergência quando houve ocorrência marcada ou a soma dos tipos de palete não bate com o total. */
function temDivergencia(r) {
	if (r.tem_ocorrencia) return true;
	const tipos = [
		r.paletes_pbr,
		r.paletes_chep,
		r.paletes_descartavel,
		r.paletes_quebrados
	];
	if (r.paletes_total === null && tipos.every((v) => v === null)) return false;
	return somaPaletes({
		total: r.paletes_total,
		pbr: r.paletes_pbr,
		chep: r.paletes_chep,
		descartavel: r.paletes_descartavel,
		quebrados: r.paletes_quebrados
	}) !== (r.paletes_total ?? 0);
}
function resumoLista(regs) {
	return {
		total: regs.length,
		volumes: regs.reduce((s, r) => s + r.volumes, 0),
		peso: regs.reduce((s, r) => s + (r.peso_kg ?? 0), 0),
		valor: regs.reduce((s, r) => s + (r.valor ?? 0), 0),
		paletes: regs.reduce((s, r) => s + (r.paletes_total ?? 0), 0),
		comDivergencia: regs.filter(temDivergencia).length
	};
}
function duracaoLinha(r) {
	return duracaoDescarga(r.hora_inicio ?? "", r.hora_final ?? "");
}
var XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
function Indicador({ rotulo, valor, destaque }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("card-surface p-4", destaque && "border-warning/60 bg-warning-soft"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
			children: rotulo
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "tabular mt-1 text-2xl font-medium text-foreground",
			children: valor
		})]
	});
}
function ListaRecebimentos() {
	const { data, isLoading, error } = useQuery(recebimentosQuery);
	const [f, setF] = (0, import_react.useState)(FILTROS_VAZIOS);
	const [gerando, setGerando] = (0, import_react.useState)(false);
	const lista = (0, import_react.useMemo)(() => filtrar(data ?? [], f), [data, f]);
	const res = (0, import_react.useMemo)(() => resumoLista(lista), [lista]);
	const set = (k, v) => setF((x) => ({
		...x,
		[k]: v
	}));
	async function exportar() {
		setGerando(true);
		try {
			const { planilhaRecebimentos } = await import("./planilha-CSe10Cv_.mjs");
			baixar(await planilhaRecebimentos(lista), "recebimentos.xlsx", XLSX_MIME);
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível gerar a planilha.");
		} finally {
			setGerando(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight text-foreground",
				children: "Recebimento"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Controle de recebimento de cargas, do mais recente para o mais antigo."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					onClick: exportar,
					disabled: gerando || lista.length === 0,
					children: [gerando ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, {}), " Exportar planilha"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/recebimento/novo",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Novo recebimento"]
					})
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-surface mt-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "de",
						children: "Chegada de"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "de",
						type: "date",
						value: f.de,
						onChange: (e) => set("de", e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "ate",
						children: "até"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "ate",
						type: "date",
						value: f.ate,
						onChange: (e) => set("ate", e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "cli",
						children: "Cliente"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "cli",
						value: f.cliente,
						onChange: (e) => set("cliente", e.target.value),
						placeholder: "Parte do nome"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "tr",
						children: "Transportadora"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "tr",
						value: f.transportadora,
						onChange: (e) => set("transportadora", e.target.value),
						placeholder: "Parte do nome"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "oc",
						children: "Ocorrências"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						id: "oc",
						value: f.ocorrencia,
						onChange: (e) => set("ocorrencia", e.target.value),
						className: "h-9 w-full rounded-md border border-input bg-background px-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "todas",
								children: "Todas"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "com",
								children: "Com ocorrências"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "sem",
								children: "Sem ocorrências"
							})
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-3 md:grid-cols-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Recebimentos",
					valor: res.total
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Volumes",
					valor: escreverNumBr(res.volumes)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Peso (kg)",
					valor: escreverNumBr(res.peso, 1)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Valor",
					valor: brl(res.valor)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Paletes",
					valor: escreverNumBr(res.paletes)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Com divergência",
					valor: res.comDivergencia,
					destaque: res.comDivergencia > 0
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6",
			children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-md border border-destructive/30 bg-destructive-soft px-4 py-3 text-sm text-destructive",
				children: "Não foi possível carregar os recebimentos. Recarregue a página."
			}) : lista.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "card-surface px-5 py-10 text-center text-sm text-muted-foreground",
				children: data && data.length > 0 ? "Nenhum recebimento com esses filtros." : "Nenhum recebimento registrado ainda."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-surface overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b bg-secondary text-xs uppercase tracking-wide text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [[
							"Chegada",
							"Cliente",
							"Origem",
							"Motorista",
							"Transportadora",
							"Placa",
							"Vol.",
							"NF-e",
							"Peso (kg)",
							"Valor",
							"Paletes",
							"Ocorr.",
							"Descarga"
						].map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: cn("px-3 py-2.5 font-medium", [
								6,
								7,
								8,
								9,
								10
							].includes(i) && "text-right"),
							children: h
						}, h)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-8" })] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lista.map((r) => {
						const n = Array.isArray(r.ocorrencias) ? r.ocorrencias.length : 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "group relative border-t hover:bg-accent/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "tabular px-3 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/recebimento/$id",
										params: { id: r.id },
										className: "font-medium text-primary after:absolute after:inset-0",
										children: dataBr(r.data_chegada)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: r.hora_chegada ?? ""
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-48 truncate px-3 py-3",
									title: r.cliente,
									children: r.cliente
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: r.origem
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-40 truncate px-3 py-3",
									children: r.motorista
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-40 truncate px-3 py-3",
									children: r.transportadora
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-3",
									children: r.placa
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-3 text-right",
									children: r.volumes
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-3 text-right",
									children: r.quant_nfe ?? ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-3 text-right",
									children: escreverNumBr(r.peso_kg, 1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-3 text-right",
									children: r.valor === null ? "" : brl(r.valor)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-3 text-right",
									children: r.paletes_total ?? ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: r.tem_ocorrencia ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded bg-warning-soft px-1.5 py-0.5 text-xs font-medium text-warning-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3" }),
											" Sim (",
											n,
											")"
										]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: temDivergencia(r) ? "Paletes" : "Não"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "tabular px-3 py-3",
									children: formatarDuracao(duracaoLinha(r))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-2 py-3 text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
								})
							]
						}, r.id);
					}) })]
				})
			})
		})
	] });
}
//#endregion
export { ListaRecebimentos as component };
