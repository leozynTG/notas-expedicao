//#region node_modules/.nitro/vite/services/ssr/assets/pdf-texto-DYy5gAvA.js
/** Reads every page's text pieces with their positions (viewport coordinates, origin top-left). */
async function lerPaginasPdf(arquivo) {
	const [pdfjs, worker] = await Promise.all([import("../_libs/pdfjs-dist.mjs").then((n) => n.t), import("./pdf.worker.min-BDqvoJpD.mjs")]);
	pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
	const pdf = await pdfjs.getDocument({ data: new Uint8Array(await arquivo.arrayBuffer()) }).promise;
	const paginas = [];
	for (let p = 1; p <= pdf.numPages; p++) {
		const pagina = await pdf.getPage(p);
		const viewport = pagina.getViewport({ scale: 1 });
		const conteudo = await pagina.getTextContent();
		const trechos = [];
		for (const item of conteudo.items) {
			const it = item;
			if (typeof it.str !== "string" || !it.transform || it.str.trim() === "") continue;
			const [, , , , x = 0, topo = 0] = pdfjs.Util.transform(viewport.transform, it.transform);
			trechos.push({
				str: it.str,
				x,
				topo,
				largura: it.width ?? 0
			});
		}
		paginas.push({
			largura: viewport.width,
			altura: viewport.height,
			trechos
		});
	}
	return paginas;
}
/** Abre um PDF (pdf.js carregado sob demanda). */
async function abrirPdf(dados) {
	const [pdfjs, worker] = await Promise.all([import("../_libs/pdfjs-dist.mjs").then((n) => n.t), import("./pdf.worker.min-BDqvoJpD.mjs")]);
	pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
	const copia = dados instanceof Uint8Array ? dados.slice() : new Uint8Array(dados.slice(0));
	return pdfjs.getDocument({ data: copia }).promise;
}
/** Texto de cada página do PDF (itens separados por espaço). */
async function lerTextoPdf(arquivo) {
	const pdf = await abrirPdf(await arquivo.arrayBuffer());
	const paginas = [];
	for (let i = 1; i <= pdf.numPages; i++) {
		const c = await (await pdf.getPage(i)).getTextContent();
		paginas.push(c.items.map((it) => it.str ?? "").join(" "));
	}
	return paginas;
}
//#endregion
export { abrirPdf, lerPaginasPdf, lerTextoPdf };
