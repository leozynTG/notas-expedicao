import { o as __toESM } from "../_runtime.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { O as ChevronRight, a as Search, f as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { n as dataHora } from "./formato-C78tmqZq.mjs";
import { a as keepPreviousData } from "../_libs/tanstack__query-core.mjs";
import { r as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as cargasQuery } from "./historico-queries-DyG2ualt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/historico.index-DxGO9Lfh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Historico() {
	const [texto, setTexto] = (0, import_react.useState)("");
	const [termo, setTermo] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const t = setTimeout(() => setTermo(texto.trim()), 300);
		return () => clearTimeout(t);
	}, [texto]);
	const { data, isLoading, isFetching, error } = useQuery({
		...cargasQuery(termo),
		placeholderData: keepPreviousData
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-bold tracking-tight text-foreground",
			children: "Histórico de cargas"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Da mais recente para a mais antiga."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative w-full sm:w-96",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "pl-9",
					placeholder: "Nº da carga, NF, pedido ou destinatário",
					value: texto,
					onChange: (e) => setTexto(e.target.value),
					"aria-label": "Buscar no histórico"
				}),
				isFetching && !isLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "absolute right-3 top-1/2 size-4 -translate-y-1/2 animate-spin text-muted-foreground" })
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-6",
		children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin text-muted-foreground" })
		}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-md border border-destructive/30 bg-destructive-soft px-4 py-3 text-sm text-destructive",
			children: "Não foi possível carregar o histórico. Recarregue a página."
		}) : !data || data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "card-surface px-5 py-10 text-center text-sm text-muted-foreground",
			children: termo ? `Nenhuma carga encontrada para "${termo}".` : "Nenhuma carga salva ainda. Processe uma carga e salve no histórico."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-surface overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b bg-secondary text-xs uppercase tracking-wide text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 font-medium",
							children: "Carga"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 font-medium",
							children: "Processada"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 text-right font-medium",
							children: "Notas"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 font-medium",
							children: "Por tipo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 text-right font-medium",
							children: "Frac."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2.5 text-right font-medium",
							children: "Sem vol."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "w-8" })
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data.map((c) => {
					const tipos = [
						["Venda", c.vendas],
						["Troca", c.trocas],
						["Bonif.", c.bonificacoes],
						["Brinde", c.brindes],
						["Amostra", c.amostras],
						["Outras", c.outras]
					].filter(([, v]) => Number(v) > 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "group relative border-t hover:bg-accent/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/historico/$id",
									params: { id: c.id },
									search: termo ? { q: termo } : {},
									className: "tabular font-medium text-primary after:absolute after:inset-0",
									children: c.numero_carga
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tabular text-foreground",
									children: dataHora(c.processada_em)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "max-w-52 truncate text-xs text-muted-foreground",
									children: c.processada_por_email || "usuário removido"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "tabular px-4 py-3 text-right",
								children: c.total_notas
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex flex-wrap gap-1.5",
									children: tipos.map(([t, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded border bg-secondary px-1.5 py-0.5 text-xs",
										children: [
											t,
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tabular font-medium text-primary",
												children: v
											})
										]
									}, t))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "tabular px-4 py-3 text-right",
								children: c.notas_fracionadas
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "tabular px-4 py-3 text-right",
								children: c.notas_sem_volume
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-3 text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
							})
						]
					}, c.id);
				}) })]
			})
		})
	})] });
}
//#endregion
export { Historico as component };
