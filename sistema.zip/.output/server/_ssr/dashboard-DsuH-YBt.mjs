import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DsuH-YBt.js
var $$splitComponentImporter = () => import("./dashboard-PgRk2vth.mjs");
var DATA = /^\d{4}-\d{2}-\d{2}$/;
var Route = createFileRoute("/_authenticated/dashboard")({
	validateSearch: (s) => {
		const r = {};
		if (typeof s["de"] === "string" && DATA.test(s["de"])) r.de = s["de"];
		if (typeof s["ate"] === "string" && DATA.test(s["ate"])) r.ate = s["ate"];
		if (typeof s["carga"] === "string" && s["carga"]) r.carga = s["carga"];
		return r;
	},
	head: () => ({ meta: [
		{ title: "Dashboard — Expedição CDLog" },
		{
			name: "description",
			content: "Totais acumulados das cargas: valor, peso, volumes, trocas e cidades, com filtro por período."
		},
		{
			property: "og:title",
			content: "Dashboard — Expedição CDLog"
		},
		{
			property: "og:description",
			content: "Visão geral das cargas processadas pela expedição."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
