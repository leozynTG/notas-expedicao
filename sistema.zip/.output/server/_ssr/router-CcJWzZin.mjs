import { o as __toESM } from "../_runtime.mjs";
import { _ as createFileRoute, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { i as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Route$6 } from "./dashboard-DsuH-YBt.mjs";
import { t as Route$7 } from "./historico._id-BlyVrCrn.mjs";
import { t as Route$8 } from "./recebimento._id-BmxIggvZ.mjs";
import { t as Route$9 } from "./recebimento.novo-ChMZbmTW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CcJWzZin.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DwN2it7J.css";
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Página não encontrada"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "A página que você procura não existe."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Voltar ao início"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		console.error(error);
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "Esta página não carregou"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Algo deu errado. Tente novamente ou volte ao início."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Tentar novamente"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Voltar ao início"
					})]
				})
			]
		})
	});
}
var Route$5 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Expedição CDLog" },
			{
				name: "description",
				content: "Organize os XMLs de NF-e de uma carga direto no navegador."
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/icone-cdlog.png?v=2",
				type: "image/png"
			},
			{
				rel: "shortcut icon",
				href: "/favicon.ico?v=2"
			},
			{
				rel: "apple-touch-icon",
				href: "/apple-touch-icon.png?v=2"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Montserrat:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$5.useRouteContext();
	useRouter();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			richColors: true,
			position: "top-center"
		})]
	});
}
var $$splitComponentImporter$4 = () => import("./route-Di7iQBCH.mjs");
var Route$4 = createFileRoute("/_authenticated")({
	ssr: false,
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_authenticated-CjAjAPS3.mjs");
var Route$3 = createFileRoute("/_authenticated/")({
	head: () => ({ meta: [
		{ title: "Expedição CDLog — Organizar XMLs da carga" },
		{
			name: "description",
			content: "Leia os XMLs de NF-e de uma carga, cruze as notas com os pickings e baixe a planilha e os ZIPs separados. Tudo no navegador."
		},
		{
			property: "og:title",
			content: "Expedição CDLog"
		},
		{
			property: "og:description",
			content: "Planilha de notas e ZIPs separados por tipo, gerados direto no navegador."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./cte-CXc4splV.mjs");
var Route$2 = createFileRoute("/_authenticated/cte")({
	head: () => ({ meta: [
		{ title: "Organizar CTe — Expedição CDLog" },
		{
			name: "description",
			content: "Junte os PDFs de CTe em um único arquivo ordenado pelo número da NF-e, direto no navegador."
		},
		{
			property: "og:title",
			content: "Organizar CTe — Expedição CDLog"
		},
		{
			property: "og:description",
			content: "CTe ordenados pela nota fiscal, sem enviar arquivos."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./historico.index-DxGO9Lfh.mjs");
var Route$1 = createFileRoute("/_authenticated/historico/")({
	head: () => ({ meta: [
		{ title: "Histórico de cargas — Expedição CDLog" },
		{
			name: "description",
			content: "Cargas processadas, com busca por número da carga, NF, pedido ou destinatário."
		},
		{
			property: "og:title",
			content: "Histórico de cargas — Expedição CDLog"
		},
		{
			property: "og:description",
			content: "Cargas processadas pela equipe de expedição."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./recebimento.index-8I7mQul8.mjs");
var Route = createFileRoute("/_authenticated/recebimento/")({
	head: () => ({ meta: [
		{ title: "Recebimento — Expedição CDLog" },
		{
			name: "description",
			content: "Controle de recebimento de cargas, com filtros, resumo e planilha."
		},
		{
			property: "og:title",
			content: "Recebimento — Expedição CDLog"
		},
		{
			property: "og:description",
			content: "Recebimentos registrados pela equipe de expedição."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var AuthenticatedRouteRoute = Route$4.update({
	id: "/_authenticated",
	getParentRoute: () => Route$5
});
var AuthenticatedIndexRoute = Route$3.update({
	id: "/",
	path: "/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedCteRoute = Route$2.update({
	id: "/cte",
	path: "/cte",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedDashboardRoute = Route$6.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedHistoricoIndexRoute = Route$1.update({
	id: "/historico/",
	path: "/historico/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedHistoricoIdRoute = Route$7.update({
	id: "/historico/$id",
	path: "/historico/$id",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRecebimentoIndexRoute = Route.update({
	id: "/recebimento/",
	path: "/recebimento/",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedCteRoute,
	AuthenticatedDashboardRoute,
	AuthenticatedIndexRoute,
	AuthenticatedHistoricoIdRoute,
	AuthenticatedRecebimentoIdRoute: Route$8.update({
		id: "/recebimento/$id",
		path: "/recebimento/$id",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedRecebimentoNovoRoute: Route$9.update({
		id: "/recebimento/novo",
		path: "/recebimento/novo",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedHistoricoIndexRoute,
	AuthenticatedRecebimentoIndexRoute
};
var rootRouteChildren = { AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren) };
var routeTree = Route$5._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
