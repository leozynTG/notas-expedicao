import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as Check, b as Eraser, f as LoaderCircle, g as FileText, l as Plus, n as TriangleAlert, o as Save, r as Trash2, y as FileArchive } from "../_libs/lucide-react.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-UtwXV0ic.mjs";
import { t as Input } from "./input-B8Q2ztVi.mjs";
import { t as Label } from "./label-DBD1bRRP.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { f as lerInteiro, g as resumoXml, i as duracaoDescarga, m as normalizarPlaca, n as avisoPaletes, o as escreverNumBr, s as finalAntesDoInicio, t as MOTIVOS, u as formatarDuracao, v as validar } from "./dados-DGVmU1Si.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FormRecebimento-B0pwYjiC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
function Erro({ texto }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: "alert",
		className: "rounded-md border border-destructive/30 bg-destructive-soft px-3 py-2 text-sm text-destructive",
		children: texto
	});
}
function Assinatura({ rotulo, valor, onChange }) {
	const ref = (0, import_react.useRef)(null);
	const desenhando = (0, import_react.useRef)(false);
	const ultimo = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const c = ref.current;
		if (!c) return;
		const ctx = c.getContext("2d");
		ctx.clearRect(0, 0, c.width, c.height);
		if (valor) {
			const img = new Image();
			img.onload = () => ctx.drawImage(img, 0, 0, c.width, c.height);
			img.src = valor;
		}
	}, []);
	function ponto(e) {
		const c = ref.current;
		const r = c.getBoundingClientRect();
		return {
			x: (e.clientX - r.left) * c.width / r.width,
			y: (e.clientY - r.top) * c.height / r.height
		};
	}
	function mover(e) {
		if (!desenhando.current) return;
		const ctx = ref.current.getContext("2d");
		const p = ponto(e);
		ctx.strokeStyle = "#111";
		ctx.lineWidth = 3;
		ctx.lineCap = "round";
		ctx.lineJoin = "round";
		ctx.beginPath();
		ctx.moveTo(ultimo.current.x, ultimo.current.y);
		ctx.lineTo(p.x, p.y);
		ctx.stroke();
		ultimo.current = p;
	}
	function fim() {
		if (!desenhando.current) return;
		desenhando.current = false;
		onChange(ref.current.toDataURL("image/png"));
	}
	function limpar() {
		const c = ref.current;
		c.getContext("2d").clearRect(0, 0, c.width, c.height);
		onChange(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium text-foreground",
				children: rotulo
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: limpar,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, {}), " Limpar"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			width: 600,
			height: 200,
			"aria-label": `Assinatura ${rotulo}`,
			className: "h-40 w-full touch-none rounded-md border-2 border-dashed border-input bg-card",
			onPointerDown: (e) => {
				e.currentTarget.setPointerCapture(e.pointerId);
				desenhando.current = true;
				ultimo.current = ponto(e);
			},
			onPointerMove: mover,
			onPointerUp: fim,
			onPointerCancel: fim
		})]
	});
}
function Secao({ n, titulo, children, acao }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "card-surface p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-7 items-center justify-center rounded-full bg-primary text-sm font-semibold text-primary-foreground",
					children: n
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-semibold text-foreground",
					children: titulo
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ml-auto",
					children: acao
				})
			]
		}), children]
	});
}
function Aviso({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-3 flex items-start gap-2 rounded-md border border-warning/60 bg-warning-soft px-3 py-2 text-sm text-warning-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0" }),
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children })
		]
	});
}
function FormRecebimento({ inicial, onSalvar, salvando }) {
	const [f, setF] = (0, import_react.useState)(inicial);
	const [erros, setErros] = (0, import_react.useState)([]);
	const [lendo, setLendo] = (0, import_react.useState)(false);
	const [avisosXml, setAvisosXml] = (0, import_react.useState)([]);
	const arquivo = (0, import_react.useRef)(null);
	const arquivoMdfe = (0, import_react.useRef)(null);
	const set = (k, v) => setF((x) => ({
		...x,
		[k]: v
	}));
	function campo(k, rotulo, modo = "texto", extra) {
		const tipo = modo === "data" ? "date" : modo === "hora" ? "time" : "text";
		const im = modo === "decimal" ? "decimal" : modo === "inteiro" ? "numeric" : void 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("space-y-1.5", extra?.cls),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
				htmlFor: k,
				children: [rotulo, extra?.obrig && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-destructive",
					children: " *"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				id: k,
				type: tipo,
				inputMode: im,
				placeholder: extra?.ph,
				className: "h-11 text-base",
				value: f[k],
				onChange: (e) => {
					let v = e.target.value;
					if (k === "placa") v = normalizarPlaca(v);
					if (modo === "inteiro") v = v.replace(/\D/g, "");
					set(k, v);
				}
			})]
		});
	}
	async function lerXml(file) {
		setLendo(true);
		setAvisosXml([]);
		try {
			const { processarCarga } = await import("./processar-CJm-LIil.mjs");
			const r = await processarCarga(await file.arrayBuffer(), null);
			const s = resumoXml(r.notas);
			let cliente = "";
			let origem = s.origem;
			const primeira = r.notas[0];
			if (primeira) {
				const emit = new DOMParser().parseFromString(new TextDecoder().decode(primeira.bytes), "application/xml").getElementsByTagNameNS("*", "emit")[0];
				const t = (tag) => emit?.getElementsByTagNameNS("*", tag)[0]?.textContent?.trim() ?? "";
				cliente = t("xNome");
				if (t("xMun") || t("UF")) origem = `${t("xMun")}/${t("UF")}`;
			}
			setF((x) => ({
				...x,
				quant_nfe: String(s.quantNfe),
				valor: escreverNumBr(s.valor, 2),
				peso: s.peso === null ? x.peso : escreverNumBr(s.peso, 3),
				volumes: s.volumes === null ? x.volumes : String(s.volumes),
				cliente: cliente || x.cliente,
				origem: origem || x.origem
			}));
			const av = [];
			if (s.semPeso) av.push(`${s.semPeso} nota(s) sem peso no XML ficaram fora do peso.`);
			if (s.semVolume) av.push(`${s.semVolume} nota(s) sem volume no XML ficaram fora dos volumes.`);
			setAvisosXml(av);
			toast.success(`${s.quantNfe} notas lidas. Confira os campos preenchidos.`);
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Não foi possível ler o ZIP.");
		} finally {
			setLendo(false);
			if (arquivo.current) arquivo.current.value = "";
		}
	}
	async function lerMdfe(file) {
		setLendo(true);
		setAvisosXml([]);
		try {
			const { lerTextoPdf } = await import("./pdf-texto-DYy5gAvA.mjs");
			const { lerManifesto } = await import("./manifesto-mmIkbTkv.mjs");
			const { dados, avisos } = lerManifesto(await lerTextoPdf(file));
			if (Object.values(dados).filter(Boolean).length === 0) {
				toast.error("Não encontrei dados de manifesto nesse PDF.");
				setAvisosXml(avisos);
				return;
			}
			setF((x) => ({
				...x,
				cliente: dados.cliente || x.cliente,
				origem: dados.origem || x.origem,
				motorista: dados.motorista || x.motorista,
				transportadora: dados.transportadora || x.transportadora,
				placa: dados.placa || x.placa,
				peso: dados.peso || x.peso,
				valor: dados.valor || x.valor,
				volumes: dados.volumes || x.volumes,
				quant_nfe: dados.quant_nfe || x.quant_nfe,
				lacre: dados.lacre || x.lacre
			}));
			setAvisosXml(avisos);
			toast.success("Manifesto lido. Confira os campos preenchidos.");
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível ler o PDF do manifesto.");
		} finally {
			setLendo(false);
			if (arquivoMdfe.current) arquivoMdfe.current.value = "";
		}
	}
	async function salvar(e) {
		e.preventDefault();
		const er = validar(f);
		setErros(er);
		if (er.length) {
			window.scrollTo({
				top: 0,
				behavior: "smooth"
			});
			return;
		}
		await onSalvar(f);
	}
	const dur = duracaoDescarga(f.hora_inicio, f.hora_final);
	const avPal = avisoPaletes({
		total: lerInteiro(f.paletes_total),
		pbr: lerInteiro(f.paletes_pbr),
		chep: lerInteiro(f.paletes_chep),
		descartavel: lerInteiro(f.paletes_descartavel),
		quebrados: lerInteiro(f.paletes_quebrados)
	});
	const setOc = (i, k, v) => set("ocorrencias", f.ocorrencias.map((o, j) => j === i ? {
		...o,
		[k]: v
	} : o));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: salvar,
		className: "space-y-5",
		noValidate: true,
		children: [
			erros.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: erros.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Erro, { texto: x }, x))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-surface flex flex-wrap items-center gap-3 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: arquivo,
						type: "file",
						accept: ".zip,.rar",
						className: "hidden",
						onChange: (e) => e.target.files?.[0] && lerXml(e.target.files[0])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => arquivo.current?.click(),
						disabled: lendo,
						children: [lendo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileArchive, {}), " Preencher a partir dos XMLs da carga"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: arquivoMdfe,
						type: "file",
						accept: ".pdf,application/pdf",
						className: "hidden",
						onChange: (e) => e.target.files?.[0] && lerMdfe(e.target.files[0])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => arquivoMdfe.current?.click(),
						disabled: lendo,
						children: [lendo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}), " Preencher a partir do manifesto (PDF)"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Opcional. Os arquivos são lidos no seu computador e não são enviados."
					}),
					avisosXml.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aviso, { children: a }, a))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secao, {
				n: 1,
				titulo: "Chegada",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [campo("data_chegada", "Data da chegada", "data", { obrig: true }), campo("hora_chegada", "Horário da chegada", "hora")]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Secao, {
				n: 2,
				titulo: "Descarga",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-4",
					children: [
						campo("hora_inicio", "Hora início", "hora"),
						campo("hora_final", "Hora final", "hora"),
						campo("data_saida", "Data da saída", "data"),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Duração" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "tabular flex h-11 items-center rounded-md border bg-secondary px-3 text-base font-medium",
								children: formatarDuracao(dur)
							})]
						})
					]
				}), finalAntesDoInicio(f.hora_inicio, f.hora_final) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aviso, { children: "A hora final é antes da hora início." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secao, {
				n: 3,
				titulo: "Embarcador",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [campo("cliente", "Cliente", "texto", { obrig: true }), campo("origem", "Origem", "texto", { ph: "Cidade ou UF" })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secao, {
				n: 4,
				titulo: "Dados da carga",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: [
						campo("motorista", "Motorista", "texto", { obrig: true }),
						campo("transportadora", "Transportadora"),
						campo("veiculo", "Veículo", "texto", { ph: "3/4, Truck…" }),
						campo("placa", "Placa", "texto", {
							obrig: true,
							ph: "AAA-0A00 ou AAA-0A00 / BBB-0B00"
						}),
						campo("peso", "Peso (kg)", "decimal", { ph: "2.435,2" }),
						campo("valor", "Valor da carga (R$)", "decimal", { ph: "177.993,51" }),
						campo("transporte", "Transporte"),
						campo("cubagem", "Cubagem (m³)", "decimal"),
						campo("volumes", "Volumes", "inteiro", { obrig: true }),
						campo("quant_nfe", "Quant. NF-e", "inteiro"),
						campo("lacre", "Lacre")
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Secao, {
				n: 5,
				titulo: "Paletes",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-4 sm:grid-cols-5",
					children: [
						campo("paletes_total", "Total", "inteiro"),
						campo("paletes_pbr", "PBR", "inteiro"),
						campo("paletes_chep", "CHEP", "inteiro"),
						campo("paletes_descartavel", "Descartável", "inteiro"),
						campo("paletes_quebrados", "Quebrados", "inteiro")
					]
				}), avPal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Aviso, { children: avPal })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Secao, {
				n: 6,
				titulo: "Ocorrências / divergências",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					role: "radiogroup",
					"aria-label": "Houve ocorrências?",
					children: [false, true].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						role: "radio",
						"aria-checked": f.tem_ocorrencia === v,
						variant: f.tem_ocorrencia === v ? "default" : "outline",
						className: "h-11 w-24",
						onClick: () => set("tem_ocorrencia", v),
						children: v ? "Sim" : "Não"
					}, String(v)))
				}), f.tem_ocorrencia && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
							id: "motivos",
							children: MOTIVOS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: m }, m))
						}),
						f.ocorrencias.map((o, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 rounded-md border p-3 sm:grid-cols-[1fr_2fr_0.7fr_1fr_1fr_auto]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									"aria-label": "Código",
									placeholder: "Código",
									className: "h-11",
									value: o.codigo,
									onChange: (e) => setOc(i, "codigo", e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									"aria-label": "Produto",
									placeholder: "Produto",
									className: "h-11",
									value: o.produto,
									onChange: (e) => setOc(i, "produto", e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									"aria-label": "Quant.",
									placeholder: "Quant.",
									inputMode: "decimal",
									className: "h-11",
									value: o.quant,
									onChange: (e) => setOc(i, "quant", e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									"aria-label": "Nota",
									placeholder: "Nota (NF)",
									inputMode: "numeric",
									className: "h-11",
									value: o.nota,
									onChange: (e) => setOc(i, "nota", e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									"aria-label": "Motivo",
									placeholder: "Motivo",
									list: "motivos",
									className: "h-11",
									value: o.motivo,
									onChange: (e) => setOc(i, "motivo", e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									className: "h-11",
									"aria-label": "Remover linha",
									onClick: () => set("ocorrencias", f.ocorrencias.filter((_, j) => j !== i)),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
								})
							]
						}, i)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => set("ocorrencias", [...f.ocorrencias, {
								codigo: "",
								produto: "",
								quant: "",
								nota: "",
								motivo: ""
							}]),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Adicionar linha"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secao, {
				n: 7,
				titulo: "Lançamentos",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-6",
					children: [
						["lanc_kpi", "KPI"],
						["lanc_controle_paletes", "Controle de Paletes"],
						["lanc_email", "Enviado e-mail"]
					].map(([k, r]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-base",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								className: "size-6",
								checked: f[k],
								onCheckedChange: (v) => set(k, v === true)
							}),
							" ",
							r
						]
					}, k))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Secao, {
				n: 8,
				titulo: "Assinaturas",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-6 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [campo("conferente", "Conferente"), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Assinatura, {
							rotulo: "Assinatura do conferente",
							valor: f.assinatura_conferente,
							onChange: (v) => set("assinatura_conferente", v)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-3 md:pt-[4.5rem]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Assinatura, {
							rotulo: `Assinatura do motorista${f.motorista ? ` (${f.motorista})` : ""}`,
							valor: f.assinatura_motorista,
							onChange: (v) => set("assinatura_motorista", v)
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky bottom-0 -mx-5 flex justify-end border-t bg-background/95 px-5 py-3 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					size: "lg",
					disabled: salvando,
					children: [salvando ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), " Salvar recebimento"]
				})
			})
		]
	});
}
//#endregion
export { FormRecebimento as t };
