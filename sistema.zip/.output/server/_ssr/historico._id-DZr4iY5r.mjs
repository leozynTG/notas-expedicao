import { o as __toESM } from "../_runtime.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { f as LoaderCircle, j as ArrowLeft, r as Trash2, v as FileSpreadsheet, x as Download } from "../_libs/lucide-react.mjs";
import { s as excluirCarga, t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { t as Button } from "./button-UtwXV0ic.mjs";
import { n as dataHora, r as kg, t as brl } from "./formato-C78tmqZq.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-CJc3CPXp.mjs";
import { r as linhasDoHistorico, t as TabelaNotas } from "./historico-C0yNNhv5.mjs";
import { a as useQueryClient, n as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { t as cargaQuery } from "./historico-queries-DyG2ualt.mjs";
import { t as Route } from "./historico._id-BlyVrCrn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/historico._id-DZr4iY5r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
function Indicador({ rotulo, valor, destaque }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("card-surface p-4", destaque && "border-warning/60 bg-warning-soft"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium uppercase tracking-wide text-muted-foreground",
			children: rotulo
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: cn("tabular mt-1 text-2xl font-medium", destaque ? "text-warning-foreground" : "text-foreground"),
			children: valor
		})]
	});
}
function DetalheCarga() {
	const { id } = Route.useParams();
	const { q } = Route.useSearch();
	const { data } = useSuspenseQuery(cargaQuery(id));
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const [baixando, setBaixando] = (0, import_react.useState)(false);
	const [excluindo, setExcluindo] = (0, import_react.useState)(false);
	const linhas = (0, import_react.useMemo)(() => data ? linhasDoHistorico(data.notas) : [], [data]);
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-surface mx-auto max-w-md p-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold text-foreground",
				children: "Carga não encontrada"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Ela pode ter sido excluída."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/historico",
					children: "Voltar ao histórico"
				})
			})
		]
	}) });
	const { carga } = data;
	const valorTotal = linhas.reduce((s, n) => s + n.valor, 0);
	async function baixarPlanilha() {
		setBaixando(true);
		try {
			const [{ gerarPlanilha, baixar }] = await Promise.all([import("./exportar-CyB7YhkX.mjs")]);
			baixar(await gerarPlanilha(linhas), `notas_carga_${carga.numero_carga}.xlsx`, XLSX_MIME);
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível gerar a planilha.");
		} finally {
			setBaixando(false);
		}
	}
	async function excluir() {
		setExcluindo(true);
		let falhou = false;
		try {
			await excluirCarga({ data: { id: carga.id } });
		} catch (e) {
			console.error(e);
			falhou = true;
		}
		setExcluindo(false);
		if (falhou) {
			toast.error("Não foi possível excluir a carga.");
			return;
		}
		toast.success(`Carga ${carga.numero_carga} excluída.`);
		queryClient.removeQueries({ queryKey: [
			"cargas",
			"detalhe",
			carga.id
		] });
		await Promise.all([queryClient.invalidateQueries({ queryKey: ["cargas", "lista"] }), queryClient.invalidateQueries({ queryKey: ["cargas", "dashboard"] })]);
		navigate({
			to: "/historico",
			replace: true
		});
	}
	const tipos = [
		["Venda", carga.vendas],
		["Troca", carga.trocas],
		["Bonificação", carga.bonificacoes],
		["Brinde", carga.brindes],
		["Amostra", carga.amostras],
		["Outras", carga.outras]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/historico",
			className: "inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Histórico"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-3 flex flex-wrap items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-2xl font-bold tracking-tight text-foreground",
				children: ["Carga ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular",
					children: carga.numero_carga
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"Processada por ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground",
						children: carga.processada_por_email || "usuário removido"
					}),
					" ",
					"em ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular text-foreground",
						children: dataHora(carga.processada_em)
					})
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "download",
					onClick: baixarPlanilha,
					disabled: baixando,
					children: [
						baixando ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, {}),
						" Baixar planilha",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "text-destructive hover:text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Excluir"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogTitle, { children: [
					"Excluir a carga ",
					carga.numero_carga,
					"?"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogDescription, { children: [
					"A carga e as ",
					carga.total_notas,
					" nota(s) dela serão apagadas do histórico. Isso não pode ser desfeito."
				] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancelar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
					onClick: excluir,
					disabled: excluindo,
					className: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
					children: "Excluir carga"
				})] })] })] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Notas",
					valor: carga.total_notas
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Fracionadas",
					valor: carga.notas_fracionadas,
					destaque: carga.notas_fracionadas > 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Sem volume no XML",
					valor: carga.notas_sem_volume,
					destaque: carga.notas_sem_volume > 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Valor total",
					valor: brl(valorTotal)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Peso bruto",
					valor: kg(carga.peso_bruto_total_kg)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicador, {
					rotulo: "Peso líquido",
					valor: kg(carga.peso_liquido_total_kg)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			children: tipos.filter(([, v]) => v > 0).map(([t, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-2 rounded-md border bg-card px-3 py-1.5 text-sm",
				children: [t, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular font-medium text-primary",
					children: v
				})]
			}, t))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "text-sm font-semibold text-foreground",
				children: [
					"Notas ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-normal text-muted-foreground",
						children: [
							"(",
							linhas.length,
							")"
						]
					}),
					q && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-2 font-normal text-muted-foreground",
						children: [
							"— destacando \"",
							q,
							"\""
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabelaNotas, {
				linhas,
				destaque: q ?? ""
			})]
		})
	] });
}
//#endregion
export { DetalheCarga as component };
