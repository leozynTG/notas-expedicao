import { l as lerCarga, o as dashboardCargas, r as buscarCargas } from "./AppShell-DeQ07z7V.mjs";
import { t as queryOptions } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/historico-queries-DyG2ualt.js
var n = (v) => {
	const x = typeof v === "number" ? v : Number(v);
	return Number.isFinite(x) ? x : 0;
};
var nOuNulo = (v) => v === null || v === void 0 ? null : n(v);
var arred = (v) => Math.round(v * 1e4) / 1e4;
var div = (a, b) => b > 0 ? a / b : null;
/** Normaliza o JSON da função do banco (números podem vir como texto). */
function lerDashboard(json) {
	const o = json ?? {};
	return {
		cargas: (o.cargas ?? []).map((c) => ({
			id: String(c["id"]),
			numero_carga: String(c["numero_carga"] ?? ""),
			processada_em: String(c["processada_em"] ?? ""),
			notas: n(c["notas"]),
			trocas: n(c["trocas"]),
			valor: n(c["valor"]),
			valor_trocas: n(c["valor_trocas"]),
			volumes: n(c["volumes"]),
			peso_bruto: nOuNulo(c["peso_bruto"]),
			peso_liquido: nOuNulo(c["peso_liquido"]),
			notas_sem_peso_bruto: n(c["notas_sem_peso_bruto"]),
			notas_sem_peso_liquido: n(c["notas_sem_peso_liquido"])
		})),
		cidades: (o.cidades ?? []).map((c) => ({
			carga_id: String(c["carga_id"]),
			cidade_uf: String(c["cidade_uf"] ?? ""),
			notas: n(c["notas"]),
			valor: n(c["valor"])
		}))
	};
}
function totais(cargas) {
	const soma = (f) => arred(cargas.reduce((s, c) => s + f(c), 0));
	const notas = soma((c) => c.notas);
	const valor = soma((c) => c.valor);
	const volumes = soma((c) => c.volumes);
	const trocas = soma((c) => c.trocas);
	const valorTrocas = soma((c) => c.valor_trocas);
	const pctT = div(trocas, notas);
	const pctV = div(valorTrocas, valor);
	return {
		cargas: cargas.length,
		notas,
		valor,
		ticketMedio: div(valor, notas),
		pesoBruto: soma((c) => c.peso_bruto ?? 0),
		pesoLiquido: soma((c) => c.peso_liquido ?? 0),
		notasSemPesoBruto: soma((c) => c.notas_sem_peso_bruto),
		notasSemPesoLiquido: soma((c) => c.notas_sem_peso_liquido),
		volumes,
		mediaVolumesPorCarga: div(volumes, cargas.length),
		trocas,
		pctTrocas: pctT === null ? null : pctT * 100,
		valorTrocas,
		pctValorTrocas: pctV === null ? null : pctV * 100,
		mediaNotasPorCarga: div(notas, cargas.length)
	};
}
/** Top N cidades somando as cargas informadas (todas, se `cargaIds` não for passado). */
function topCidades(cidades, criterio, limite = 10, cargaIds) {
	const mapa = /* @__PURE__ */ new Map();
	for (const c of cidades) {
		if (cargaIds && !cargaIds.has(c.carga_id)) continue;
		const nome = c.cidade_uf.trim() || "(sem cidade)";
		const atual = mapa.get(nome) ?? {
			cidade: nome,
			notas: 0,
			valor: 0
		};
		atual.notas += c.notas;
		atual.valor = arred(atual.valor + c.valor);
		mapa.set(nome, atual);
	}
	return Array.from(mapa.values()).sort((a, b) => b[criterio] - a[criterio] || a.cidade.localeCompare(b.cidade)).slice(0, limite);
}
/** Série por carga em ordem cronológica (mais antiga primeiro). */
function seriePorCarga(cargas) {
	return [...cargas].sort((a, b) => a.processada_em.localeCompare(b.processada_em)).map((c) => ({
		id: c.id,
		carga: c.numero_carga,
		processadaEm: c.processada_em,
		pesoBruto: c.peso_bruto,
		taxaTroca: c.notas > 0 ? Math.round(c.trocas / c.notas * 1e4) / 100 : 0
	}));
}
/** "AAAA-MM-DD" (dia local) → intervalo [de, até) em ISO. Até é inclusivo no dia escolhido. */
function intervaloPeriodo(de, ate) {
	const inicio = (d) => /* @__PURE__ */ new Date(`${d}T00:00:00`);
	let fim = null;
	if (ate) {
		fim = inicio(ate);
		fim.setDate(fim.getDate() + 1);
	}
	return {
		de: de ? inicio(de).toISOString() : null,
		ate: fim ? fim.toISOString() : null
	};
}
var cargasQuery = (termo) => queryOptions({
	queryKey: [
		"cargas",
		"lista",
		termo
	],
	queryFn: async () => await buscarCargas({ data: { termo } })
});
var cargaQuery = (id) => queryOptions({
	queryKey: [
		"cargas",
		"detalhe",
		id
	],
	queryFn: async () => {
		return await lerCarga({ data: { id } });
	}
});
var dashboardQuery = (de, ate) => queryOptions({
	queryKey: [
		"cargas",
		"dashboard",
		de,
		ate
	],
	queryFn: async () => lerDashboard(await dashboardCargas({ data: {
		de,
		ate
	} }))
});
//#endregion
export { seriePorCarga as a, intervaloPeriodo as i, cargasQuery as n, topCidades as o, dashboardQuery as r, totais as s, cargaQuery as t };
