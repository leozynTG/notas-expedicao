import { o as __toESM } from "../_runtime.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { E as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as Copy, c as Printer, f as LoaderCircle, j as ArrowLeft, r as Trash2, u as Pencil } from "../_libs/lucide-react.mjs";
import { c as excluirRecebimento, n as atualizarRecebimento, t as AppShell } from "./AppShell-DeQ07z7V.mjs";
import { t as Button } from "./button-UtwXV0ic.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, l as AlertDialogTrigger, n as AlertDialogAction, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as AlertDialog } from "./alert-dialog-CJc3CPXp.mjs";
import { a as useQueryClient, n as useSuspenseQuery } from "../_libs/tanstack__react-query.mjs";
import { a as duracaoRegistro, c as formDeRegistro, h as paraRegistro, o as escreverNumBr, r as dataBr, u as formatarDuracao } from "./dados-DGVmU1Si.mjs";
import { t as recebimentoQuery } from "./consultas-CR7OsYoG.mjs";
import { t as Route } from "./recebimento._id-BmxIggvZ.mjs";
import { t as FormRecebimento } from "./FormRecebimento-B0pwYjiC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recebimento._id-JjGzQBbB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Linha({ itens }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-x-6 gap-y-1 border-b border-neutral-300 py-1.5",
		children: itens.map(([r, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-40 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] uppercase tracking-wide text-neutral-500",
				children: r
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-5 text-sm font-medium text-neutral-900",
				children: v || "—"
			})]
		}, r))
	});
}
function Caixa({ titulo, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mb-3 border-2 border-neutral-800 px-3 pb-2 pt-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "-mt-3 mb-1 w-fit bg-white px-2 text-xs font-bold uppercase text-neutral-700",
			children: titulo
		}), children]
	});
}
/** Layout da folha de papel "CONTROLE DE RECEBIMENTO" (tela e impressão A4). */
function Folha({ r }) {
	const oc = Array.isArray(r.ocorrencias) ? r.ocorrencias : [];
	const n = (v, c = 0) => v === null || v === void 0 ? "" : escreverNumBr(v, c);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "folha-print mx-auto max-w-[210mm] bg-white p-6 text-neutral-900",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-end justify-between border-b-2 border-neutral-800 pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-3xl font-black leading-none tracking-tight text-neutral-700",
					children: "CDlog"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] italic text-neutral-500",
					children: "Sua entrega sempre na frente"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black tracking-tight",
					children: "CONTROLE DE RECEBIMENTO"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [["Data da chegada", dataBr(r.data_chegada)], ["Horário da chegada", r.hora_chegada]] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Caixa, {
				titulo: "Descarga",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [
					["Hora início", r.hora_inicio],
					["Hora final", r.hora_final],
					["Duração", formatarDuracao(duracaoRegistro(r)) === "–" ? "" : formatarDuracao(duracaoRegistro(r))],
					["Data da saída", dataBr(r.data_saida)]
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Caixa, {
				titulo: "Embarcador",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [["Cliente", r.cliente], ["Origem", r.origem]] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Caixa, {
				titulo: "Dados da carga",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [["Motorista", r.motorista], ["Transp.", r.transportadora]] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [["Veículo", r.veiculo], ["Placa", r.placa]] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [["Peso (kg)", n(r.peso_kg, 3)], ["Valor da carga (R$)", n(r.valor, 2)]] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [["Transporte", r.transporte], ["Cubagem (m³)", n(r.cubagem_m3, 3)]] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [
						["Volumes", n(r.volumes)],
						["Quant. NF-e", n(r.quant_nfe)],
						["Lacre", r.lacre]
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linha, { itens: [
						["Total de paletes", n(r.paletes_total)],
						["PBR", n(r.paletes_pbr)],
						["CHEP", n(r.paletes_chep)],
						["Descartável", n(r.paletes_descartavel)],
						["Quebrados", n(r.paletes_quebrados)]
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-1 text-sm font-bold",
				children: [
					"OCORRÊNCIAS / DIVERGÊNCIAS: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-2",
						children: [
							"(",
							r.tem_ocorrencia ? "X" : " ",
							") SIM"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-4",
						children: [
							"(",
							r.tem_ocorrencia ? " " : "X",
							") NÃO"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "mb-4 w-full border-2 border-neutral-800 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
					className: "border-b-2 border-neutral-800 text-left text-xs uppercase",
					children: [
						"Código",
						"Produto",
						"Quant",
						"Nota",
						"Motivo"
					].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "border-r border-neutral-800 px-2 py-1 last:border-r-0",
						children: h
					}, h))
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: Array.from({ length: Math.max(6, oc.length) }).map((_, i) => {
					const o = oc[i];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "h-7 border-b border-neutral-400",
						children: [
							o?.codigo,
							o?.produto,
							o?.quant,
							o?.nota,
							o?.motivo
						].map((c, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "border-r border-neutral-400 px-2 last:border-r-0",
							children: c
						}, j))
					}, i);
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-2 gap-10",
				children: [[
					"Conferente",
					r.assinatura_conferente,
					r.conferente
				], [
					"Motorista",
					r.assinatura_motorista,
					r.motorista
				]].map(([rot, img, nome]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-20 items-end justify-center border-b border-neutral-800",
							children: img && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: img,
								alt: `Assinatura ${rot}`,
								className: "max-h-20"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-semibold",
							children: rot
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-neutral-600",
							children: nome
						})
					]
				}, rot))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm",
				children: [
					"Lançamentos: (",
					r.lanc_kpi ? "X" : " ",
					") KPI \xA0 (",
					r.lanc_controle_paletes ? "X" : " ",
					") Controle de Paletes \xA0 (",
					r.lanc_email ? "X" : " ",
					") Enviado e-mail"
				]
			})
		]
	});
}
function Detalhe() {
	const { id } = Route.useParams();
	const { data: r } = useSuspenseQuery(recebimentoQuery(id));
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [editando, setEditando] = (0, import_react.useState)(false);
	const [salvando, setSalvando] = (0, import_react.useState)(false);
	const [excluindo, setExcluindo] = (0, import_react.useState)(false);
	const [imprimindo, setImprimindo] = (0, import_react.useState)(false);
	if (!r) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "card-surface px-5 py-10 text-center text-sm text-muted-foreground",
		children: "Recebimento não encontrado."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/recebimento",
		className: "mt-4 inline-flex items-center gap-1 text-sm text-primary hover:underline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Voltar"]
	})] });
	async function salvar(f) {
		setSalvando(true);
		try {
			await atualizarRecebimento({ data: {
				id,
				registro: paraRegistro(f)
			} });
			await qc.invalidateQueries({ queryKey: ["recebimentos"] });
			toast.success("Alterações salvas.");
			setEditando(false);
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível salvar. O que você digitou continua na tela; tente de novo.");
		} finally {
			setSalvando(false);
		}
	}
	async function imprimir() {
		setImprimindo(true);
		try {
			const { abrirFolhaPdf } = await import("./folha-pdf-CkkdQpPe.mjs");
			if (r) await abrirFolhaPdf(r);
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível gerar a folha para impressão.");
		} finally {
			setImprimindo(false);
		}
	}
	async function excluir() {
		setExcluindo(true);
		try {
			await excluirRecebimento({ data: { id } });
			await qc.invalidateQueries({ queryKey: ["recebimentos"] });
			toast.success("Recebimento excluído.");
			navigate({ to: "/recebimento" });
		} catch (e) {
			console.error(e);
			toast.error("Não foi possível excluir.");
			setExcluindo(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/recebimento",
			className: "mb-4 inline-flex items-center gap-1 text-sm text-primary hover:underline",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Recebimentos"]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-bold tracking-tight text-foreground",
				children: editando ? "Editar recebimento" : "Recebimento"
			}), !editando && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: imprimir,
						disabled: imprimindo,
						children: [imprimindo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), " Imprimir folha"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setEditando(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {}), " Editar"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/recebimento/novo",
							search: { copiar: id },
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), " Duplicar"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialog, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "text-destructive",
							disabled: excluindo,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), " Excluir"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Excluir este recebimento?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "Essa ação não pode ser desfeita. As assinaturas também serão apagadas." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancelar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						onClick: excluir,
						children: "Excluir"
					})] })] })] })
				]
			})]
		}),
		editando ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRecebimento, {
			inicial: formDeRegistro(r),
			onSalvar: salvar,
			salvando
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			className: "mt-3",
			onClick: () => setEditando(false),
			children: "Cancelar edição"
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-surface overflow-x-auto p-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Folha, { r })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-xs text-muted-foreground",
			children: [
				"Lançado por ",
				r.criado_por_email || "usuário removido",
				"."
			]
		})] })
	] });
}
//#endregion
export { Detalhe as component };
