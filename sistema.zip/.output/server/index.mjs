globalThis.__nitro_main__ = import.meta.url;
import { i as serve, r as NodeResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
import { a as toEventHandler, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"2911-+CpFQezFxzE/L8EogmAnMM3dPTE\"",
		"mtime": "2026-11-27T14:51:48.038Z",
		"size": 10513,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"7a79-6vwK0PvheNTkEc4jATr9qiQNI6Q\"",
		"mtime": "2026-11-27T14:51:48.019Z",
		"size": 31353,
		"path": "../public/favicon.ico"
	},
	"/folha-recebimento.pdf": {
		"type": "application/pdf",
		"etag": "\"18d7c-dV+D7IPd0QgIblir5wFPI3jfyjE\"",
		"mtime": "2026-11-27T14:51:48.106Z",
		"size": 101756,
		"path": "../public/folha-recebimento.pdf"
	},
	"/icone-cdlog.png": {
		"type": "image/png",
		"etag": "\"885c-WfNAK4JrNT8FpmTpjo5Fi08WEak\"",
		"mtime": "2026-11-27T14:51:48.019Z",
		"size": 34908,
		"path": "../public/icone-cdlog.png"
	},
	"/logo-cdlog.png": {
		"type": "image/png",
		"etag": "\"ce10-cfbfd3qYjg/ehBCGKZOUhh4Tsmw\"",
		"mtime": "2026-11-27T14:51:48.038Z",
		"size": 52752,
		"path": "../public/logo-cdlog.png"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-11-27T14:51:48.106Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/unrar.wasm": {
		"type": "application/wasm",
		"etag": "\"32ae9-XWnkvsSA/kXNDlhDG+2Pvs7q5sw\"",
		"mtime": "2026-11-27T14:51:48.106Z",
		"size": 207593,
		"path": "../public/unrar.wasm"
	},
	"/assets/AppShell-DuKKRfRk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16192-s7VGhsBmev5+YR8Fzj3GnKgPbcA\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 90514,
		"path": "../public/assets/AppShell-DuKKRfRk.js"
	},
	"/assets/Combination-CBwg8PtB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5c0f-AxGxezcOHqGBn5+l17TpG4Cpnac\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 23567,
		"path": "../public/assets/Combination-CBwg8PtB.js"
	},
	"/assets/FormRecebimento-OZewGSEU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"44c4-gYmiEBrV0exHQT6clNi7wSFBDLY\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 17604,
		"path": "../public/assets/FormRecebimento-OZewGSEU.js"
	},
	"/assets/_authenticated-BIN2CHEg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45d4-1sTk8W0ymzk6pSx8dKCkYcRUh+g\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 17876,
		"path": "../public/assets/_authenticated-BIN2CHEg.js"
	},
	"/assets/alert-dialog-CFOF4H9K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2075-9nkoP9bi8Lifvoev15T0w40LRZU\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 8309,
		"path": "../public/assets/alert-dialog-CFOF4H9K.js"
	},
	"/assets/chevron-right-Ce_4w_8r.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7a-Blq4HGUOFz1MFvsnR5vSikP3A0Y\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 122,
		"path": "../public/assets/chevron-right-Ce_4w_8r.js"
	},
	"/assets/cte-PVUzN88W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a54-ktTdLtDHMag/I/yPqfAqNk7PMrE\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 10836,
		"path": "../public/assets/cte-PVUzN88W.js"
	},
	"/assets/dados-B8TcGrvV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17c0-hKNXUYv3IBooKlQAncAYPJIpWwE\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 6080,
		"path": "../public/assets/dados-B8TcGrvV.js"
	},
	"/assets/dashboard-Ce4HMbks.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6f737-x+O4YpqiYzUY8IBfVeDEzkRw5Ps\"",
		"mtime": "2026-11-27T14:51:47.149Z",
		"size": 456503,
		"path": "../public/assets/dashboard-Ce4HMbks.js"
	},
	"/assets/dist-BQrrITPo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"165d-7Lvfts/+74OZ/gf60SdH2wNM3sI\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 5725,
		"path": "../public/assets/dist-BQrrITPo.js"
	},
	"/assets/dist-BQz7sBaD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"70d-Kaqzq6d1rxOcXrt6xh+JDuQ6nds\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 1805,
		"path": "../public/assets/dist-BQz7sBaD.js"
	},
	"/assets/dist-D3mQCY3V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"313-CIkqlfYjjrFuGVwYHHALniF7cSI\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 787,
		"path": "../public/assets/dist-D3mQCY3V.js"
	},
	"/assets/dist-nlOcyzZC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14d6-YZNeOMkICyNI7pmK8+KDroDSdYo\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 5334,
		"path": "../public/assets/dist-nlOcyzZC.js"
	},
	"/assets/download-CYIG0YY2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e0-Z7LjIPnRNet0ZfndxAm8x3mFy2E\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 224,
		"path": "../public/assets/download-CYIG0YY2.js"
	},
	"/assets/es-CNtkDv0S.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"668a3-np1hidO6NYgJZhmhpgvZqsBrBhY\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 420003,
		"path": "../public/assets/es-CNtkDv0S.js"
	},
	"/assets/exportar-Br9tW4wt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bca-kUJiyb2kagmRgOL+o6h6BVswkB4\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 3018,
		"path": "../public/assets/exportar-Br9tW4wt.js"
	},
	"/assets/file-spreadsheet-DzbYmH9a.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a4-Hoa1bQBrJTkXuraRZ/40TVYAfNo\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 420,
		"path": "../public/assets/file-spreadsheet-DzbYmH9a.js"
	},
	"/assets/exceljs.min-CEH0cozu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e2f1b-f1N0d8Qu/eUzC554UcU+xzofA9o\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 929563,
		"path": "../public/assets/exceljs.min-CEH0cozu.js"
	},
	"/assets/file-text-B4a-jsZI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f3-F6GQ6rZhfPDm9yvY8zsWCGrlPd0\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 755,
		"path": "../public/assets/file-text-B4a-jsZI.js"
	},
	"/assets/folha-pdf-BvbLbo74.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11eb-bcq6TeTmvhlbMHb5L4LbMFB6+YI\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 4587,
		"path": "../public/assets/folha-pdf-BvbLbo74.js"
	},
	"/assets/formato-BVpioUbh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1dd-hk1d3Jec75mJpEzW3jk1Cj+6Hzo\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 477,
		"path": "../public/assets/formato-BVpioUbh.js"
	},
	"/assets/historico-CJvNHk49.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e40-Lye0jNeITda3OsXkmjQ/IUP/U8Q\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 3648,
		"path": "../public/assets/historico-CJvNHk49.js"
	},
	"/assets/historico._id-BRxMCgBn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"175f-fV37NVIP4oqdLV+pWFf7n9mmHII\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 5983,
		"path": "../public/assets/historico._id-BRxMCgBn.js"
	},
	"/assets/historico.index-D559kogX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"118f-2dHqLCHJvTgOEx3aHxej0ICjF0o\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 4495,
		"path": "../public/assets/historico.index-D559kogX.js"
	},
	"/assets/index-CLiV3A19.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4414c-KQKaIzgP/ji4mlF/43zkeqxa0k4\"",
		"mtime": "2026-11-27T14:51:47.145Z",
		"size": 278860,
		"path": "../public/assets/index-CLiV3A19.js"
	},
	"/assets/index.esm-DzLN2eLH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a0fa-KRB2FYi9FlShRpRgcncgYaOky9E\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 41210,
		"path": "../public/assets/index.esm-DzLN2eLH.js"
	},
	"/assets/input-BBCP_jeX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"299-Sk1EcoSMulah2k296/yxmo/WFHo\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 665,
		"path": "../public/assets/input-BBCP_jeX.js"
	},
	"/assets/jszip.min-gms7YGF-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"176e0-frcsHjqlS6ApP//tLVbAHGTKegI\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 95968,
		"path": "../public/assets/jszip.min-gms7YGF-.js"
	},
	"/assets/label-CwQV9W00.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d3-RQlkWKbxv0zfKa754GpvbqzmEqY\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 979,
		"path": "../public/assets/label-CwQV9W00.js"
	},
	"/assets/manifesto-BIg6ojHV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"68a-b1aFgg0W4KcDwuauJ2UG1uFg1+0\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 1674,
		"path": "../public/assets/manifesto-BIg6ojHV.js"
	},
	"/assets/matchContext-1KyhBNCI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ce-7+V+eb1hy4TN5Z5aM7Mca0jvdT0\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 206,
		"path": "../public/assets/matchContext-1KyhBNCI.js"
	},
	"/assets/ocr-7VliE8UY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"523d-bLPtJUiyULPTeg5PPdH4R87CChY\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 21053,
		"path": "../public/assets/ocr-7VliE8UY.js"
	},
	"/assets/ordenar-BIEiKX-8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e64-ABGci7VBZf5+IKO0uZsEIrw93ik\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 3684,
		"path": "../public/assets/ordenar-BIEiKX-8.js"
	},
	"/assets/pdf-B_x5y_pZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ca28-sTV9R4AlOk4YDQ5wRwEQVM4ZNS4\"",
		"mtime": "2026-11-27T14:51:47.150Z",
		"size": 444968,
		"path": "../public/assets/pdf-B_x5y_pZ.js"
	},
	"/assets/pdf-ptDPP3m1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56d-0Z0Bb55f0OO0E0F2eA5SaNN0bnU\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 1389,
		"path": "../public/assets/pdf-ptDPP3m1.js"
	},
	"/assets/pdf-texto-ChNclbWR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"630-em/zoMgADU5vEC6yxfb6kT80w/4\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 1584,
		"path": "../public/assets/pdf-texto-ChNclbWR.js"
	},
	"/assets/pdf.worker.min-UqOn5EDC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"41-iKjTWUXJN7G+/4Dzw84XghlxIYQ\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 65,
		"path": "../public/assets/pdf.worker.min-UqOn5EDC.js"
	},
	"/assets/planilha-D8rf_DhH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a48-LlD5xu2dKVIatz/E3qTYgVF47ho\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 2632,
		"path": "../public/assets/planilha-D8rf_DhH.js"
	},
	"/assets/processar-yS5zIywx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b90-gT9FWAapvBKTUJozG3t2nHCFoqk\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 11152,
		"path": "../public/assets/processar-yS5zIywx.js"
	},
	"/assets/queryOptions-C9dJc8S5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a52-F1IjoP3aVTnv/sfNuVTywkQ5JEk\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 14930,
		"path": "../public/assets/queryOptions-C9dJc8S5.js"
	},
	"/assets/recebimento._id-DmCH0XIU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2301-BayMmOf4SnL0SvXsKycpLdPWXbQ\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 8961,
		"path": "../public/assets/recebimento._id-DmCH0XIU.js"
	},
	"/assets/recebimento.index-BsX8P_iK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21ae-Q/UXb0+fwlCJRa5Q+qTGwnAe5nE\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 8622,
		"path": "../public/assets/recebimento.index-BsX8P_iK.js"
	},
	"/assets/pdf.worker.min-CIqJB0yW.mjs": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13686b-tTbgZcZsHCSRN+itgBwG74AJwr0\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 1271915,
		"path": "../public/assets/pdf.worker.min-CIqJB0yW.mjs"
	},
	"/assets/recebimento.novo-CtdxSQBq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"691-AHpZ3FHA1GF6XNtepV1r4OIzXWU\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 1681,
		"path": "../public/assets/recebimento.novo-CtdxSQBq.js"
	},
	"/assets/rolldown-runtime-C0FnF6B9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50b-+WBETyVi3nVwvAsJ9zqeHfutBiA\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 1291,
		"path": "../public/assets/rolldown-runtime-C0FnF6B9.js"
	},
	"/assets/route-DxclXa8I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-Xr3wsDkj8nWYBNABzl5KuXfyyOM\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 141,
		"path": "../public/assets/route-DxclXa8I.js"
	},
	"/assets/styles-DwN2it7J.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"14727-hLFnwIAfmJwnWszSugpfc4V3ObQ\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 83751,
		"path": "../public/assets/styles-DwN2it7J.css"
	},
	"/assets/trash-2-DlHl7KK7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b0-Wb6BAL8dtkIJIjBzLDosm9+hKwk\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 432,
		"path": "../public/assets/trash-2-DlHl7KK7.js"
	},
	"/assets/unrar-De7VYsPt.wasm": {
		"type": "application/wasm",
		"etag": "\"32ae9-XWnkvsSA/kXNDlhDG+2Pvs7q5sw\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 207593,
		"path": "../public/assets/unrar-De7VYsPt.wasm"
	},
	"/assets/unrar-YXa3yGXY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"39-0+dms767tkJu25AuYhMPhryRyRw\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 57,
		"path": "../public/assets/unrar-YXa3yGXY.js"
	},
	"/assets/useBaseQuery-h1WR1CWn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"22b0-qVDnEPggaAxPlbyKDeQiJKHqxmY\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 8880,
		"path": "../public/assets/useBaseQuery-h1WR1CWn.js"
	},
	"/assets/useQuery-CdJVZ_6k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"60-Bo+HfFkHP3rJ5ZhvHv3lRm774kw\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 96,
		"path": "../public/assets/useQuery-CdJVZ_6k.js"
	},
	"/assets/useSelector-DlpMds3W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2749-N/UG3A8VXcdc05PK08MsHR67r5c\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 10057,
		"path": "../public/assets/useSelector-DlpMds3W.js"
	},
	"/assets/useSuspenseQuery-CT7giOaf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-ivgVgJzH464GXlKa2UeVtYnllo4\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 174,
		"path": "../public/assets/useSuspenseQuery-CT7giOaf.js"
	},
	"/assets/utils-B6KiDbIe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a7d-iNkBSvaSyIjvZOzWoTvEa49qwcI\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 27261,
		"path": "../public/assets/utils-B6KiDbIe.js"
	},
	"/assets/x-DIwZeolV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"92-6+OGZ7XLKqyhs7p5QgTqGldBfP0\"",
		"mtime": "2026-11-27T14:51:47.151Z",
		"size": 146,
		"path": "../public/assets/x-DIwZeolV.js"
	},
	"/ocr/worker.min.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b2cb-/N/GkNdd+o0+EhsLNbRj99yr/Dg\"",
		"mtime": "2026-11-27T14:51:48.019Z",
		"size": 111307,
		"path": "../public/ocr/worker.min.js"
	},
	"/ocr/eng.traineddata.gz": {
		"type": "text/plain; charset=utf-8",
		"encoding": "gzip",
		"etag": "\"2d0ea9-AqxWH1uQkusg7z1thrP0B9K5NLg\"",
		"mtime": "2026-11-27T14:51:48.018Z",
		"size": 2952873,
		"path": "../public/ocr/eng.traineddata.gz"
	},
	"/ocr/tesseract-core-lstm.wasm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b74a4-O8sAvOecXcNUcxwtJZ8nRyjMeOo\"",
		"mtime": "2026-11-27T14:51:48.015Z",
		"size": 3896484,
		"path": "../public/ocr/tesseract-core-lstm.wasm.js"
	},
	"/ocr/tesseract-core-relaxedsimd-lstm.wasm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b98e7-l6Ibk/a75JeLGmhCcGeBlOOdTA0\"",
		"mtime": "2026-11-27T14:51:48.019Z",
		"size": 3905767,
		"path": "../public/ocr/tesseract-core-relaxedsimd-lstm.wasm.js"
	},
	"/ocr/tesseract-core-simd-lstm.wasm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b8050-CqOQSGk60FaCCzWICvuRHiNVM64\"",
		"mtime": "2026-11-27T14:51:48.019Z",
		"size": 3899472,
		"path": "../public/ocr/tesseract-core-simd-lstm.wasm.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_dkkPdR = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_dkkPdR
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
