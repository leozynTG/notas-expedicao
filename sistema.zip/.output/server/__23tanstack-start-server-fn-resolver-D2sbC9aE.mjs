//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-D2sbC9aE.js
var manifest = {
	"0b2820bfd52bb35eb2a3d370a4840efa9d5c5cccd8e40bcfe4e28bd27e97691d": {
		functionName: "excluirRecebimento_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"16be09368a0e84cb8e2ce4b1a8e0c97e76f3fc09bec2bec219096afe19d0d1ec": {
		functionName: "excluirCarga_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"17676bf3447605e4a015301692433309a5509aa13cb836c74371c9dc6dabd116": {
		functionName: "criarRecebimento_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"1ad621858cb1ac3542436284088b42e4d5b09142941b0e2fdb1bb05070f80347": {
		functionName: "cargaExistente_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"4db06652dcd8e202c61c6bf72553f3fcf656fa7e79dd4f85e7081964dbe6234d": {
		functionName: "atualizarRecebimento_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"56bc825dd8bf5e306a51679d4eb2b5754f377fb9bef603f1111380e6dee205e2": {
		functionName: "listarRecebimentos_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"6cce6de78506ca95c407db558bedf1b87afce0c3924c35e55a9c2d578054ceef": {
		functionName: "lerRecebimento_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"7d4dd17df75127374004930d82771207d083cf937c64b66da253b2f3d41ead50": {
		functionName: "salvarCarga_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"832ddf203094db8d628cc9c3141f82ad90df8ab96a4ca96e3cb8bed7844a877a": {
		functionName: "baixarBackup_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"af55fb3335ddc7de462123f0eabaec035ec494de569b66e070e777e53e2d3413": {
		functionName: "dashboardCargas_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"c3bda7de8583cf7ad6095f945ab73ab8bf5e98461394635aa86aa6957f40cc5a": {
		functionName: "buscarCargas_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	},
	"d81450e7fff21008e4c3d673451f075e0cc904202bbde3c4e5b86ba668c8992b": {
		functionName: "lerCarga_createServerFn_handler",
		importer: () => import("./_ssr/api.functions-CxX--Cf8.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
